import React from 'react';
import { history, useModel, FormattedMessage, getLocale, formatMessage } from 'umi';
import {
  Modal,
  Button,
  Input,
  Alert,
  Row,
  Col,
  Tooltip,
  InputNumber,
  message,
  Form,
  DatePicker,
} from 'antd';
import { ExclamationCircleFilled } from '@ant-design/icons';
import apiService from '@/shared/services/api.service';
import moment from 'moment';
import { storageService } from '@/services/storage';

enum PurchaseRoutes {
  'bgi' = '/bgi/purchase',
  'nonmoh' = '/non-moh/purchase',
  'centralbloodbank' = '/blood-bank/purchase',
  'branchbloodbank' = '/blood-bank/purchase',
  'peripheralbloodbank' = '/blood-bank/purchase',
  'medicalredcrescent' = '/redcrescent/medical/purchase',
  'nonmedicalredcrescent' = '/redcrescent/non-medical/purchase',
}

class OrderModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      orderName: 'DefaultOrder',
      orderNotes: '',
      inputList: [{ product: '', quantity: '' }],
      maxValue: 0,
      dateFormat: 'YYYY-MM-DD',
    };
  }
  componentDidMount() {
    const { inputList } = this.props;
    this.setState({ inputList });
  }

  componentDidUpdate(prevProps) {
    if (prevProps.inputList !== this.props.inputList) {
      this.setState({ inputList: this.props.inputList });
    }
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleOk = async (e) => {
    const { locationId } = this.props;
    const { orderName, orderNotes, inputList } = this.state;

    // array.forEach(function(v){ delete v.bad });
    const regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    const numericRegex = /^\d+$/;

    if (this.props.type === 'PlaceOrder') {
      if (
        !inputList.some(
          (sku) => sku.quantity <= 0 || sku.quantity.toString().length > 9 || !sku.supplierName || !sku.expiryDate || !sku.manufacturingCountry
            || !sku.deliveryCost || !sku.eta || !sku.itemPrice || !sku.totalValueWithTax || !sku.issueDate || !sku.issueNumber
            || !sku.deliveryCost || !sku.eta || !sku.itemPrice || !sku.totalValueWithTax || !sku.issueDate || !sku.issueNumber
            || !sku.deliveryCost || !sku.eta || !sku.itemPrice || !sku.totalValueWithTax || !sku.issueDate || !sku.issueNumber || !sku.email ||
            !sku.placeOfSupply || !sku.srcaNumber || !sku.mailBox || !sku.phoneNumber || !sku.faxNumber || !sku.nupcoNumber || !regex.test(sku.email)
            || !numericRegex.test(sku.phoneNumber) || !numericRegex.test(sku.nupcoNumber) || !numericRegex.test(sku.srcaNumber)

        )
      ) {
        this.setState({
          visible: false,
        });

        await apiService
          .createPurchaseOrder({
            name: orderName,
            // location: locationId,
            userName: this.props.user.name,
            email: this.props.user.email,
            orderItems: inputList,
            notes: orderNotes,
            labType: this.props.module,
          })
          .then(() => message.success(formatMessage({ id: 'OrderCreationSuccess' })));

        const urlFragment = PurchaseRoutes[this.props.module];
        history.push(urlFragment);
      } else {
        if (inputList.some((sku) => sku.quantity <= 0)) {
          message.error(formatMessage({ id: 'SKUQuantityError' }));
        } else if (inputList.some((sku) => !sku.supplierName)) {
          message.error(formatMessage({ id: 'MissingSupplierName' }));
        } else if (inputList.some((sku) => !sku.expiryDate)) {
          message.error(formatMessage({ id: 'MissingExpiryDate' }));
        } else if (inputList.some((sku) => !sku.manufacturingCountry)) {
          message.error(formatMessage({ id: 'MissingManufacturingCountry' }));
        } else if (inputList.some((sku) => !sku.deliveryCost || sku.deliveryCost <= 0)) {
          message.error(formatMessage({ id: 'DeliveryCostShouldBeNumericAndGreaterThan0' }));
        } else if (inputList.some((sku) => !sku.eta || sku.eta <= 0)) {
          message.error(formatMessage({ id: 'MissingExpectedLeadTime' }));
        } else if (inputList.some((sku) => !sku.itemPrice || sku.itemPrice <= 0)) {
          message.error(formatMessage({ id: 'ItemPriceShouldBeNumericAndGreaterThan0' }));
        } else if (inputList.some((sku) => !sku.totalValueWithTax || sku.totalValueWithTax <= 0)) {
          message.error(formatMessage({ id: 'TotalValueWithTaxShouldBeNumericAndGreaterThan0' }));
        } else if (inputList.some((sku) => !sku.issueDate)) {
          message.error(formatMessage({ id: 'MissingIssueDate' }));
        } else if (inputList.some((sku) => !sku.issueNumber || sku.issueNumber <= 0)) {
          message.error(formatMessage({ id: 'IssueNumberShouldBeNumericAndGreaterThan0' }))
        }else if (inputList.some((sku) => !sku.mailBox )) {
          message.error(formatMessage({ id: 'MissingMailBox' }));
        }else if (inputList.some((sku) => !sku.phoneNumber )) {
          message.error(formatMessage({ id: 'MissingPhoneNumber' }));
        }else if (inputList.some((sku) => !numericRegex.test(sku.phoneNumber) )) {
          message.error(formatMessage({ id: 'InvalidPhoneNumber' }));
        }else if (inputList.some((sku) => !sku.faxNumber )) {
          message.error(formatMessage({ id: 'MissingFaxNumber' }));
        }else if (inputList.some((sku) => !sku.placeOfSupply )) {
          message.error(formatMessage({ id: 'MissingPlaceOfSupply' }));
        }else if (inputList.some((sku) => !sku.srcaNumber  || !numericRegex.test(sku.srcaNumber) )) {
          message.error(formatMessage({ id: 'MissingOrInvalidSrcaNumber' }));
        }else if (inputList.some((sku) => !sku.nupcoNumber || !numericRegex.test(sku.nupcoNumber) )) {
          message.error(formatMessage({ id: 'MissingOrInvalidNupcoNumber' }));
        }else if (inputList.some((sku) =>   !sku.email )) {
          message.error(formatMessage({ id: 'MissingEmailOrInvalidEmail' }));
        }else if (inputList.some((sku) =>   !regex.test(sku.email) )) {
          message.error(formatMessage({ id: 'InvalidEmail' }));
        }
      }
    } else {
      if (
        !inputList.some(
          (sku) => sku.quantity <= 0)
      ) {
        this.setState({
          visible: false,
        });

        await apiService
          .createPurchaseOrder({
            name: orderName,
            // location: locationId,
            userName: this.props.user.name,
            email: this.props.user.email,
            orderItems: inputList,
            notes: orderNotes,
            labType: this.props.module,
          })
          .then(() => message.success(formatMessage({ id: 'OrderCreationSuccess' })));

        const urlFragment = PurchaseRoutes[this.props.module];
        history.push(urlFragment);
      } else {
        if (inputList.some((sku) => sku.quantity <= 0)) {
          message.error(formatMessage({ id: 'SKUQuantityError' }));
        } else {
          message.error(formatMessage({ id: 'QuantityShouldBeNumericAndGreaterThan0' }));
        }
      }

    }
  };

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  };

  handleInputChange = (e, index) => {
    const { name, value } = e.target;
    const list = this.state.inputList;
    list[index][name] = value;
    this.setState({ inputList: list });
  };

  // handle click event of the Remove button
  handleRemoveClick = (index) => {
    const list = this.state.inputList;
    list.splice(index, 1);
    this.setState({ inputList: list });
  };

  // handle click event of the Add button
  handleAddClick = () => {
    const list = this.state.inputList;
    list.push({ product: '', quantity: '' });
    this.setState({ inputList: list });
  };
  disabledPastDates = (current: any) => {
    // Can not select days after today
    return current && current < moment().add(1, 'days');
  };

  render() {
    const { visible, orderName, inputList } = this.state;
    const { count, style, btnName } = this.props;
    const locale = getLocale();

    return (
      <div>
        <Button
          // disabled={this.checkPermission()}
          // style={style}
          type="primary"
          onClick={this.showModal}
        >
          {btnName}
        </Button>
        <Modal
          title={<FormattedMessage id="CreatePurchaseOrder" />}
          visible={visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
          {inputList.some((item) => item.quantitiesInTransit > 0) ? (
            <Row gutter={[12, 12]}>
              <Col>
                <Alert
                  message={formatMessage({ id: 'Warning' })}
                  description={formatMessage({ id: 'ItemsInTransitWarning' })}
                  type="warning"
                  showIcon
                  closable
                />
              </Col>
            </Row>
          ) : null}

          <div style={{ marginTop: '5px' }}>
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                padding: '0px 42px',
              }}
            >
              <span>
                <FormattedMessage id="Product" />
              </span>
              <span style={{ marginLeft: '36%' }}>
                <FormattedMessage id="Quantity" />
              </span>
            </div>
            {inputList.map((x, i) => {
              if (typeof x.quantity !== 'number') {
                x.quantity = 0;
              }
              return (
                <Row gutter={[12, 12]} align="middle">
                  <Col span={11}>
                    <Input
                      name="product"
                      value={locale === 'ar-EG' ? x.arabicDescription : x.description}
                      onChange={(e) => this.handleInputChange(e, i)}
                    />
                    {this.state.inputList[i].quantity > x.nupcoInventoryQuantity &&
                      this.state.inputList[i].quantity !== x.nupcoInventoryQuantity ? (
                      <p style={{ color: 'red', height: '20px' }}> </p>
                    ) : (
                      <p> </p>
                    )}
                  </Col>
                  <Col span={11}>
                    <InputNumber
                      className="ml10"
                      name="quantity"
                      value={x.quantity}
                      onChange={(value) =>
                        this.handleInputChange({ target: { value, name: 'quantity' } }, i)
                      }
                      style={{ width: '100%' }}
                    />
                    {this.state.inputList[i].quantity > x.nupcoInventoryQuantity &&
                      this.state.inputList[i].quantity !== x.nupcoInventoryQuantity ? (
                      <p style={{ color: 'red', height: '20px' }}>
                        {formatMessage({ id: 'CannotBeMoreThan' }) + x.nupcoInventoryQuantity}
                      </p>
                    ) : this.state.inputList[i].quantity &&
                      (isNaN(this.state.inputList[i].quantity) ||
                        this.state.inputList[i].quantity <= 0) ? (
                      <p style={{ color: 'red', height: '20px' }}>
                        {formatMessage({
                          id: 'QuantityShouldBeNumericAndGreaterThan0',
                        })}{' '}
                      </p>
                    ) : this.state.inputList[i].quantity &&
                      this.state.inputList[i].quantity.toString().length > 9 && this.props.type === 'PlaceOrder' ? (
                      <p style={{ color: 'red', height: '20px' }}>
                        {' '}
                        {formatMessage({
                          id: 'QuantityShouldBeLessThan9Digits',
                        })}{' '}
                      </p>
                    ) : (
                      <p></p>
                    )}
                  </Col>
                  <Col span={2}>
                    {x.quantitiesInTransit > 0 ? (
                      <Tooltip
                        placement="top"
                        title={
                          formatMessage({ id: 'QuantitiesinTransit' }) +
                          `: ${x.quantitiesInTransit}`
                        }
                      >
                        <ExclamationCircleFilled style={{ color: '#ad8b00' }} />
                      </Tooltip>
                    ) : null}
                  </Col>
                  {this.props.type === 'PlaceOrder' && window.location.href.includes('redcrescent') && (
                    <>
                      <Col span={22}>
                        <Form.Item
                          label={formatMessage({
                            id: 'SupplierName',
                          })}
                          rules={[
                            {
                              required: true,
                              message: formatMessage({
                                id: 'MissingSupplierName',
                              }),
                            },

                          ]}
                        >
                          <Input
                            name="supplier"
                            onChange={(value) =>
                              this.handleInputChange(
                                { target: { value: value.target.value, name: 'supplierName' } },
                                i,
                              )
                            }
                            style={{ width: '100%' }}
                          />
                        </Form.Item>
                      </Col>
                      <div
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          padding: '0px 42px',
                          width: '100%',
                        }}
                      >
                        <span>
                          <FormattedMessage id="ExpiryDate" />
                        </span>
                        <span style={{ marginLeft: '36%' }}>
                          <FormattedMessage id="ManufacturingCountry" />
                        </span>
                      </div>
                      <Col span={11}>
                        <Form.Item
                          name="expiryDate"
                          rules={[
                            {
                              required: true,
                              message: formatMessage({ id: 'MissingExpiryDate' }),
                            },
                          ]}
                        // initialValue={updateModalData && moment(updateModalData?.expiryDate, dateFormat)}
                        >
                          <DatePicker
                            format={this.state.dateFormat}
                            disabledDate={this.disabledPastDates}
                            style={{ width: '100%' }}
                            onChange={(value) =>
                              this.handleInputChange({ target: { value, name: 'expiryDate' } }, i)
                            }
                          />
                        </Form.Item>
                      </Col>
                      <Col span={11}>
                        <Form.Item
                          rules={[
                            {
                              required: true,
                              message: formatMessage({
                                id: 'ManufacturingCountry',
                              }),
                            },
                          ]}
                        >
                          <Input
                            name="manufacturingCountry"
                            onChange={(value) =>
                              this.handleInputChange(
                                { target: { value: value.target.value, name: 'manufacturingCountry' } },
                                i,
                              )
                            }
                          />
                        </Form.Item>
                      </Col>
                      <div
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          padding: '0px 42px',
                          width: '100%',
                        }}
                      >
                        <span>
                          <FormattedMessage id="DeliveryCost" />
                        </span>
                        <span style={{ marginLeft: '36%' }}>
                          <FormattedMessage id="ExpectedLeadTime" />
                        </span>
                      </div>
                      <Col span={11}>
                        <Form.Item
                          rules={[
                            {
                              required: true,
                              message: formatMessage({
                                id: 'DeliveryCost',
                              }),
                            },
                          ]}
                        >
                          <InputNumber
                            className="ml10"
                            name="deliveryCost"
                            onChange={(value) =>
                              this.handleInputChange({ target: { value, name: 'deliveryCost' } }, i)
                            }
                            style={{ width: '100%' }}
                          />
                        </Form.Item>
                      </Col>
                      <Col span={11}>
                        <Form.Item
                          rules={[
                            {
                              required: true,
                              message: formatMessage({
                                id: 'ExpectedLeadTime',
                              }),
                            },
                          ]}
                        >
                          <InputNumber
                            className="ml10"
                            min={1}
                            name="eta"
                            onChange={(value) =>
                              this.handleInputChange({ target: { value, name: 'eta' } }, i)
                            }
                            style={{ width: '100%' }}
                          />
                        </Form.Item>
                      </Col>
                      <div
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          padding: '0px 42px',
                          width: '100%',
                        }}
                      >
                        <span>
                          <FormattedMessage id="ItemPrice" />
                        </span>
                        <span style={{ marginLeft: '36%' }}>
                          <FormattedMessage id="TotalValueWithTax" />
                        </span>
                      </div>
                      <Col span={11}>
                        <InputNumber
                          min={1}
                          className="ml10"
                          name="itemPrice"
                          onChange={(value) =>
                            this.handleInputChange({ target: { value, name: 'itemPrice' } }, i)
                          }
                          style={{ width: '100%' }}
                        />
                      </Col>
                      <Col span={11}>
                        <InputNumber
                          min={1}
                          className="ml10"
                          name="totalValueWithTax"
                          onChange={(value) =>
                            this.handleInputChange({ target: { value, name: 'totalValueWithTax' } }, i)
                          }
                          style={{ width: '100%' }}
                        />
                      </Col>
                      <div
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          padding: '0px 42px',
                          width: '100%',
                        }}
                      >
                        <span>
                          <FormattedMessage id="IssueDate" />
                        </span>
                        <span style={{ marginLeft: '36%' }}>
                          <FormattedMessage id="IssueNumber" />
                        </span>
                      </div>
                      <Col span={11}>
                        <DatePicker
                          onChange={(value) =>
                            this.handleInputChange({ target: { value, name: 'issueDate' } }, i)
                          }
                          format={this.state.dateFormat}
                          disabledDate={this.disabledPastDates}
                          style={{ width: '100%' }}
                        />
                      </Col>
                      <Col span={11}>
                        <InputNumber
                          min={1}
                          className="ml10"
                          name="issueNumber"
                          onChange={(value) =>
                            this.handleInputChange({ target: { value, name: 'issueNumber' } }, i)
                          }
                          style={{ width: '100%' }}
                        />
                      </Col>
                    </>
                  )}

                </Row>
              );
            })}
          </div>
          <Row gutter={[12, 12]}>
            <Col span={22}>
              <Input
                placeholder={formatMessage({ id: 'Note' })}
                onChange={(event) => this.setState({ orderNotes: event.target.value })}
                style={{ width: '100%' }}
              />
            </Col>
          </Row>
        </Modal>
      </div>
    );
  }
}

const OrderModalWrapper = (props: any) => {
  const { initialState } = useModel('@@initialState');
  const userDetails = {
    name: initialState?.currentUser?.name || '',
    email: initialState?.currentUser?.email || '',
  };

  return <OrderModal {...props} user={userDetails} />;
};

export default OrderModalWrapper;

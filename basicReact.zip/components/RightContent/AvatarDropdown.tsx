import React, { useCallback, useState } from 'react';
import {
  EnvironmentOutlined,
  SafetyOutlined,
  LogoutOutlined,
  MailOutlined,
  UserOutlined,
} from '@ant-design/icons';
import { Switch, Avatar, Menu, Spin, Modal } from 'antd';
import {
  history,
  useModel,
  formatMessage,
  FormattedMessage,
  defineConfig,
  getLocale,
  setLocale,
} from 'umi';
import Apis from '@/api/apis';
import _ from 'lodash';
import HeaderDropdown from '../HeaderDropdown';
import { getObj } from '../../../config/theme';
import styles from './index.less';
import DarkModeSwitch from '../DarkModeSwitch/index';
import defaultSettings from '../../../config/defaultSettings';
export interface GlobalHeaderRightProps {
  menu?: boolean;
}
const AvatarDropdown: React.FC<GlobalHeaderRightProps> = ({ menu }) => {
  const { initialState, setInitialState } = useModel('@@initialState');
  const [isVisible, setIsVisible] = useState(false);
  const [theme, setTheme] = useState('');
  const logOut = async () => {
    Modal.confirm({
      title: formatMessage({ id: 'AreYouSureToLogOut' }),
      okText: formatMessage({ id: 'Yes' }),
      okType: 'primary',
      onOk: () => {
        return Apis.logout().then(() => {
          // storageService.clear();

          setInitialState({});
          history.push('/user/login');
        });
      },
      onCancel: () => {},
    });
  };

  const onMenuClick = useCallback(
    (event: {
      key: React.Key;
      keyPath: React.Key[];
      item: React.ReactInstance;
      domEvent: React.MouseEvent<HTMLElement>;
    }) => {
      const { key } = event;
      if (key === 'logout' && initialState) {
        setIsVisible(false);
        logOut();
        return;
      }

      if (key === 'profile') {
        // Modal.
      }
      // history.push(`/user/login`);
    },
    [],
  );

  const loading = (
    <span className={`${styles.action} ${styles.account}`}>
      <Spin
        size="small"
        style={{
          marginLeft: 8,
          marginRight: 8,
        }}
      />
    </span>
  );

  if (!initialState) {
    return loading;
  }

  const { currentUser } = initialState;

  if (!currentUser || !currentUser.name) {
    return loading;
  }

  const handleVisibleChange = (flag) => {
    setIsVisible(flag);
  };

  const menuHeaderDropdown = (
    <Menu className={styles.menu} selectedKeys={[]} onClick={onMenuClick}>
      <Menu.Item className={styles.info}>
        <MailOutlined />
        {currentUser.email}
      </Menu.Item>

      <Menu.Item className={styles.info}>
        <SafetyOutlined />
        {_.startCase(currentUser.role)}
      </Menu.Item>

      <Menu.Item className={styles.info}>
        <EnvironmentOutlined />
        {currentUser.locationName || currentUser.region}
      </Menu.Item>
      <Menu.Divider />

      <Menu.Item key="logout" className={styles.logout}>
        <LogoutOutlined />
        <FormattedMessage id="LogOut" />
      </Menu.Item>
    </Menu>
  );
  const changeLang = () => {
    const locale = getLocale();
    if (!locale || locale.includes( 'en')) {
      setLocale('ar-EG', true);
    } else {
      setLocale('en-US', true);
    }
  };

  return (
    <div className={styles.headerDiv}>
      {window.location.href.includes('redcrescent') && (
        <div className={styles.customColor}>
          General
          <DarkModeSwitch className={styles.topToggle} theme={theme} setTheme={setTheme} />
          Custom
        </div>
      )}
      {window.location.href.includes('redcrescent') && (
        <div>
          Arabic
          <Switch className={styles.topToggle} defaultChecked onChange={changeLang} />
          English
        </div>
      )}

      <HeaderDropdown
        overlay={menuHeaderDropdown}
        onVisibleChange={handleVisibleChange}
        visible={isVisible}
      >
        <span className={`${styles.action} ${styles.account}`}>
          <Avatar size="small" className={styles.avatar} icon={<UserOutlined />} alt="avatar" />
          <span className={`${styles.name} anticon`}>{currentUser.name}</span>
        </span>
      </HeaderDropdown>
    </div>
  );
};

export default AvatarDropdown;

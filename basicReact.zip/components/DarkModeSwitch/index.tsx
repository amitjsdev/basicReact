import React from 'react';
import { Switch } from 'antd';
import { PropertySafetyFilled } from '@ant-design/icons';
import defaultSettings from '../../../config/defaultSettings';
enum Theme {
  LIGHT = 'light-theme',
  DARK = 'no-theme',
}

function changeTheme(nextTheme: Theme) {
  let styleLink = document.getElementById('theme-style') as HTMLLinkElement;
  const body = document.getElementsByTagName('body')[0];

  if (styleLink) {
    styleLink.href = `/theme/${nextTheme}.css`;
    body.className = `body-wrap-${nextTheme}`;
    return;
  }
  styleLink = document.createElement('link');
  styleLink.type = 'text/css';
  styleLink.rel = 'stylesheet';
  styleLink.id = 'theme-style';
  styleLink.href = `/theme/${nextTheme}.css`;
  body.className = `body-wrap-${nextTheme}`;
  document.body.append(styleLink);
}

export default (props) => {
  const onChange = (checked: boolean) => {
    if (checked) {
      props.setTheme(Theme.LIGHT);
      localStorage.setItem('currentTheme', Theme.LIGHT);
      changeTheme(Theme.LIGHT);
    } else {
      props.setTheme(Theme.DARK);
      localStorage.setItem('currentTheme', Theme.DARK);
      changeTheme(Theme.DARK);
    }
  };
  return (
    <Switch
      checked={
        props.theme === 'light-theme' || localStorage.getItem('currentTheme') === 'light-theme'
          ? true
          : false
      }
      defaultChecked={false}
      onChange={onChange}
      className={props.className}
    />
  );
};

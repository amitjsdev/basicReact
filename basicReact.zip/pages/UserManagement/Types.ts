interface Formdata {
  name: string;
  email: string;
  id: string;
  default: boolean;
  locationId: any;
  locationName: string;
  regionId: any;
  role: string;
  type: any;
  applications: Modules[];
}
interface Modules {
  id: string;
  locationId: any;
  locationName: string;
  regionId: any;
  regionName: string;
  name: string;
  role: string;
  userId: any;
  default: boolean;
}

enum Role {
  'storeKeeper' = 'Storekeeper',
  'superUser' = 'Super User',
  'purchaser' = 'Purchaser',
  'purchaseManager' = 'Purchase Manager',
  'locationOfficer' = 'Location Officer',
  'committeeMember' = 'Committee Member',
  'storeSupervisor' = 'Store Supervisor',
  'stockController' = 'Stock Controller',
  'committeeAdministrativeMember' = 'Committee Administrative Member',
  'committeeHeadManager' = 'Committee Head Manager',
  'committeeMedicalMember' = 'Committee Medical Member',
  'regionAdmin' = 'Region Admin',
}

enum ModuleTypes {
  'medicalredcrescent' = 'Medical Red Crescent',
  'nonmedicalredcrescent' = 'Non-Medical Red Crescent',
}
const roleByModule = {
  medicalredcrescent: {
    storeKeeper: 'Storekeeper',
    superUser: 'Super User',
    purchaser: 'Purchaser',
    purchaseManager: 'Purchase Manager',
    locationOfficer: 'Location Officer',
    committeeMember: 'Committee Member',
    storeSupervisor: 'Store Supervisor',
    stockController: 'Stock Controller',
    committeeAdministrativeMember: 'Committee Administrative Member',
    committeeHeadManager: 'Committee Head Manager',
    committeeMedicalMember: 'Committee Medical Member',
  },
  nonmedicalredcrescent: {
    storeKeeper: 'Storekeeper',
    superUser: 'Super User',
    purchaser: 'Purchaser',
    purchaseManager: 'Purchase Manager',
    locationOfficer: 'Location Officer',
    committeeMember: 'Committee Member',
    storeSupervisor: 'Store Supervisor',
    stockController: 'Stock Controller',
    committeeAdministrativeMember: 'Committee Administrative Member',
    committeeHeadManager: 'Committee Head Manager',
    committeeMedicalMember: 'Committee Medical Member',
  },
};
export { roleByModule, ModuleTypes, Formdata, Role, Modules };

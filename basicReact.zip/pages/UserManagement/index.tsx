import { PageContainer } from '@ant-design/pro-layout';
import React, { useState, useEffect } from 'react';
import { message } from 'antd';
import authService from '@/services/auth.service';
import UserContainer from './UserContainer/userContainer';
import { getAllUsers } from './userManagement.services';

import styles from './index.less';

export default () => {
  const [labs, setLabs] = useState([]);
  const [users, setUsers] = useState([]);
  const [currentUser, setCurrentUser] = useState({});

  const fetchUsers = async (lab: any[], role: string, location: string) => {
    await getAllUsers(lab, role, location)
      .then((data) => {
        setUsers(data);
      })
      .catch((err) => {
        message.error(err);
      });
  };

  useEffect(() => {
    const lab = ['medicalredcrescent', 'nonmedicalredcrescent'];
    setLabs(lab);

    authService
      .getUserProfile()
      .then((res) => {
        fetchUsers(lab, res?.role, res?.locationId);
        setCurrentUser(res);
      })
      .catch((err) => {
        message.error(err);
      });
  }, []);

  return (
    <PageContainer content="" className={styles.main}>
      <UserContainer labs={labs} users={users} fetchUsers={fetchUsers} currentUser={currentUser} />
    </PageContainer>
  );
};

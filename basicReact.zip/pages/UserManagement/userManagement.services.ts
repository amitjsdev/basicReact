import httpService from '@/services/http.service';
import { ApiUrlFragments } from '@/services/Constants';
import errorHandler from '@/services/errorHandler';

const getAllLabs = () => {
  return httpService
    .get(`${ApiUrlFragments.USER}/locations`)
    .catch((err) => errorHandler(err, null));
};

const getAllRegions = () => {
  return httpService.get(`${ApiUrlFragments.USER}/regions`).catch((err) => errorHandler(err, null));
};

const getAllUsers = (labs: any[], role: string, location: string) => {
  const params = { labType: JSON.stringify(labs), role, locationId: location };
  return httpService
    .get(`${ApiUrlFragments.USER}/users`, { params })
    .catch((err) => errorHandler(err, null));
};

const createUser = (user: any) => {
  return httpService
    .post(`${ApiUrlFragments.USER}/usersRedCrescent`, user)
    .catch((err) => errorHandler(err, null));
};
const deleteUser = (id: any) => {
  return httpService
    .delete(`${ApiUrlFragments.USER}/users/${id}`)
    .catch((err) => errorHandler(err, null));
};
const removeModule = (id: any, module: Object) => {
  return httpService.put(`${ApiUrlFragments.USER}/users/${id}`, module);
};
const editUserModule = (id: any, module: Object) => {
  return httpService.put(`${ApiUrlFragments.USER}/users-redcrescent/${id}`, module);
};
const getClassifications = (labType: App.LabType) => {
  return httpService
    .get(`${ApiUrlFragments.INVENTORY}/products/classifications`, {
      params: { labType },
    })
    .then((res) => res.results.data)
    .catch((err) => errorHandler(err));
};
export {
  getAllLabs,
  getAllRegions,
  getAllUsers,
  createUser,
  deleteUser,
  editUserModule,
  removeModule,
  getClassifications,
};

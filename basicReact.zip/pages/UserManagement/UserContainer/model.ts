import { Effect, Reducer } from 'umi';

export interface StateType {
  survey: any[];
  options: any[];
  formContent: any[];
}

export interface ModelType {
  namespace: string;
  state: StateType;
  effects: {
    submitUserForm: Effect;
  };
  reducers: {
    saveUserForm: Reducer<StateType>;
  };
}

const formContent: any[] = [
  {
    sectionName: 'Modules',

    formFields: [
      {
        valueType: 'select',
        type: '',
        name: 'dropdownValue',
        label: 'Extraction Machines Name',
        defaultValue: '',
        inputType: 'text',
        selectOptions: [
          {
            key: 'me1',
            value: 'Bioneer',
          },
          {
            key: 'me2',
            value: 'Thermo Fisher',
          },
          {
            key: 'me3',
            value: 'Perkin Elmer',
          },
          {
            key: 'me4',
            value: 'Abbott m24sp',
          },
          {
            key: 'me5',
            value: 'Abbott m2000sp',
          },
          {
            key: 'me6',
            value: 'Extraction MBGI',
          },
          {
            key: 'me7',
            value: 'Mag NA Pure',
          },
          {
            key: 'me9',
            value: 'EZ1',
          },
          {
            key: 'me0',
            value: 'Others',
          },
        ],
        onChange: () => {},
      },
      {
        valueType: 'input',
        type: 'quantity',
        name: 'machineCount',
        label: 'No. of machines',
        defaultValue: '',
        inputType: 'number',
        selectOptions: [],
        onChange: () => {},
      },
      {
        valueType: 'input',
        type: 'tests',
        name: 'testsCount',
        label: 'Daily Extraction Tests',
        defaultValue: '',
        inputType: 'number',
        selectOptions: [],
        onChange: () => {},
      },
    ],
    enableFormFields: true,
  },
  {
    question: 'Select Name and enter number of Working Machines for PCR',
    questionInArabic:
      'حدد اسم جهاز البي سي آر وادخل عدد الأجهزه التي تعمل  وعدد الفحوصات اليومي لكل نوع من الأجهزة',
    key: 'machine_pcr_working',
    enableTable: true,
    surveyFields: {},
    required: true,
    formFields: [
      {
        valueType: 'select',
        type: '',
        name: 'dropdownValue',
        label: 'PCR Machines Name',
        defaultValue: '',
        inputType: 'text',
        selectOptions: [
          {
            key: 'mpcr1',
            value: 'ABI RT PCR',
          },
          {
            key: 'mpcr2',
            value: 'ROCH -LIGHTCYCLER',
          },
          {
            key: 'mpcr3',
            value: 'BGI PCR',
          },
          {
            key: 'mpcr4',
            value: 'Abbott m2000rt RealTime PCR',
          },
          {
            key: 'mpcr5',
            value: 'Real-Time PCR Rotor GENE',
          },
          {
            key: 'mpcr6',
            value: 'Real-Time PCR Applied Biosystem 7500',
          },
        ],
        onChange: () => {},
      },
      {
        valueType: 'input',
        type: 'quantity',
        name: 'machineCount',
        label: 'No. of machines',
        defaultValue: '',
        inputType: 'number',
        selectOptions: [],
        onChange: () => {},
      },
      {
        valueType: 'input',
        type: 'tests',
        name: 'testsCount',
        label: 'Daily PCR Tests',
        defaultValue: '',
        inputType: 'number',
        selectOptions: [],
        onChange: () => {},
      },
    ],
    enableFormFields: true,
  },
  {
    question: 'How many IgM / Antiobody Test kits are available?',
    questionInArabic: 'المتبقي من الأجسام المضادة (kit) IgM',
    key: 'serology_total_no_of_igm_antibody_testkits',
    required: true,
    enableTable: false,
    surveyFields: {
      type: 'input',
      optionfields: [],
      inputType: 'number',
    },
    formFields: [],
    enableFormFields: true,
  },
];

const Model: ModelType = {
  namespace: 'userModal',
  state: {
    survey: [],
    options: [],
    formContent,
  },

  effects: {
    async *submitUserForm({ payload }) {
      const dataBody = [];

      const today = new Date();
      const dd = String(today.getDate()).padStart(2, '0');
      const mm = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
      const yyyy = today.getFullYear();

      const _date = `${yyyy}-${mm}-${dd}`;

      const payloadToSend = {
        date: _date,
        ...payload,
      };

      await mohService.submitSurvey(payloadToSend);
      window.location.reload();
    },
  },

  reducers: {
    saveUserForm(state, { payload }) {
      return {
        ...state,
        survey: [...(state as StateType).survey, ...payload],
      };
    },
  },
};

export { formContent };
export default Model;

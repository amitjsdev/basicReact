import React, { useState, useEffect } from 'react';
import { Button, Form, Modal, message } from 'antd';
import { connect } from 'umi';
import {
  createUser,
  getAllLabs,
  getAllRegions,
  getAllUsers,
  deleteUser,
  removeModule,
  getClassifications,
} from '../userManagement.services';
import { Formdata } from '../Types';
import { StateType } from './model';
import ShowTable from './showTable';
import AddUserFormRedCrescent from '../Modal/AddUserModal/addUserRedCrescent';
import EditUserRedCrescent from '../Modal/EditUserModal/editUserRedCrescent';

const UserListComponent = (props) => {
  const { labs, fetchUsers, users, currentUser } = props;

  const [locations, setLocations] = useState([]);
  const [regions, setRegions] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [labType, setLabType] = useState({});
  const [regionsByLabtype, setRegionsByLabType] = useState({});
  const [selectedLocationName, setSelectedLocationName] = useState({});
  const [selectedRegionName, setSelectedRegionName] = useState({});
  const [showEditUserRedCrescent, setShowEditUserRedCrescent] = useState(false);
  const [editModuleData, setEditModuleData] = useState({});
  const [moduleType, setModuleType] = useState({});
  const [moduleLength, setModuleLength] = useState(0);
  const [prevModule, setPrevModule] = useState([]);
  const [prevModuleType, setPrevModuleType] = useState({});
  const [prevModules, setPrevModules] = useState([]);
  const [form] = Form.useForm();
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    getLocations();
    getRegions();
  }, []);

  const handleSubmit = async (values) => {
    setLoading(true);
    let payload: Formdata;
    const x = values.modules.map((list, index) => {
      if (list.name === 'tms') {
        delete list.locationId;
        return {
          ...list,
          locationName: 'All Location',
        };
      } else {
        return selectedLocationName[index] != undefined
          ? {
              ...list,
              locationName: selectedLocationName[index],
            }
          : {
              ...list,
              regionName: selectedRegionName[index],
            };
      }
    });
    let location = {};
    const final = x.map((val) => {
      if (val.name === values.default) {
        location = val.locationName
          ? { locationId: val.locationId, type: val.name, role: val.role }
          : { regionId: val.regionId, type: val.name, role: val.role };
      }
      return val.name === values.default
        ? {
            ...val,
            default: true,
          }
        : {
            ...val,
            default: false,
          };
    });
    delete values.default;
    payload = {
      ...values,
      ...location,
      modules: final,
    };
    try {
      await createUser({ ...payload })
        .then(() => {
          setShowModal(false);
          setLoading(false);
          setLabType({});
          setSelectedRegionName({});
          setSelectedLocationName({});
          form.resetFields();
          fetchUsers(labs);
        })
        .catch((err) => {
          alert(err.message);
        });
    } catch (error) {
      alert(error.message);
    }
  };

  const getClassification = async (lab) => {
    const resultVal = await getClassifications(lab);
    const category = resultVal?.map((ele) => ele.category);
    const uniqueCategory = _.uniqBy(category);
    setCategories(uniqueCategory);
  };

  const getLocations = async () => {
    try {
      const data = await getAllLabs();
      setLocations(data);
    } catch (error) {}
  };

  const getRegions = async () => {
    try {
      const data = await getAllRegions();
      setRegions(data);
    } catch (error) {}
  };

  const removeUser = async (id) => {
    await deleteUser(id)
      .then(() => {
        fetchUsers(labs);
      })
      .catch((err) => {
        fetchUsers(labs);
      });
  };

  const editModule = (module) => {
    setShowEditUserRedCrescent(true);
    const result = module.applications?.map((ele) => ele.name);
    let obj = {};
    result?.forEach((ele, index) => {
      obj = { ...obj, [index]: ele };
    });
    setModuleType({ ...obj });
    setPrevModuleType({ ...obj });
    setEditModuleData(module);
    setModuleLength(module.applications?.length);
    setPrevModule(module.applications);
    setPrevModules(module.applications);
  };

  const handlePrevModule = (index, obj) => {
    const result = prevModule.map((ele, i) => {
      if (index === i) {
        if (Object.keys(obj)[0] == 'classificationAccesses') {
          if (ele.classificationAccesses !== null) {
            ele.classificationAccesses.push(obj.classificationAccesses);
            return { ...ele };
          } else {
            return { ...ele, classificationAccesses: [obj.classificationAccesses] };
          }
        } else {
          return { ...ele, ...obj };
        }
      } else {
        return ele;
      }
    });
    setPrevModule(result);
  };

  const deleteModule = async (userId, moduleId) => {
    await removeModule(userId, { removeModules: [moduleId] });
    fetchUsers(labs);
  };

  const handleEditModal = () => {
    setShowEditUserRedCrescent(false);
  };

  const handleEditData = () => {
    setEditModuleData({});
  };
  const handleSetModule = (obj) => {
    setModuleType(obj);
  };
  const handleLabType = (val) => {
    setLabType(val);
  };
  const handleRegionsByLabType = (val) => {
    setRegionsByLabType(val);
  };

  const handleSelectedRegion = (val) => {
    setSelectedRegionName(val);
  };
  const handleSelectedLocation = (val) => {
    setSelectedLocationName(val);
  };

  return (
    <div>
      <div style={{ textAlign: 'end' }}>
        <Button onClick={() => setShowModal(true)} type="primary" style={{ marginBottom: 16 }}>
          Add User
        </Button>
      </div>

      <ShowTable
        users={users}
        deleteUser={removeUser}
        editModule={editModule}
        deleteModule={deleteModule}
      />

      <EditUserRedCrescent
        labs={labs}
        showEditModal={showEditUserRedCrescent}
        handleEditModal={handleEditModal}
        regions={regions}
        locations={locations}
        editModuleData={editModuleData}
        handleEditData={handleEditData}
        moduleType={moduleType}
        handleSetModule={handleSetModule}
        fetchUsers={fetchUsers}
        length={moduleLength}
        prevModule={prevModule}
        prevModuleType={prevModuleType}
        handlePrevModule={handlePrevModule}
        prevModules={prevModules}
        categories={categories}
        getClassification={getClassification}
        currentUser={currentUser}
      />

      <Modal
        width="750px"
        title="Add User Modal"
        visible={showModal}
        destroyOnClose={true}
        onCancel={() => {
          setLabType({});
          setSelectedLocationName({});
          setSelectedRegionName({});
          setShowModal(false);
        }}
        footer={null}
        maskClosable={false}
      >
        <AddUserFormRedCrescent
          labs={labs}
          handleSubmit={handleSubmit}
          labType={labType}
          loading={loading}
          regionsByLabtype={regionsByLabtype}
          regions={regions}
          handleLabType={handleLabType}
          locations={locations}
          handleRegionsByLabType={handleRegionsByLabType}
          handleSelectedRegion={handleSelectedRegion}
          handleSelectedLocation={handleSelectedLocation}
          selectedLocationName={selectedLocationName}
          selectedRegionName={selectedRegionName}
          categories={categories}
          getClassification={getClassification}
          currentUser={currentUser}
        />
      </Modal>
    </div>
  );
};
export default connect(({ userModal }: { userModal: StateType }) => ({
  formContent: userModal.formContent,
}))(UserListComponent);

import React, { useState } from 'react';
import { Table, Space, Badge, Typography, Popconfirm, Tooltip, Button } from 'antd';
import { EditOutlined, DeleteOutlined } from '@ant-design/icons';
import { ModuleTypes, Role } from '../Types';

function ShowTable(props) {
  const { users, editModule, deleteUser, deleteModule } = props;
  const [expandedRowId, setExpandedRowId] = useState([]);
  const { Text } = Typography;

  const handleExpand = (id) => {
    if (id === expandedRowId[0]) {
      setExpandedRowId([]);
    } else {
      setExpandedRowId([id]);
    }
  };
  const expandedRowRender = (id) => {
    const columns = [
      {
        title: 'Module',
        dataIndex: 'name',
        key: 'name',
        render: (text: string, record) => (
          <Space>
            <Badge status={record.default && 'success'} />
            <Text>{ModuleTypes[text]}</Text>
          </Space>
        ),
      },

      {
        title: 'Role',
        dataIndex: 'role',
        key: 'role',
        render: (text: string) => <Text>{Role[text]}</Text>,
      },

      {
        title: 'Location',
        dataIndex: 'locationName',
        key: 'locationName',
      },

      {
        title: 'Action',
        dataIndex: 'operation',
        key: 'operation',
        render: (text, record) =>
          record.default === 0 &&
          record.role !== 'superAdmin' && (
            <Popconfirm
              title="Sure to delete?"
              onConfirm={() => deleteModule(record.userId, record.id)}
            >
              <Tooltip title="Delete Module">
                <Button type="primary" shape="circle" icon={<DeleteOutlined />} />
              </Tooltip>
            </Popconfirm>
          ),
      },
    ];
    const data = [];
    users
      ?.filter((item) => id == item.id)[0]
      .applications?.forEach((element) => {
        data.push(element);
      });

    return <Table columns={columns} dataSource={data} pagination={false} loading={false} />;
  };

  const columns = [
    { title: 'Name', dataIndex: 'name', key: 'name' },
    { title: 'Email', dataIndex: 'email', key: 'email' },
    {
      title: 'Action',
      dataIndex: 'operation',
      key: 'operation',
      render: (text, record) =>
        record.role !== 'superAdmin' && (
          <Space>
            <Popconfirm title="Sure to delete?" onConfirm={() => deleteUser(record.id)}>
              <Tooltip title="Delete User">
                <Button type="primary" shape="circle" icon={<DeleteOutlined />} />
              </Tooltip>
            </Popconfirm>
            <Tooltip title="Add Module">
              <Button
                type="primary"
                shape="circle"
                icon={<EditOutlined />}
                onClick={() => editModule(record)}
              />
            </Tooltip>
          </Space>
        ),
    },
  ];

  return (
    <>
      <Table
        columns={columns}
        dataSource={users}
        onExpand={(expanded, record) => handleExpand(record.id)}
        expandedRowRender={(record) => expandedRowRender(record.id)}
        rowKey={(record) => record.id}
        expandedRowKeys={expandedRowId}
      />
    </>
  );
}
export default ShowTable;

import React, { useState } from 'react';
import { Button, Form, Input, Select, Col, Radio, Row, Divider } from 'antd';
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import { ModuleTypes, roleByModule } from '../../Types';
import styles from '../../UserContainer/index.less';
import { UserManagementRoles } from '@/services/Constants';

const AddUserFormRedCrescent = (props) => {
  const {
    labs,
    handleSubmit,
    labType,
    loading,
    regionsByLabtype,
    handleLabType,
    locations,
    handleRegionsByLabType,
    handleSelectedLocation,
    selectedLocationName,
    categories,
    getClassification,
    currentUser,
  } = props;
  const [selectedRole, setSelectedRole] = useState({});

  const [form] = Form.useForm();
  let regionArrray: any[] = [];

  const children = categories.map((ele) => {
    return <Option key={ele}>{ele}</Option>;
  });

  return (
    <div>
      <Form
        layout="vertical"
        form={form}
        initialValues={{ name: '', email: '', role: '', locationId: '' }}
        preserve={false}
        onFinish={handleSubmit}
      >
        <Form.Item
          label="Name"
          name="name"
          rules={[{ required: true, message: 'Please input your name!' }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Email"
          name="email"
          rules={[
            { required: true, message: 'Please input your email!' },
            { type: 'email', message: 'Please enter a valid email!' },
          ]}
        >
          <Input type="email" />
        </Form.Item>

        <div>
          <Form.List name="modules">
            {(fields, { add, remove }) => {
              return (
                <>
                  {fields.map((field, index: number) => (
                    <div key={field.key} className={styles.formFieldContainer}>
                      <Row>
                        <Divider orientation="left">{`Module ${field.name + 1}`}</Divider>
                        <Col flex={1} span={12}>
                          <Form.Item
                            {...field}
                            label="Module"
                            name={[field.name, 'name']}
                            className={styles.formField}
                            rules={[{ required: true, message: 'Required' }]}
                          >
                            <Select
                              placeholder="Please Select"
                              onChange={(value) => {
                                getClassification(value);
                                handleLabType({
                                  ...labType,
                                  [field.name]: value,
                                });
                                regionArrray = locations
                                  .filter((loc: any) => loc.labType === value)
                                  .map((item: any, index) => {
                                    return item.regionId;
                                  });
                                const uniqueSet = [...new Set(regionArrray)];

                                handleRegionsByLabType({
                                  ...regionsByLabtype,
                                  [value]: uniqueSet,
                                });

                                form.resetFields([
                                  ['users', index, 'role'],
                                  ['users', index, 'regionId'],
                                  ['users', index, 'locationId'],
                                ]);
                              }}
                            >
                              {labs.map((item: any, index) => (
                                <Select.Option
                                  key={index}
                                  value={item}
                                  disabled={Object.values(labType)?.includes(item) ? true : false}
                                >
                                  {ModuleTypes[item]}
                                </Select.Option>
                              ))}
                            </Select>
                          </Form.Item>
                        </Col>
                        <Col span={12}>
                          <Form.Item
                            {...field}
                            label="Role"
                            name={[field.name, 'role']}
                            className={styles.formField}
                            rules={[{ required: true, message: 'Required' }]}
                          >
                            <Select
                              placeholder="Please Select"
                              onChange={(value) => {
                                setSelectedRole({
                                  ...selectedRole,
                                  [field.name]: value,
                                });
                                form.resetFields([
                                  ['users', index, 'regionId'],
                                  ['users', index, 'locationId'],
                                ]);
                              }}
                            >
                              {labType[index]?.length > 1 &&
                              currentUser.role === UserManagementRoles.REGION_ADMIN
                                ? Object.entries(roleByModule[labType[index]]).map(
                                    (item, index) => (
                                      <Select.Option key={index} value={item[0]}>
                                        {item[1]}
                                      </Select.Option>
                                    ),
                                  )
                                : labType[index]?.length > 1 && (
                                    <>
                                      {Object.entries(roleByModule[labType[index]]).map(
                                        (item, index) => (
                                          <Select.Option key={index} value={item[0]}>
                                            {item[1]}
                                          </Select.Option>
                                        ),
                                      )}
                                      <Select.Option key="regionAdmin" value="regionAdmin">
                                        {'Region Admin'}
                                      </Select.Option>
                                    </>
                                  )}
                            </Select>
                          </Form.Item>
                        </Col>
                      </Row>
                      <Row>
                        {selectedRole[field.name] === 'storeKeeper' && (
                          <Col flex={1} span={10}>
                            <Form.Item
                              {...field}
                              label="Category"
                              name={[field.name, 'classificationAccesses']}
                              className={styles.formField}
                              rules={[{ required: true, message: 'Required' }]}
                            >
                              <Select
                                mode="multiple"
                                placeholder="Please Select"
                                onChange={(value) => {
                                  form.resetFields([['users', index, 'locationId']]);
                                }}
                              >
                                {children}
                              </Select>
                            </Form.Item>
                          </Col>
                        )}
                        <Col flex={1} span={10}>
                          <Form.Item
                            {...field}
                            label="Location"
                            name={[field.name, 'locationId']}
                            rules={[{ required: true, message: 'Required' }]}
                          >
                            <Select
                              placeholder="Please Select"
                              onChange={(value, details) => {
                                handleSelectedLocation({
                                  ...selectedLocationName,
                                  [field.name]: details.children,
                                });
                              }}
                            >
                              {currentUser.role === UserManagementRoles.REGION_ADMIN ? (
                                <Select.Option
                                  key={currentUser?.locationId}
                                  value={currentUser?.locationId}
                                >
                                  {currentUser?.locationName}
                                </Select.Option>
                              ) : (
                                locations
                                  .filter((loc: any) => loc.labType === 'medicalredcrescent')
                                  .map((item: any) => (
                                    <Select.Option key={item.id} value={item.id}>
                                      {item.name}
                                    </Select.Option>
                                  ))
                              )}
                            </Select>
                          </Form.Item>
                        </Col>

                        <Col flex={1} span={4}>
                          <MinusCircleOutlined
                            onClick={() => {
                              remove(field.name);
                              delete labType[field.name];
                              const obj = {};
                              let count = 0;
                              for (const key in labType) {
                                obj[count] = labType[key];
                                count++;
                              }
                              handleLabType({ ...obj });
                            }}
                          />
                        </Col>
                      </Row>
                    </div>
                  ))}
                  <Form.Item>
                    <Button
                      type="dashed"
                      onClick={() => {
                        add();
                      }}
                      block
                      icon={<PlusOutlined />}
                    >
                      Add Module
                    </Button>
                  </Form.Item>
                </>
              );
            }}
          </Form.List>
          <Form.Item
            label="Default Module"
            name="default"
            className={styles.formField}
            rules={[{ required: true, message: 'Required' }]}
          >
            <Radio.Group name="default">
              {Object.values(labType).map((item, index) => (
                <Radio key={index} value={item}>
                  {ModuleTypes[item]}
                </Radio>
              ))}
            </Radio.Group>
          </Form.Item>
        </div>

        <Row>
          <Col flex={4} />
          <Col flex={4}>
            <Form.Item>
              <Button type="primary" htmlType="submit" loading={loading} block>
                Submit
              </Button>
            </Form.Item>
          </Col>
          <Col flex={4} />
        </Row>
      </Form>
    </div>
  );
};
export default AddUserFormRedCrescent;

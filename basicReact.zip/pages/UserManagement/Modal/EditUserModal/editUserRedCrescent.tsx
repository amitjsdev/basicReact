import React, { useState, useEffect } from 'react';
import { Button, Form, Modal, Input, Select, Col, Row, message, Divider } from 'antd';
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import { useForm } from 'antd/lib/form/Form';
import { ModuleTypes, roleByModule } from '../../Types';
import { editUserModule } from '../../userManagement.services';
import { getClassifications } from '../../userManagement.services';
import styles from '../../UserContainer/index.less';
import { UserManagementRoles } from '@/services/Constants';

const EditUserRedCrescent = (props) => {
  const {
    showEditModal,
    handleEditModal,
    categories,
    locations,
    editModuleData,
    moduleType,
    handleSetModule,
    fetchUsers,
    length,
    prevModule,
    prevModuleType,
    handlePrevModule,
    prevModules,
    labs,
    getClassification,
    currentUser,
  } = props;
  let [prevRegionsByLabtype, setPrevRegionsByLabType] = useState({});
  const [regionsByLabtype, setRegionsByLabType] = useState({});
  const [selectedLocationName, setSelectedLocationName] = useState({});
  const [selectedRegionName, setSelectedRegionName] = useState({});
  const [loading, setLoading] = useState(false);
  const [selectedRole, setSelectedRole] = useState({});
  const [classification, setClassification] = useState({});

  const [form] = useForm();

  let regionArrray: any[] = [];

  const uniqueCategory = (val) => {
    const category = val.map((ele) => ele.category);
    const uniqueVal = _.uniqBy(category);
    return uniqueVal;
  };

  const fetchCategories = async () => {
    let lab = 'medicalredcrescent';
    const data1 = await getClassifications(lab);
    const medicalCategories = uniqueCategory(data1);
    classification['medicalredcrescent'] = medicalCategories;

    lab = 'nonmedicalredcrescent';
    const data2 = await getClassifications(lab);
    const nonmedicalCategories = uniqueCategory(data2);
    classification['nonmedicalredcrescent'] = nonmedicalCategories;
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const handleSubmit = async (values) => {
    setLoading(true);
    const x = values?.applications?.map((list, index) => {
      return {
        ...list,
        locationName: selectedLocationName[index],
        default: false,
      };
    });
    const updatedModules = [];
    let defaultModuleId = '';

    const y = values?.prevApplications?.forEach((module, index) => {
      const loc = locations.filter((loc) => loc.labType === 'medicalredcrescent');
      const locObj = loc.filter((ele) => ele.name === module.locationName);

      if (prevModules[index]?.default == 1) {
        defaultModuleId = prevModules[index]?.id;
      }
      if (module.role === 'storeKeeper') {
        updatedModules.push({
          id: prevModules[index]?.id,
          locationName: module.locationName,
          locationId: locObj[0]?.id,
          role: module.role,
          name: prevModules[index]?.name,
          classificationAccesses: module.classificationAccesses,
        });
      } else {
        updatedModules.push({
          id: prevModules[index]?.id,
          locationName: module.locationName,
          locationId: locObj[0]?.id,
          role: module.role,
          name: prevModules[index]?.name,
        });
      }
    });
    let payload = {};
    if (updatedModules && x) {
      payload = {
        defaultModuleId,
        updateModules: [...updatedModules, ...x],
      };
    } else if (updatedModules) {
      payload = {
        defaultModuleId,
        updateModules: [...updatedModules],
      };
    } else {
      payload = {
        defaultModuleId,
        updateModules: [...x],
      };
    }
    const openMessage = () => {
      message.loading({ content: 'Updating...', key: 'update' });
      setTimeout(() => {
        message.success({ content: 'Updated Successfully!', key: 'update', duration: 3 });
      }, 1000);
    };
    try {
      await editUserModule(editModuleData.id, payload)
        .then(() => {
          openMessage();
          handleEditModal(false);
          setLoading(false);
          handleSetModule({});
          setSelectedRegionName({});
          setSelectedLocationName({});
          setRegionsByLabType({});
          form.resetFields();
          fetchUsers(labs);
        })
        .catch(() => {
          alert('something went wrong');
        });
    } catch (error) {
      setLoading(false);
      handleEditModal(false);
      alert(error.message);
    }
  };

  const children = categories.map((ele) => {
    return <Option key={ele}>{ele}</Option>;
  });

  const FormFields = (props) => {
    const { application, index } = props;
    const regionArray = locations.filter((loc) => loc.labType === application.name);
    const regionIdArray = regionArray.map((element) => element.regionId);
    prevRegionsByLabtype = { ...prevRegionsByLabtype, [application.name]: regionIdArray };

    const editoption = classification[application.name]?.map((ele) => {
      return (
        <Option key={ele} disabled={application?.classificationAccesses?.includes(ele)}>
          {ele}
        </Option>
      );
    });

    return (
      <div key={index}>
        <Row>
          <Divider orientation="left">{`Module ${index + 1}`}</Divider>
          <Col flex={1}>
            <Form.Item
              label="Module"
              name={[index, 'name']}
              fieldKey={[index, 'name']}
              className={styles.formField}
              initialValue={application?.name}
            >
              <Select disabled>{}</Select>
            </Form.Item>
          </Col>
          <Col flex={1}>
            <Form.Item
              label="Role"
              name={[index, 'role']}
              fieldKey={[index, 'role']}
              className={styles.formField}
              initialValue={application?.role}
              rules={[{ required: true, message: 'Required' }]}
            >
              <Select
                value={application?.role}
                onChange={(value) => handlePrevModule(index, { role: value })}
              >
                {prevModuleType[index]?.length > 1 &&
                currentUser.role === UserManagementRoles.REGION_ADMIN
                  ? Object.entries(roleByModule[prevModuleType[index]])?.map((item, index) => (
                      <Select.Option key={index} value={item[0]}>
                        {item[1]}
                      </Select.Option>
                    ))
                  : prevModuleType[index]?.length > 1 && (
                      <>
                        {Object.entries(roleByModule[prevModuleType[index]]).map((item, index) => (
                          <Select.Option key={index} value={item[0]}>
                            {item[1]}
                          </Select.Option>
                        ))}
                        <Select.Option key="regionAdmin" value="regionAdmin">
                          {'Region Admin'}
                        </Select.Option>
                      </>
                    )}
              </Select>
            </Form.Item>
          </Col>
          {application?.role === 'storeKeeper' && (
            <Col flex={1}>
              <Form.Item
                label="Category"
                name={[index, 'classificationAccesses']}
                fieldKey={[index, 'category']}
                className={styles.formField}
                initialValue={
                  prevModuleType[index]?.length > 1 ? application?.classificationAccesses : []
                } //changes required
                rules={[{ required: true, message: 'Required' }]}
              >
                <Select
                  mode="multiple"
                  placeholder="Please Select"
                  onSelect={(value) => {
                    handlePrevModule(index, { classificationAccesses: value });
                  }}
                >
                  {editoption}
                </Select>
              </Form.Item>
            </Col>
          )}

          <Col flex={1}>
            <Form.Item
              label="Location"
              name={[index, 'locationName']}
              initialValue={application?.locationName}
              rules={[{ required: true, message: 'Required' }]}
            >
              <Select
                value={application?.locationName}
                onChange={(value) => handlePrevModule(index, { locationName: value })}
              >
                {currentUser.role === UserManagementRoles.REGION_ADMIN ? (
                  <Select.Option key={currentUser?.locationId} value={currentUser?.locationId}>
                    {currentUser?.locationName}
                  </Select.Option>
                ) : (
                  locations
                    .filter((loc: any) => loc.labType === 'medicalredcrescent')
                    .map((item: any, index) => (
                      <Select.Option key={index} value={item.name}>
                        {item.name}
                      </Select.Option>
                    ))
                )}
              </Select>
            </Form.Item>
          </Col>
        </Row>
      </div>
    );
  };

  return (
    <div>
      <Modal
        width="750px"
        title="Edit Module"
        visible={showEditModal}
        destroyOnClose={true}
        onCancel={() => {
          handleEditModal();
        }}
        footer={null}
        maskClosable={false}
      >
        <div>
          <Form
            layout="vertical"
            form={form}
            onFinish={handleSubmit}
            initialValues={{ name: editModuleData.name, email: editModuleData.email }}
            preserve={false}
          >
            <Form.Item label="Name" name="name">
              <Input disabled placeholder={editModuleData.name} />
            </Form.Item>

            <Form.Item label="Email" name="email">
              <Input type="email" placeholder={editModuleData.email} disabled />
            </Form.Item>

            <div>
              <Form.List name="prevApplications">
                {() => {
                  return prevModule?.map((module, index) => {
                    return module ? (
                      <FormFields index={index} application={module} initialValue={module} />
                    ) : null;
                  });
                }}
              </Form.List>

              <Form.List name="applications">
                {(fields, { add, remove }) => {
                  return (
                    <>
                      {fields.map((field, index: number) => (
                        <div key={field.key} className={styles.formFieldContainer}>
                          <Row>
                            <Divider orientation="left">{`Module ${
                              field.name + length + 1
                            }`}</Divider>
                            <Col flex={1}>
                              <Form.Item
                                {...field}
                                label="Module"
                                name={[field.name, 'name']}
                                className={styles.formField}
                                rules={[{ required: true, message: 'Required' }]}
                              >
                                <Select
                                  placeholder="Please Select"
                                  onChange={(value) => {
                                    getClassification(value);
                                    handleSetModule({
                                      ...moduleType,
                                      [field.name + length]: value,
                                    });

                                    regionArrray = locations
                                      .filter((loc: any) => loc.labType === value)
                                      .map((item: any, index) => {
                                        return item.regionId;
                                      });
                                    const uniqueSet = [...new Set(regionArrray)];

                                    setRegionsByLabType({
                                      ...regionsByLabtype,
                                      [value]: uniqueSet,
                                    });
                                    form.resetFields([
                                      ['users', index + length, 'role'],
                                      ['users', index + length, 'regionId'],
                                      ['users', index + length, 'locationId'],
                                    ]);
                                  }}
                                >
                                  {labs.map((item: any, indx) => (
                                    <Select.Option
                                      key={indx}
                                      value={item}
                                      disabled={
                                        Object.values(moduleType)?.includes(item) ? true : false
                                      }
                                    >
                                      {ModuleTypes[item]}
                                    </Select.Option>
                                  ))}
                                </Select>
                              </Form.Item>
                            </Col>
                            <Col>
                              <Form.Item
                                {...field}
                                label="Role"
                                name={[field.name, 'role']}
                                className={styles.formField}
                                rules={[{ required: true, message: 'Required' }]}
                              >
                                <Select
                                  placeholder="Please Select"
                                  onChange={(value) => {
                                    setSelectedRole({
                                      ...selectedRole,
                                      [field.name + length]: value,
                                    });
                                    form.resetFields([
                                      ['users', index, 'regionId'],
                                      ['users', index, 'locationId'],
                                    ]);
                                  }}
                                >
                                  {moduleType[index + length]?.length > 1 &&
                                  currentUser.role === UserManagementRoles.REGION_ADMIN
                                    ? Object.entries(roleByModule[moduleType[index + length]]).map(
                                        (item, index) => (
                                          <Select.Option key={index} value={item[0]}>
                                            {item[1]}
                                          </Select.Option>
                                        ),
                                      )
                                    : moduleType[index + length]?.length > 1 && (
                                        <>
                                          {Object.entries(
                                            roleByModule[moduleType[index + length]],
                                          ).map((item, index) => (
                                            <Select.Option key={index} value={item[0]}>
                                              {item[1]}
                                            </Select.Option>
                                          ))}
                                          <Select.Option key="regionAdmin" value="regionAdmin">
                                            {'Region Admin'}
                                          </Select.Option>
                                        </>
                                      )}
                                </Select>
                              </Form.Item>
                            </Col>
                          </Row>
                          <Row>
                            {selectedRole[field.name + length] === 'storeKeeper' && (
                              <Col flex={1}>
                                <Form.Item
                                  {...field}
                                  label="Category"
                                  name={[field.name, 'category']}
                                  className={styles.formField}
                                  rules={[{ required: true, message: 'Required' }]}
                                >
                                  <Select
                                    mode="multiple"
                                    placeholder="Please Select"
                                    onChange={() => {
                                      form.resetFields([
                                        ['users', index + length, 'role'],
                                        ['users', index + length, 'regionId'],
                                        ['users', index + length, 'locationId'],
                                      ]);
                                    }}
                                  >
                                    {children}
                                  </Select>
                                </Form.Item>
                              </Col>
                            )}
                            <Col flex={1}>
                              <Form.Item
                                {...field}
                                label="Location"
                                name={[field.name, 'locationId']}
                                rules={[{ required: true, message: 'Required' }]}
                              >
                                <Select
                                  placeholder="Please Select"
                                  onChange={(value, details) => {
                                    setSelectedLocationName({
                                      ...selectedLocationName,
                                      [field.name]: details.children,
                                    });
                                  }}
                                >
                                  {currentUser.role === UserManagementRoles.REGION_ADMIN ? (
                                    <Select.Option
                                      key={currentUser?.locationId}
                                      value={currentUser?.locationId}
                                    >
                                      {currentUser?.locationName}
                                    </Select.Option>
                                  ) : (
                                    locations
                                      .filter((loc: any) => loc.labType === 'medicalredcrescent')
                                      .map((item: any) => (
                                        <Select.Option key={item.id} value={item.id}>
                                          {item.name}
                                        </Select.Option>
                                      ))
                                  )}
                                </Select>
                              </Form.Item>
                            </Col>

                            <Col flex={1}>
                              <MinusCircleOutlined
                                onClick={() => {
                                  remove(field.name);
                                  const obj = {};
                                  let count = 0;
                                  const result = Object.keys(moduleType);
                                  const ke = result.filter((ele, i) => i !== field.name + length);
                                  for (const key in moduleType) {
                                    if (ke[count] === key) {
                                      obj[count] = moduleType[key];
                                      count++;
                                    }
                                  }
                                  //handleSetModule({ ...obj })
                                }}
                              />
                            </Col>
                          </Row>
                          <hr />
                        </div>
                      ))}
                      <Form.Item>
                        <Button
                          type="dashed"
                          onClick={() => {
                            add();
                          }}
                          block
                          icon={<PlusOutlined />}
                        >
                          Add Module
                        </Button>
                      </Form.Item>
                    </>
                  );
                }}
              </Form.List>
            </div>

            <Row>
              <Col flex={4} />
              <Col flex={4}>
                <Form.Item>
                  <Button type="primary" htmlType="submit" loading={loading} block>
                    Submit
                  </Button>
                </Form.Item>
              </Col>
              <Col flex={4} />
            </Row>
          </Form>
        </div>
      </Modal>
    </div>
  );
};
export default EditUserRedCrescent;

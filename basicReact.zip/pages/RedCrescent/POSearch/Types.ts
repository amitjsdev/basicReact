interface ITicketsAutocomplete {
  dueDates: string[];
  externalTicketIds: string[];
  pointOfCollections: string[];
  priorities: string[];
}

interface ITableColumn {
  title: string;
  width?: string;
  dataIndex: string;
  key: string;
  fixed?: string;
  render?: any;
}

interface IPatient {
  appointmentDate: string;
  createdAt: string;
  id: number;
  lost: false;
  networkEfficiency: number;
  patientCode: string;
  patientName: string;
  pointOfCollection: string;
  regionId: number;
  sampleCollectionTime: string;
  sampleProcessTime: string;
  status: string;
  testingTime: number;
  timeforSampleCollection: number;
  turnAroundTime: number;
  type: string;
  updatedAt: string;
  uploadIdentifier: number;
}

export { ITicketsAutocomplete, ITableColumn, IPatient };

import React from 'react';
import { Table, Tag, Button, Typography, Tooltip, Modal, Row } from 'antd';
import { DownloadOutlined, ExclamationCircleTwoTone, FileDoneOutlined } from '@ant-design/icons';
import moment from 'moment';
import { connect, useModel, getLocale, FormattedMessage, formatMessage } from 'umi';

import { ITableColumn } from '../../Types';
import { DATE_FORMAT } from '../../Constants';
// import tmsService from '../../../services/tms.service';

import styles from './index.less';
import redcrescentService from '@/pages/RedCrescent/services/redcrescent.service';

const { Text } = Typography;

export default (props) => {
  const { category, results, date, currentLocation, labType } = props;

  const dateDiff = (_date) => {
    const today = new Date();
    const yday = new Date(_date);
    const _diff = (today.getTime() - yday.getTime()) / (1000 * 3600 * 24);
    return _diff;
  };

  const categoryWiseColumns = {
    columns: [
      {
        title: <FormattedMessage id="PurchaseOrderNumber" />,
        dataIndex: 'id',
        key: 'id',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        dataIndex: 'quantity',
        key: 'quantity',
      },

      {
        title: <FormattedMessage id="CreatedOn" />,
        key: 'createdAt',
        dataIndex: 'createdAt',
        render: (text, record) => {
          return getLocale().includes( 'en')
            ? moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
            : moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD');
        },
      },
      {
        title: <FormattedMessage id="ExpectedDelivery" />,
        dataIndex: 'expectedOn',
        key: 'expectedOn',
        render: (text, record, index) =>
          dateDiff(record.expectedOn) > 0 ? (
            <div>
              <ExclamationCircleTwoTone twoToneColor="#ff0000" />
              <Text>
                {getLocale().includes( 'en')
                  ? moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')
                  : moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')}
              </Text>
            </div>
          ) : (
            <Text>
              {getLocale().includes( 'en')
                ? moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')
                : moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')}
            </Text>
          ),
      },
      {
        title: <FormattedMessage id="Status" />,
        key: 'status',
        dataIndex: 'status',
        render: (text: any, record: any) => {
          return record.status === 'created' && record.isApproved === 1 ? (
            <Tag
              style={{
                textTransform: 'uppercase',
              }}
            >
              <FormattedMessage id="Approved" />
            </Tag>
          ) : (
            <Tag
              style={{
                textTransform: 'uppercase',
              }}
            >
              {text ? formatMessage({ id: `${text.charAt(0).toUpperCase() + text.slice(1)}` }) : ''}
            </Tag>
          );
        },
      },
      {
        title: <FormattedMessage id="Actions" />,
        key: 'action',
        render: (text, record, index) => {
          return record.status !== 'created' && record.status !== 'cancelled' ? (
            <div style={styles.actions}>
              <Button
                type="primary"
                style={styles.actionButton}
                onClick={() => downloadPO(record.id)}
              >
                <DownloadOutlined />
              </Button>
            </div>
          ) : (
            <div style={styles.actions}>
              <Button disabled={true} style={styles.actionButton}>
                <DownloadOutlined />
              </Button>
            </div>
          );
        },
      },
    ],

    columns1: [
      {
        title: <FormattedMessage id="PurchaseOrderNumber" />,
        dataIndex: 'id',
        key: 'id',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="CreatedOn" />,
        key: 'createdAt',
        dataIndex: 'createdAt',
        render: (text, record) => {
          return getLocale().includes( 'en')
            ? moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
            : moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD');
        },
      },
      {
        title: <FormattedMessage id="Description" />,
        key: getLocale() === 'ar-EG' ? 'arabicDescription' : 'description',
        dataIndex: getLocale() === 'ar-EG' ? 'arabicDescription' : 'description',
      },

      {
        title: <FormattedMessage id="ExpectedDelivery" />,
        dataIndex: ['purchaseOrder', 'expectedDeliveryDate'],
        key: ['purchaseOrder', 'expectedDeliveryDate'],
        render: (text, record) => {
          return getLocale().includes( 'en')
            ? moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
            : moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD');
        },
      },
      {
        title: <FormattedMessage id="Status" />,
        key: ['purchaseOrder', 'status'],
        dataIndex: ['purchaseOrder', 'status'],
        render: (text: any, record: any) => {
          return record?.purchaseOrder?.status === 'created' &&
            record?.purchaseOrder?.isApproved === 1 ? (
            <Tag
              style={{
                textTransform: 'uppercase',
              }}
            >
              <FormattedMessage id="Approved" />
            </Tag>
          ) : (
            <Tag
              style={{
                textTransform: 'uppercase',
              }}
            >
              {text ? formatMessage({ id: `${text.charAt(0).toUpperCase() + text.slice(1)}` }) : ''}
            </Tag>
          );
        },
      },
    ],
    nestedColumns: [
      {
        title: <FormattedMessage id="Code" />,
        width: '200px',
        dataIndex: 'productCode',
        key: 'productCode',
      },
      {
        title: <FormattedMessage id="Description" />,
        width: '200px',
        dataIndex: getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : 'description',
        key: 'description',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        width: '150px',
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        width: '150px',
        dataIndex: 'updatedAt',
        key: 'updatedAt',
        render: (text, record) =>
          getLocale().includes( 'en')
            ? moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
      {
        title: <FormattedMessage id="CreatedAt" />,
        width: '150px',
        dataIndex: 'createdAt',
        key: 'createdAt', // moment(batch.manufactureDate).format(dateFormat)
        render: (text, record) =>
          getLocale().includes( 'en')
            ? moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
    ],

    nestedPendingColumns: [
      {
        title: <FormattedMessage id="Code" />,
        width: '200px',
        dataIndex: 'productCode',
        key: 'productCode',
      },
      {
        title: <FormattedMessage id="Description" />,
        width: '200px',
        dataIndex: getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : 'description',
        key: 'description',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        width: '150px',
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="PendingQuantity" />,
        width: '150px',
        dataIndex: 'pendingQuantity',
        key: 'pendingQuantity',
      },
      {
        title: <FormattedMessage id="UpdatedAt" />,
        width: '150px',
        dataIndex: 'updatedAt',
        key: 'updatedAt',
        render: (text, record) =>
          getLocale().includes( 'en')
            ? moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
      {
        title: <FormattedMessage id="CreatedAt" />,
        width: '150px',
        dataIndex: 'createdAt',
        key: 'createdAt', // moment(batch.manufactureDate).format(dateFormat)
        render: (text, record) =>
          getLocale().includes( 'en')
            ? moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
    ],

    nestedInspectedColumns: [
      {
        title: <FormattedMessage id="Code" />,
        width: '200px',
        dataIndex: 'productCode',
        key: 'productCode',
      },
      {
        title: <FormattedMessage id="Description" />,
        width: '200px',
        dataIndex: getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : 'description',
        key: 'description',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        width: '150px',
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="PendingQuantity" />,
        width: '150px',
        dataIndex: 'quarantineQuantity',
        key: 'quarantineQuantity',
      },
      {
        title: <FormattedMessage id="UpdatedAt" />,
        width: '150px',
        dataIndex: 'updatedAt',
        key: 'updatedAt',
        render: (text, record) =>
          getLocale().includes( 'en')
            ? moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
      {
        title: <FormattedMessage id="CreatedAt" />,
        width: '150px',
        dataIndex: 'createdAt',
        key: 'createdAt', // moment(batch.manufactureDate).format(dateFormat)
        render: (text, record) =>
          !getLocale() || getLocale().includes( 'en')
            ? moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
    ],
    GRNColumn: [
      {
        title: <FormattedMessage id="GRN" />,
        width: '100px',
        dataIndex: 'id',
        key: 'id',
      },
      {
        title: <FormattedMessage id="PurchaseOrderId" />,
        width: '100px',
        dataIndex: 'purchaseOrderId',
        key: 'purchaseOrderId',
      },
      {
        title: <FormattedMessage id="Description" />,
        width: '200px',
        dataIndex:
          getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : ['product', 'description'],
        key: 'purchaseOrderId',
      },
      {
        title: <FormattedMessage id="ReceivedQuantity" />,
        width: '100px',
        dataIndex: 'receivedQuantity',
        key: 'receivedQuantity',
      },
      {
        title: <FormattedMessage id="UpdatedAt" />,
        width: '100px',
        dataIndex: 'updatedAt',
        key: 'updatedAt',
        render: (text, record) =>
          getLocale().includes( 'en')
            ? moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
    ],
  };

  const downloadPO = async (id) => {
    await redcrescentService.downloadPO(id, currentLocation, labType);
  };

  const expandedRowRender = (nestedData, status) => {
    return status === 'created' || status === 'completed' ? (
      <Table
        columns={categoryWiseColumns['nestedColumns']}
        dataSource={nestedData}
        pagination={false}
      />
    ) : status === 'pending' ? (
      <Table
        columns={categoryWiseColumns['nestedPendingColumns']}
        dataSource={nestedData}
        pagination={false}
      />
    ) : (
      <Table
        columns={categoryWiseColumns['nestedInspectedColumns']}
        dataSource={nestedData}
        pagination={false}
      />
    );
  };

  return (
    <Row style={{ width: '100%' }}>
      {category === 'purchaseOrderIds' ? (
        <div className={styles.tableContainer}>
          <Table
            columns={categoryWiseColumns['columns']}
            dataSource={results}
            rowKey={(record) => record.id}
            expandedRowRender={(record) => expandedRowRender(record.orderItems, record.status)}
            pagination={false}
          />
        </div>
      ) : category === 'GRNIds' ? (
        <div className={styles.tableContainer}>
          <Table
            columns={categoryWiseColumns['GRNColumn']}
            dataSource={results}
            pagination={false}
          />
        </div>
      ) : (
        <>
          <div className={styles.heading}>
            {results[0]?.inventoryQuantity ? (
              <h1 className="qtyInHnad">
                <FormattedMessage id="QuantityInHand" /> - {results[0]?.inventoryQuantity}
              </h1>
            ) : (
              <h1 className="qtyInHnad">
                <FormattedMessage id="QuantityInHand" /> - 0
              </h1>
            )}
          </div>
          <div className={styles.tableContainer}>
            <Table
              columns={categoryWiseColumns['columns1']}
              dataSource={results}
              pagination={false}
            />
          </div>
        </>
      )}
    </Row>
  );
};

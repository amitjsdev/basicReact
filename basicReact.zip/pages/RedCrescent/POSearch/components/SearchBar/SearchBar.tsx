import React, { useState } from 'react';
import { Row, Col, Spin, Input, Select, AutoComplete } from 'antd';
import debounce from 'lodash.debounce';

import { getAutocompleteResults } from '../../services';
import { ITicketsAutocomplete } from '../../Types';
import { AutocompleteCategories, SearchCategoryNames } from '../../Constants';

import styles from './index.less';
import { getDirection, useIntl, getLocale } from 'umi';

const { Option } = Select;

export default (props) => {
  const { handleSearchResults, searchLocation, onLocationChange, labtype } = props;
  const [currentLocation, setCurrentLocation] = useState(286);
  const [value, setValue] = useState('');
  const [options, setOptions] = useState([]);
  const [isLoading, setLoading] = useState(false);

  const getRelatedSearchTerms = async (searchText, currentLocation, labtype) => {
    setLoading(true);
    const results: ITicketsAutocomplete = await getAutocompleteResults(
      searchText,
      currentLocation,
      labtype,
    );

    const parsedResults =
      results && Object.keys(results).length > 0
        ? Object.keys(results)
          ?.map((category) => {
            return {
              label: AutocompleteCategories[category],
              options: results[category].map((value) => ({ value, category: category })),
            };
          })
          .filter((category) => category.options.length)
        : [];
    setOptions(parsedResults);
    setLoading(false);
  };

  const handleSearch = debounce(getRelatedSearchTerms, 200);

  const handleLocationChange = (location) => {
    setCurrentLocation(location);
    onLocationChange(location);
    setOptions([]);
  };
  const clearSearchValue = () => {
    handleSearchResults('');
    setValue('');
    setOptions([]);
  };
  return (
    <div className={styles.container}>
      <Row gutter={[24, 24]} align="middle" justify="center">
        <Col>
          <Input.Group size="large">
            <Row>
              <Col span={8}>
                <Select
                  defaultValue={286}
                  style={{ width: 200 }}
                  onChange={(value) => handleLocationChange(value)}
                >
                  {searchLocation?.map((location) => (
                    <Option value={location.id}>{location.code}</Option>
                  ))}
                </Select>
              </Col>
              <Col span={16}>
                {getLocale() === 'ar-EG' && (
                  <button className={styles.close} onClick={clearSearchValue}>
                    X
                  </button>
                )}
                <AutoComplete
                  style={{ width: 400 }}
                  className={getDirection() === 'rtl' ? 'search-rtl' : ''}
                  options={options}
                  value={value}
                  direction={getDirection()}
                  onChange={(x, y, data) => {
                    setOptions([]);
                    setValue(x);
                    handleSearchResults('');
                  }}
                  onSearch={(searchText) => {
                    if (searchText && searchText.length >= 1)
                      handleSearch(searchText, currentLocation, labtype);
                  }}
                  onSelect={handleSearchResults}
                  notFoundContent={useIntl().formatMessage({ id: 'NoDataFound' })}
                  allowClear={getDirection() !== 'rtl'}
                />
              </Col>
            </Row>
          </Input.Group>
        </Col>
        <Col>
          <Spin spinning={isLoading} />
        </Col>
      </Row>
    </div>
  );
};

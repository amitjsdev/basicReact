import React, { useState, useEffect } from 'react';
import { Empty } from 'antd';

import moment from 'moment';
import SearchBar from './components/SearchBar/SearchBar';
import POSearchTable from './components/POSearchTable/POSearchTable';
import { getSearchResults } from './services';
import { SEARCH_CATEGORIES } from './Constants';

import styles from './index.less';
import PocDetails from './components/PocDetails/PocDetails';
import PatientDetails from './components/PatientDetails/PatientDetails';
import redcrescentService from '../services/redcrescent.service';
import { LabTypes } from '@/services/Constants';
import { getLocale } from 'umi';

const date = moment().format('L');
const SearchResults = (props) => {
  const { category, results, currentLocation, labType } = props;

  // const resultContainer = {
  //   purchaseOrderIds: <POSearchTable category={category} results={results} date={date} />,
  //   // poc: <PocDetails poc={poc} date={date} />,
  //   // 'patient-code': <PatientDetails patient={patient} date={date} />,
  // };

  // return resultContainer[category];
  return (
    <POSearchTable
      category={category}
      results={results}
      date={date}
      currentLocation={currentLocation}
      labType={labType}
    />
  );
};

export default () => {
  const [results, setResults] = useState([]);
  const [currentCategory, setCurrentCategory] = useState(SEARCH_CATEGORIES[0]);
  const [poc, setPoc] = useState();
  const [patientDetails, setPatientDetails] = useState();
  const [redcrescentLocation, setRedcrescentLocation] = useState();
  const [currentLocation, setCurrentLocation] = useState(286);
  const [labType, setLabType] = useState('');
  useEffect(() => {
    setLabType(window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC);

    redcrescentService.getLocations(LabTypes.MRC).then((loc: any) => {
      const locCodeAndId = loc.map(({ code, id }) => ({ code, id }));
      setRedcrescentLocation(locCodeAndId);
    });
  }, []);

  const handleLocationChange = (newlocation) => {
    setCurrentLocation(newlocation);
    setResults([]);
    setPoc(null);
    setPatientDetails(null);
  };

  const getResults = async (searchTerm, optionDetail) => {
    if (searchTerm !== '') {
      setCurrentCategory(optionDetail.category);

      const regionId = undefined;
      const searchResults = await getSearchResults(
        regionId,
        searchTerm,
        optionDetail.category,
        labType,
        currentLocation,
      );
      setResults(searchResults);
    } else {
      setResults([]);
    }

    // }
  };
  const clearData = () => {};
  return (
    <div className={styles.main}>
      <div className={styles.searchBarContainer}>
        <SearchBar
          labtype={labType}
          searchLocation={redcrescentLocation}
          handleSearchResults={getResults}
          onLocationChange={handleLocationChange}
        />
      </div>
      <div className={styles.resultContainer}>
        {results.length || poc || patientDetails ? (
          <SearchResults
            category={currentCategory}
            results={results}
            currentLocation={currentLocation}
            labType={labType}
          />
        ) : (
          <Empty />
        )}
      </div>
    </div>
  );
};

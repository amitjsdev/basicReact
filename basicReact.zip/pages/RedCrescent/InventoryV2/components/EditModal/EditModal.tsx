import React, { useState, useEffect } from 'react';
import { Select, Form, Input, InputNumber, Button, Row, Col, Modal, Tabs, DatePicker } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import redCrescentService from '../../../services/redcrescent.service';
import { useIntl, getLocale, formatMessage } from 'umi';
import moment from 'moment';
import styles from './index.less';
import { update } from 'lodash';

const BasicEditForm = (props) => {
  const { TabPane } = Tabs;
  const [form] = Form.useForm();
  const [formSubmit, setFormSubmit] = useState(false);
  const [newLocators, setNewLocators] = useState([]);
  const [updateLocators, setUpdateLocators] = useState([]);
  const [createLocators, setCreateLocators] = useState([]);
  const [createBatches, setCreateBtaches] = useState([]);
  const [warehouse, setWarehouse] = useState([]);
  const [newBatches, setNewBatches] = useState([]);
  const [showAddLocatorModal, setShowAddLocatorModal] = useState(false);
  const batchDetail = props.batches[0];
  const { currentDailyConsumption, locationId, isVisible } = props;
  const [subWareHouse, setSubWareHouse] = useState([]);
  const [bacthesSubWareHouse, setBacthesSubWareHouse] = useState([]);
  const [batchesWarehouse, setBatchesWarehouse] = useState([]);
  const { batches, id, editModalContent } = props;
  const dateFormat = 'YYYY-MM-DD';
  useEffect(() => {
    if (isVisible) {
      redCrescentService.getWareHouses('medicalredcrescent', locationId).then((data) => {
        setWarehouse(data);
        setBatchesWarehouse(data);
      });
    }
    // if (props.labType === 'nonmedicalredcrescent') {
    //   const locators = [];
    //   locators.push({ batchId: batches[0].batchId });

    //   setNewLocators(locators);
    // }
  }, [isVisible]);

  const onFinish = async (values) => {
    const { dailyConsumption } = values;
    let updatedLocators = updateLocators;
    let createdLocators = createLocators;
    let createdBatches = createBatches;

    updatedLocators.forEach(function (v) {
      delete v.index;
    });

    createdLocators.forEach(function (v) {
      delete v.index;
    });

    createdBatches.forEach(function (v) {
      delete v.index;
    });

    if (updatedLocators || createdLocators || createdBatches) {
      setFormSubmit(true);
      const dailyConsumptionPayload = {
        dailyConsumption: dailyConsumption,
        productId: editModalContent?.productId,
        locationId: editModalContent?.locationId,
        inventoryId: editModalContent?.id,
      };
      if (dailyConsumptionPayload) {
        await redCrescentService.updateDailyConsumption(dailyConsumptionPayload);
      }
      props.handleUpdateLocators({
        updateLocators: updatedLocators,
        createLocators: createdLocators,
        createBatches: createdBatches,
      });
    }

    setUpdateLocators([])
    setCreateBtaches([])
    setCreateLocators([])

  };
  const disabledPastDates = (current: any) => {
    // Can not select days after today
    return current && current < moment().add(1, 'days');
  };
  const handleChange = (value, index, type, item, updateType) => {
    let isnum = /^\d+$/.test(value);

    if (!isnum && type === 'quantity') {
      return
    }
    let arr = [];
    let finalType = type;
    let obj = {};

    if (type === 'quantity' && updateType === 'updateLocators') {
      arr = updateLocators.slice();
      let indexData = arr.findIndex((x) => x.index == index);

      if (indexData > -1) {
        obj = { ...arr[indexData] };
        const a = arr.splice(indexData, 1);
      } else {
        obj.index = index;
      }
      obj[finalType] = value;
      const subWarehouseId = item.subWarehouseId ? item.subWarehouseId : null;
      if (subWarehouseId != '' && subWarehouseId != null) {
        obj = {
          ...obj,
          id: item.id,
          mainWarehouseId: item.mainWarehouseId,
          subWarehouseId: item.subWarehouseId ? item.subWarehouseId : null,
          locatorId: item.locatorId,
        };
      } else {
        obj = {
          ...obj,
          id: item.id,
          mainWarehouseId: item.mainWarehouseId,
          locatorId: item.locatorId,
        };
      }
      arr.push(obj);
      setUpdateLocators(arr);
    }

    if (updateType === 'createLocators') {
      arr = [...createLocators];

      let indexData = arr.findIndex((x) => x.index == index);

      if (indexData > -1) {
        obj = arr[indexData];
      } else {
        obj.index = index;
      }

      obj[finalType] = value;

      obj = {
        ...obj,
        batchId: item.id,
      };
      if (indexData > -1) {
        arr[indexData] = obj;
      } else {
        arr.push(obj);
      }

      setCreateLocators(arr);

      if (type === 'mainWarehouseId') {
        if (arr[indexData] && arr[indexData].subWarehouseId) {
          delete arr[indexData].subWarehouseId;
        }
        let indexSub = subWareHouse.findIndex((subhouse) => subhouse.index == index);
        let sub = warehouse && warehouse.length > 0 && warehouse.find((item) => item.id == value);

        if (sub && sub.subWarehouses) {
          if (indexSub == -1) {
            setSubWareHouse([...subWareHouse, { index, value: sub.subWarehouses }]);
          } else {
            subWareHouse[indexSub] = { index, value: sub.subWarehouses };
          }
        } else {
          if (indexSub !== -1) {
            subWareHouse.splice(indexSub, 1);
          }
        }
      }
    }

    if (updateType === 'AddBatches') {
      arr = [...createBatches];

      let indexData = arr.findIndex((x) => x.index == index);

      if (indexData > -1) {
        obj = arr[indexData];
      } else {
        obj.index = index;
      }

      obj[finalType] = value;

      obj = {
        ...obj,
        batchId: item.id,
        inventoryId: item.inventoryId,
      };
      if (indexData > -1) {
        arr[indexData] = obj;
      } else {
        arr.push(obj);
      }

      setCreateBtaches(arr);

      if (type === 'mainWarehouseId') {
        if (arr[indexData] && arr[indexData].subWarehouseId) {
          delete arr[indexData].subWarehouseId;
        }
        let indexSub = bacthesSubWareHouse.findIndex((subhouse) => subhouse.index == index);
        let sub =
          batchesWarehouse &&
          batchesWarehouse.length > 0 &&
          batchesWarehouse.find((item) => item.id == value);

        if (sub && sub.subWarehouses) {
          if (indexSub == -1) {
            setBacthesSubWareHouse([...bacthesSubWareHouse, { index, value: sub.subWarehouses }]);
          } else {
            bacthesSubWareHouse[indexSub] = { index, value: sub.subWarehouses };
          }
        } else {
          if (indexSub !== -1) {
            bacthesSubWareHouse.splice(indexSub, 1);
          }
        }
      }
    }
  };
  const addLocator = (batch) => {
    let obj =
      props.labType === 'medicalredcrescent' ? { batchId: batch.batchId } : { batchId: batch.id };
    const locators = newLocators.slice();
    locators.push(obj);
    setNewLocators(locators);
    setShowAddLocatorModal(true);
  };

  const addNewBatch = () => {
    let obj = {};
    let arr = newBatches.slice();
    obj['inventoryId'] = id;
    obj['index'] = newBatches.length;
    arr.push(obj);

    setNewBatches(arr);
  };

  const onCancel = () => {
    props.handleCancel();
    setUpdateLocators([]);
    setCreateBtaches([]);
    setCreateLocators([]);
  };

  return (
    <>
      <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
        <div style={{ marginTop: '5px' }}>
          <Row gutter={[24, 24]}>
            <Col flex={1}>
              <Form.Item
                name="dailyConsumption"
                label={useIntl().formatMessage({ id: 'ActualDailyConsumption' })}
                rules={[
                  { required: true },
                  {
                    type: 'number',
                    min: 0,
                    message: useIntl().formatMessage({ id: 'PleaseEnterValidNumber' }),
                  },
                ]}
                initialValue={currentDailyConsumption}
              >
                <InputNumber style={{ width: '100%' }} precision={0} />
              </Form.Item>
            </Col>
          </Row>
          <Tabs type="card">
            {batches &&
              batches.length > 0 &&
              batches.map((batch, index) => {
                return (
                  <>
                    <TabPane
                      tab={
                        props.labType === 'medicalredcrescent'
                          ? batch.batchNumber
                          : formatMessage({ id: 'AddLocators' })
                      }
                      key={index}
                    >
                      {props.labType === 'medicalredcrescent' && (
                        <Row gutter={[24, 24]} align="middle">
                          <Col>
                            <Form.Item
                              label={formatMessage({
                                id: 'ExpiryDate',
                              })}
                            >
                              <Input
                                name="expiryDate"
                                // value={`${batch.expiryDate ? batch.expiryDate : ''}`}
                                value={
                                  batch.expiryDate
                                    ? getLocale().includes('en')
                                      ? moment(batch.expiryDate)
                                        .locale(getLocale())
                                        .format('YYYY-MM-DD')
                                      : moment(batch.expiryDate)
                                        .locale(getLocale())
                                        .format('YYYY-MM-DD')
                                    : ''
                                }
                              />
                            </Form.Item>
                          </Col>
                        </Row>
                      )}
                      {batch.items &&
                        batch.items.map((item, indexObj) => {
                          return (
                            <Row gutter={[24, 24]} align="middle">
                              <Col span={11}>
                                <Form.Item
                                  label={formatMessage({
                                    id: 'Locator',
                                  })}
                                  rules={[
                                    {
                                      required: true,
                                      message: useIntl().formatMessage({
                                        id: 'MissingLocatorId',
                                      }),
                                    },
                                  ]}
                                >
                                  <Input
                                    name="locatorId"
                                    value={`${!!item.mainWarehouseName ? `${item.mainWarehouseName}` : ''
                                      } ${!!item.subWarehouseName ? `${item.subWarehouseName}` : ''
                                      } ${!!item.locatorId ? `${item.locatorId}` : ''}`}
                                  />
                                </Form.Item>
                              </Col>
                              <Col span={11}>
                                <Form.Item
                                  label={useIntl().formatMessage({ id: 'Quantity' })}
                                  name={`quantity-${indexObj}${index}`}
                                  initialValue={item && item.quantity}
                                  rules={[
                                    {
                                      required: true,
                                      message: useIntl().formatMessage({ id: 'MissingQuantity' }),
                                    },
                                    {
                                      type: 'number',
                                      min: 1,
                                    },
                                  ]}
                                >
                                  <InputNumber
                                    placeholder={useIntl().formatMessage({ id: 'Quantity' })}
                                    style={{ width: '100%' }}
                                    value={item && item.quantity}
                                    defaultValue={item && item.quantity}
                                    onChange={(value) => {
                                      handleChange(
                                        value,
                                        `${indexObj}${index}`,
                                        'quantity',
                                        item,
                                        'updateLocators',
                                      );
                                    }}
                                  />
                                </Form.Item>
                              </Col>
                            </Row>
                          );
                        })}
                      {newLocators &&
                        newLocators.map((loc, locIndex) => {
                          return (
                            <>
                              <Row gutter={[24, 24]} align="middle">
                                <Col span={24}>
                                  <Form.Item
                                    label={useIntl().formatMessage({ id: `AddWarehouse` })}
                                    name={`ToWareHouse${index}${locIndex}`}
                                    rules={[
                                      {
                                        required: true,
                                        message: useIntl().formatMessage({
                                          id: 'MissingWareHouse',
                                        }),
                                      },
                                    ]}
                                  >
                                    <Select
                                      onChange={(value) => {
                                        handleChange(
                                          value,
                                          `${index}${locIndex}`,
                                          'mainWarehouseId',
                                          batch,
                                          'createLocators',
                                        );
                                      }}
                                    >
                                      {warehouse &&
                                        warehouse.length > 0 &&
                                        warehouse.map((house) => {
                                          return <Option value={house.id}>{house.name}</Option>;
                                        })}
                                    </Select>
                                  </Form.Item>
                                </Col>
                              </Row>

                              {subWareHouse && subWareHouse.length > 0 && (
                                <Row gutter={[24, 24]} align="middle">
                                  <Col span={24}>
                                    <Form.Item
                                      label={useIntl().formatMessage({ id: `SubWareHouse` })}
                                      name={`subWarehouseId${index}${locIndex}`}
                                      rules={[
                                        {
                                          required: true,
                                          message: useIntl().formatMessage({
                                            id: 'MissingWareHouse',
                                          }),
                                        },
                                      ]}
                                    >
                                      <Select
                                        onChange={(value) => {
                                          handleChange(
                                            value,
                                            `${index}${locIndex}`,
                                            'subWarehouseId',
                                            batch,
                                            'createLocators',
                                          );
                                        }}
                                      >
                                        {subWareHouse &&
                                          subWareHouse.length > 0 &&
                                          subWareHouse.map((sub) => {
                                            return (
                                              sub.index == `${index}${locIndex}` &&
                                              sub.value.map((s) => {
                                                return <option value={s.id}>{s.name}</option>;
                                              })
                                            );
                                          })}
                                      </Select>
                                    </Form.Item>
                                  </Col>
                                </Row>
                              )}
                              <Row gutter={[24, 24]} align="middle">
                                <Col span={11}>
                                  <Form.Item
                                    label={formatMessage({
                                      id: 'Locator',
                                    })}
                                    name={`locatorIdnew${index}${locIndex}`}
                                    rules={[
                                      {
                                        required: true,
                                        message: useIntl().formatMessage({
                                          id: 'MissingLocatorId',
                                        }),
                                      },
                                    ]}
                                  >
                                    <Input
                                      style={{ width: '100%' }}
                                      onChange={(value) => {
                                        handleChange(
                                          value.target.value,
                                          `${index}${locIndex}`,
                                          'locatorId',
                                          batch,
                                          'createLocators',
                                        );
                                      }}
                                    />
                                  </Form.Item>
                                </Col>
                                <Col span={11}>
                                  <Form.Item
                                    label={useIntl().formatMessage({ id: 'Quantity' })}
                                    name={`quantity${index}${locIndex}`}
                                    rules={[
                                      {
                                        required: true,
                                        message: useIntl().formatMessage({ id: 'MissingQuantity' }),
                                      },
                                      {
                                        type: 'number',
                                        min: 1,
                                      },
                                    ]}
                                  >
                                    <InputNumber
                                      placeholder={useIntl().formatMessage({
                                        id: 'Quantity',
                                      })}
                                      style={{ width: '100%' }}
                                      // defaultValue={item.quantity}
                                      onChange={(value) => {
                                        handleChange(
                                          value,
                                          `${index}${locIndex}`,
                                          'quantity',
                                          batch,
                                          'createLocators',
                                        );
                                      }}
                                    />
                                  </Form.Item>
                                </Col>
                              </Row>
                            </>
                          );
                        })}
                      <Button
                        className={styles.btnText}
                        type="dashed"
                        onClick={() => addLocator(batch)}
                        block
                      >
                        <PlusOutlined /> {useIntl().formatMessage({ id: 'AddLocators' })}
                      </Button>
                    </TabPane>
                  </>
                );
              })}

            {props.labType === 'medicalredcrescent' && (
              <TabPane tab={formatMessage({ id: 'AddBatch' })}>
                {newBatches &&
                  newBatches.map((batch, batchIndex) => {
                    return (
                      <>
                        <Row gutter={[24, 24]} align="middle">
                          <Col span={11}>
                            <Form.Item
                              label={formatMessage({
                                id: 'BatchNumber',
                              })}
                              name={`batchNumber${batchIndex}`}
                            >
                              <Input
                                onChange={(value) => {
                                  handleChange(
                                    value.target.value,
                                    `${batchIndex}`,
                                    'batchNumber',
                                    batch,
                                    'AddBatches',
                                  );
                                }}
                              />
                            </Form.Item>
                          </Col>
                          <Col span={11}>
                            <Form.Item
                              name={`expiryDate${batchIndex}`}
                              label={formatMessage({
                                id: 'ExpiryDate',
                              })}
                              rules={[
                                {
                                  required: true,
                                  message: formatMessage({ id: 'MissingExpiryDate' }),
                                },
                              ]}
                            // initialValue={updateModalData && moment(updateModalData?.expiryDate, dateFormat)}
                            >
                              <DatePicker
                                format={dateFormat}
                                disabledDate={disabledPastDates}
                                onChange={(value) =>
                                  handleChange(
                                    value,
                                    `${batchIndex}`,
                                    'expiryDate',
                                    batch,
                                    'AddBatches',
                                  )
                                }
                                style={{ width: '100%' }}
                              />
                            </Form.Item>
                          </Col>
                        </Row>
                        <Row gutter={[24, 24]} align="middle">
                          <Col span={24}>
                            <Form.Item
                              label={useIntl().formatMessage({ id: `Warehouse` })}
                              name={`mainWarehouseId${batchIndex}`}
                              rules={[
                                {
                                  required: true,
                                  message: useIntl().formatMessage({ id: 'MissingWareHouse' }),
                                },
                              ]}
                            >
                              <Select
                                onChange={(value) => {
                                  handleChange(
                                    value,
                                    `${batchIndex}`,
                                    'mainWarehouseId',
                                    batch,
                                    'AddBatches',
                                  );
                                }}
                              >
                                {batchesWarehouse &&
                                  batchesWarehouse.length > 0 &&
                                  batchesWarehouse.map((house) => {
                                    return <Option value={house.id}>{house.name}</Option>;
                                  })}
                              </Select>
                            </Form.Item>
                          </Col>
                        </Row>
                        {bacthesSubWareHouse && bacthesSubWareHouse.length > 0 && (
                          <Row gutter={[24, 24]} align="middle">
                            <Col span={24}>
                              <Form.Item
                                label={useIntl().formatMessage({ id: `Warehouse` })}
                                name={`subWarehouseId${batchIndex}`}
                                rules={[
                                  {
                                    required: true,
                                    message: useIntl().formatMessage({ id: 'MissingWareHouse' }),
                                  },
                                ]}
                              >
                                <Select
                                  onChange={(value) => {
                                    handleChange(
                                      value,
                                      `${batchIndex}`,
                                      'subWarehouseId',
                                      batch,
                                      'AddBatches',
                                    );
                                  }}
                                >
                                  {bacthesSubWareHouse &&
                                    bacthesSubWareHouse.length > 0 &&
                                    bacthesSubWareHouse.map((sub) => {
                                      return (
                                        sub.index == `${batchIndex}` &&
                                        sub.value.map((s) => {
                                          return <option value={s.id}>{s.name}</option>;
                                        })
                                      );
                                    })}
                                </Select>
                              </Form.Item>
                            </Col>
                          </Row>
                        )}
                        <Row gutter={[24, 24]} align="middle">
                          <Col span={11}>
                            <Form.Item
                              label={formatMessage({
                                id: 'Locator',
                              })}
                              name={`locatorId${batchIndex}`}
                              rules={[
                                {
                                  required: true,
                                  message: useIntl().formatMessage({
                                    id: 'MissingLocatorId',
                                  }),
                                },
                              ]}
                            >
                              <Input
                                onChange={(value) => {
                                  handleChange(
                                    value.target.value,
                                    `${batchIndex}`,
                                    'locatorId',
                                    batch,
                                    'AddBatches',
                                  );
                                }}
                              />
                            </Form.Item>
                          </Col>
                          <Col span={11}>
                            <Form.Item
                              label={useIntl().formatMessage({ id: 'Quantity' })}
                              name={`quantity${batchIndex}`}
                              rules={[
                                {
                                  required: true,
                                  message: useIntl().formatMessage({ id: 'MissingQuantity' }),
                                },
                                {
                                  type: 'number',
                                  min: 1,
                                },
                              ]}
                            >
                              <InputNumber
                                placeholder={useIntl().formatMessage({ id: 'Quantity' })}
                                onChange={(value) => {
                                  handleChange(
                                    value,
                                    `${batchIndex}`,
                                    'quantity',
                                    batch,
                                    'AddBatches',
                                  );
                                }}
                                style={{ width: '100%' }}
                              />
                            </Form.Item>
                          </Col>
                        </Row>
                      </>
                    );
                  })}
                <Button className={styles.btnText} type="dashed" onClick={addNewBatch} block>
                  <PlusOutlined /> {useIntl().formatMessage({ id: 'AddMore' })}
                </Button>
              </TabPane>
            )}
          </Tabs>
        </div>

        <Row gutter={[24, 24]}>
          <Col flex={1}>
            <Form.Item>
              {formSubmit ? (
                <Button
                  disabled={formSubmit}
                  type="primary"
                  htmlType="submit"
                  block
                  loading={formSubmit}
                >
                  {useIntl().formatMessage({ id: 'Apply' })}
                </Button>
              ) : (
                <Button disabled={formSubmit} type="primary" htmlType="submit" block>
                  {useIntl().formatMessage({ id: 'Apply' })}
                </Button>
              )}
            </Form.Item>
          </Col>
          <Col flex={1}>
            <Form.Item>
              <Button onClick={onCancel} block>
                {useIntl().formatMessage({ id: 'Cancel' })}
              </Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </>
  );
};

const EditModal = (props) => {
  const {
    skuDetails,
    skuBatchDetails,
    handleUpdateLocators,
    handleCancel,
    isVisible,
    labType,
    editModalContent,
  } = props;

  const title =
    getLocale() === 'ar-EG'
      ? skuDetails?.product?.arabicDescription
      : skuDetails?.product?.description || 'Edit';
  let batchDetails = skuBatchDetails;
  const onCancel = () => {
    props.handleCancel();
  };
  batchDetails ||= null;
  if (batchDetails) {
    return (
      <>
        {/* <Spin spinning={!isVisible} /> */}

        <Modal
          title={title}
          visible={isVisible}
          afterClose={() => handleCancel()}
          destroyOnClose
          closable={false}
          footer={false}
        >
          {/* {batchDetails && batchDetails.batches && batchDetails.batches.length > 0 ? ( */}
          <BasicEditForm
            batches={batchDetails?.batches || null}
            currentDailyConsumption={skuDetails.dailyConsumption}
            handleUpdateLocators={(updatedBatches) => handleUpdateLocators(updatedBatches)}
            handleCancel={() => handleCancel()}
            isVisible={isVisible}
            locationId={skuBatchDetails.locationId}
            labType={labType}
            id={skuBatchDetails.id}
            editModalContent={editModalContent}
          />
          {/* ) : (
            <p>
              {formatMessage({ id: 'MissingBatchNumber' })}
              <p>
                {' '}
                <Button style={{ marginTop: '14px' }} onClick={onCancel} block>
                  {useIntl().formatMessage({ id: 'Cancel' })}
                </Button>
              </p>
            </p>
          )} */}
        </Modal>
      </>
    );
  } else {
    return null;
  }
};

export default EditModal;

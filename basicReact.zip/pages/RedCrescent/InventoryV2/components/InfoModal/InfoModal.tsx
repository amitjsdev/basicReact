import React, { useState, useEffect } from 'react';
import {
  Select,
  Form,
  Input,
  InputNumber,
  Button,
  Row,
  Col,
  Modal,
  Tabs,
  DatePicker,
  Divider,
} from 'antd';

import { useIntl, getLocale, formatMessage } from 'umi';

const BasicInfoForm = (props) => {
  const { batches, batchCategory } = props;
  const onCancel = () => {
    props.handleCancel();
  };

  const { TabPane } = Tabs;
  return (
    <>
      <Form layout="vertical" name="basicEditForm">
        <div style={{ marginTop: '5px' }}>
          <Tabs type="card">
            {batchCategory &&
              batchCategory.map((batch, index) => {
                return (
                  <>
                    <TabPane tab={batch.batchNumber} key={index}>
                      {batch.warehouses &&
                        batch.warehouses.map((ware, wareIndex) => {
                          return (
                            <>
                              <Row gutter={[24, 24]} align="middle">
                                {/* <Col span={11}>
                              <Form.Item
                                label={formatMessage({
                                  id: 'WarehouseId',
                                })}

                              >
                                <Input
                                  name="WarehouseId"
                                  value={`${!!ware.mainWarehouseId ? `${ware.mainWarehouseId}` : ''}`}
                                />
                              </Form.Item>
                            </Col> */}
                                <Col span={22}>
                                  <Form.Item
                                    label={useIntl().formatMessage({ id: 'WareHouseName' })}
                                  >
                                    <Input
                                      placeholder={useIntl().formatMessage({ id: 'WareHouseName' })}
                                      style={{ width: '100%' }}
                                      value={`${
                                        !!ware.mainWarehouseName ? `${ware.mainWarehouseName}` : ''
                                      }`}
                                    />
                                  </Form.Item>
                                </Col>
                              </Row>
                              {ware.subwarehouses &&
                                ware.subwarehouses.map((sub, subIndex) => {
                                  return (
                                    <>
                                      {sub.subWarehouseName && (
                                        <Row gutter={[24, 24]} align="middle">
                                          {/* <Col span={11}>
                                          <Form.Item
                                            label={formatMessage({
                                              id: 'SubWarehouseId',
                                            })}
                                          >
                                            <Input
                                              name="SubWarehouseId"
                                              value={`${
                                                !!sub.subWarehouseId ? `${sub.subWarehouseId}` : ''
                                              }`}
                                            />
                                          </Form.Item>
                                        </Col> */}
                                          <Col span={22}>
                                            <Form.Item
                                              label={useIntl().formatMessage({
                                                id: 'SubWareHouseName',
                                              })}
                                            >
                                              <Input
                                                placeholder={useIntl().formatMessage({
                                                  id: 'SubWareHouseName',
                                                })}
                                                style={{ width: '100%' }}
                                                value={`${
                                                  !!sub.subWarehouseName
                                                    ? `${sub.subWarehouseName}`
                                                    : ''
                                                }`}
                                              />
                                            </Form.Item>
                                          </Col>
                                        </Row>
                                      )}
                                      {sub.locators &&
                                        sub.locators.map((loc, locIndex) => {
                                          return (
                                            <>
                                              <Row gutter={[24, 24]} align="middle">
                                                <Col span={11}>
                                                  <Form.Item
                                                    label={formatMessage({
                                                      id: 'Locator',
                                                    })}
                                                  >
                                                    <Input
                                                      name="Locator"
                                                      value={`${
                                                        !!loc.locatorId ? `${loc.locatorId}` : ''
                                                      }`}
                                                    />
                                                  </Form.Item>
                                                </Col>
                                                <Col span={11}>
                                                  <Form.Item
                                                    label={useIntl().formatMessage({
                                                      id: 'Quantity',
                                                    })}
                                                  >
                                                    <Input
                                                      placeholder={useIntl().formatMessage({
                                                        id: 'Quantity',
                                                      })}
                                                      style={{ width: '100%' }}
                                                      value={`${
                                                        !!loc.quantity ? `${loc.quantity}` : ''
                                                      }`}
                                                    />
                                                  </Form.Item>
                                                </Col>
                                              </Row>
                                            </>
                                          );
                                        })}
                                    </>
                                  );
                                })}
                              <Divider />
                            </>
                          );
                        })}
                    </TabPane>
                  </>
                );
              })}
            {/* {batches && batches.map((batch, index) => {
              return (
                <>
                  <TabPane tab={batch.batchNumber} key={index}>
                    {batch.items && batch.items.map((item, itemIndex) => {
                      return (
                        <Row gutter={[24, 24]} align="middle">
                          <Col span={11}>
                            <Form.Item
                              label={formatMessage({
                                id: 'locatorId',
                              })}

                              rules={[
                                {
                                  required: true,
                                  message: useIntl().formatMessage({
                                    id: 'MissingLocatorId',
                                  }),
                                },
                              ]}
                            >
                              <Input
                                name="locatorId"
                                value={`${!!item.locatorId ? `${item.locatorId}` : ''}`}
                              />
                            </Form.Item>
                          </Col>
                          <Col span={11}>
                            <Form.Item
                              label={useIntl().formatMessage({ id: 'Quantity' })}

                            >
                              <Input
                                placeholder={useIntl().formatMessage({ id: 'Quantity' })}
                                style={{ width: '100%' }}
                                value={item && item.quantity}

                              />
                            </Form.Item>
                          </Col>
                        </Row>
                      )
                    })}
                  </TabPane>

                </>
              )
            })} */}
          </Tabs>
        </div>
        <Row gutter={[24, 24]}>
          <Col flex={1}>
            <Form.Item>
              <Button onClick={onCancel} block>
                {useIntl().formatMessage({ id: 'Cancel' })}
              </Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </>
  );
};

const InfoModal = (props) => {
  const {
    skuDetails,
    skuBatchDetails,
    handleUpdateLocators,
    handleCancel,
    isVisible,
    labType,
  } = props;
  const [batchCategory, setBatchCategory] = useState([]);
  useEffect(() => {
    setBatchCategory([]);
    const batches = skuBatchDetails && skuBatchDetails.batches && skuBatchDetails.batches;
    let batchClassification = [];

    batches &&
      batches.map((batch) => {
        let obj = {};

        obj['batchNumber'] = batch.batchNumber;

        let warehouses = [];

        batch.items &&
          batch.items.map((item) => {
            let index = warehouses.findIndex(
              (warehouse, index) => item.mainWarehouseId == warehouse.mainWarehouseId,
            );

            if (index == -1) {
              let subwarehouses = [];
              batch.items &&
                batch.items.map((subw) => {
                  if (item.mainWarehouseId == subw.mainWarehouseId) {
                    let indexSub = subwarehouses.findIndex(
                      (sub, i) => item.subWarehouseId == sub.subWarehouseId,
                    );
                    if (indexSub == -1) {
                      subwarehouses.push({
                        subWarehouseId: item.subWarehouseId,
                        subWarehouseName: item.subWarehouseName,
                        locators: [],
                      });
                    }
                  }
                });
              batch.items &&
                batch.items.map((subw) => {
                  if (item.mainWarehouseId == subw.mainWarehouseId) {
                    let indexSub = subwarehouses.findIndex(
                      (sub, i) => item.subWarehouseId == sub.subWarehouseId,
                    );
                    if (indexSub != -1) {
                      let loc =
                        subwarehouses[indexSub].locators &&
                        subwarehouses[indexSub].locators.slice();
                      loc.push({ locatorId: subw.locatorId, quantity: subw.quantity });
                      subwarehouses[indexSub].locators = loc;
                    }
                  }
                });

              warehouses.push({
                mainWarehouseId: item.mainWarehouseId,
                mainWarehouseName: item.mainWarehouseName,
                subwarehouses: subwarehouses,
              });
            }
          });

        obj['warehouses'] = warehouses;
        // obj['warehouses']['subwarehouses'] = subwarehouses;

        batchClassification.push(obj);
      });

    setBatchCategory(batchClassification);
  }, [isVisible]);

  const title =
    getLocale() === 'ar-EG'
      ? skuDetails?.product?.arabicDescription
      : skuDetails?.product?.description || 'Edit';
  let batchDetails = skuBatchDetails && skuBatchDetails;
  const onCancel = () => {
    props.handleCancel();
  };
  batchDetails ||= null;
  if (batchDetails) {
    return (
      <>
        {/* <Spin spinning={!isVisible} /> */}

        <Modal
          title={title}
          visible={isVisible}
          afterClose={() => handleCancel()}
          destroyOnClose
          closable={false}
          footer={false}
        >
          {batchDetails && batchDetails.batches && batchDetails.batches.length > 0 ? (
            <BasicInfoForm
              batches={batchDetails?.batches || null}
              handleCancel={() => handleCancel()}
              isVisible={isVisible}
              locationId={skuBatchDetails.locationId}
              labType={labType}
              id={skuBatchDetails.id}
              batchCategory={batchCategory}
            />
          ) : (
            <p>
              {formatMessage({ id: 'MissingBatchNumber' })}
              <p>
                {' '}
                <Button style={{ marginTop: '14px' }} onClick={onCancel} block>
                  {useIntl().formatMessage({ id: 'Cancel' })}
                </Button>
              </p>
            </p>
          )}
        </Modal>
      </>
    );
  } else {
    return null;
  }
};

export default InfoModal;
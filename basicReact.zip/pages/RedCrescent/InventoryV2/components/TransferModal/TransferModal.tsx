import React, { useEffect, useState } from 'react';
import { PlusOutlined } from '@ant-design/icons';
import {
  Form,
  Button,
  Row,
  Col,
  Modal,
  Select,
  Input,
  InputNumber,
  Tooltip,
  message,
  Spin,
  Radio,
} from 'antd';
import redCrescentService from '../../../services/redcrescent.service';
import styles from './index.less';
import { useIntl, getLocale, formatMessage } from 'umi';
import { text } from 'express';
import { LabTypes } from '@/services/Constants';
const { Option } = Select;

const BasicTransferForm = (props: any) => {
  const {
    selectedLocation,
    setSelectedLocation,
    locations,
    locationDetails,
    locationName,
    quantity,
    labType,
    selectedOrder,
    batchData,
    setdataArr,
    dataArr,
    data,
    setData,
    warehouse,
    subWarehouses,
    setsubWarehouses,
    type,
  } = props;
  const [isLoading, setIsLoading] = useState(false);
  const [formSubmit, setFormSubmit] = useState(false);
  const [locators, setLocators] = useState([]);

  const [form] = Form.useForm();
  const onFinish = (values: any) => {
    if (data && data.length > 0) {
      if (selectedLocation === '' && type == 'Transfer') {
        message.error(formatMessage({ id: 'PleaseChangeTheLocation' }));
      } else {
        let nonData = false;
        if (data && data.length > 0) {
          let total = 0;
          for (var i = 0; i < data.length; i++) {
            // let dataQty = selectedOrder.find(
            //   (dataItem) => dataItem.productId == data[i].productId,
            // );

            if (data[i].quantity.toString().length < 10) {
              nonData = false;
            } else {
              message.error(formatMessage({ id: 'QuantityShouldBeLessThan9Digits' }));
              return (nonData = true);

            }
          }
        }
        if (nonData) {
          message.error(formatMessage({ id: 'QuantityShouldBeLessThan9Digits' }));
        } else {
          let dataCheck = false;
          batchData &&
            batchData.length > 0 &&
            batchData.map((batch) => {
              let dataFind = data.filter((dataItem) => dataItem.batchId == batch.batchNumber);
              if (dataFind && dataFind.length > 0) {
                let total = 0;
                for (var i = 0; i < dataFind.length; i++) {
                  total += dataFind[i].quantity;
                }
                if (total > batch.quantity) {
                  return (dataCheck = true);
                }
              }
            });
          if (dataCheck) {
            message.error(formatMessage({ id: 'QuantityIsMoreThanBatchQuantity' }));
          } else {
            const quantityCheck = data.find((item) => isNaN(item.quantity) || item.quantity <= 0);
            if (quantityCheck) {
              message.error(formatMessage({ id: 'QuantityShouldBeNumericAndGreaterThan0' }));
            } else {
              const payload = {
                item: [...data],
                type,
              };
              if (type === 'Transfer') {
                var location = (locations || []).find((loc) => loc.id === locationDetails.id);
                payload.location = location;
                payload.labType = labType;
              }
              props.handleOk(payload);

              setIsLoading(true);
              setFormSubmit(true);
            }
          }
        }
      }
    } else {
      let wareHouseCheck = false;
      for (let i = 0; i < data.length; i++) {
        if (data[i]?.mainWarehouseId) {
        } else {
          wareHouseCheck = true;
        }
      }
      if (wareHouseCheck) {
        message.error(formatMessage({ id: 'MissingWareHouse' }));
      } else if (quantity.length == 0) {
        message.error(formatMessage({ id: 'PleaseEnterQuantity' }));
      } else {
        message.error(formatMessage({ id: 'PleaseSelectLocation' }));
      }
    }
  };

  const onCancel = () => {
    props.handleCancel();
  };

  const handleChange = (value, index, type, dataVal) => {
    let arr = [...data];
    let indexData = data.findIndex((x) => x.index == index);
    let obj = {};
    if (indexData > -1) {
      obj = { ...data[indexData] };
    } else {
      obj.index = index;
    }

    if (type === 'mainWarehouseId') {
      const tmpArr = value.split('__');
      const mainWarehouseId = tmpArr[0].split('main_')[1];
      const subWarehouseId = tmpArr[1].split('sub_')[1];
      const locatorId = tmpArr[2].split('loc_')[1];
      if (mainWarehouseId !== 'undefined') {
        obj[type] = mainWarehouseId;
      } else {
        obj[type] = null;
      }
      if (subWarehouseId !== 'undefined') {
        obj['subWarehouseId'] = subWarehouseId;
      } else {
        obj['subWarehouseId'] = null;
      }

      if (locatorId !== 'undefined') {
        obj['locatorId'] = locatorId;
      } else {
        obj['locatorId'] = null;
      }
    } else if (type === 'quantity') {
      var location = (locations || []).find((loc) => loc.id === selectedLocation);
      obj[type] = value;
      obj = {
        ...obj,
        labType,
        locationId: location.id,
        inventoryId: dataVal.inventoryId,
        productId: dataVal.productId,
        locationName: location.name,
        locationCode: location.code,
      };
    } else {
      obj[type] = value;
    }

    if (indexData > -1) {
      arr[indexData] = obj;
    } else {
      arr.push(obj);
    }

    setData(arr);
  };
  return (
    <>
      <Spin className={styles.loader} spinning={isLoading} size="large" />
      <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
        {type === 'Transfer' && (
          <Row gutter={[24, 24]}>
            <Col flex={1}>
              <Form.Item
                label={useIntl().formatMessage({ id: 'FromLocation' })}
                name={locationName}
                rules={[
                  {
                    required: true,
                    message: formatMessage({ id: 'PleaseChangeTheLocation' }),
                  },
                ]}
              >
                {locations && locations.length > 0 && (
                  <Select onChange={(value) => setSelectedLocation(value)}>
                    {locations &&
                      locations.map((location) => {
                        if (location.code == 'RIY' || location.code == 'DER') {
                          return (
                            <Option key={location.id} value={location.id}>
                              {getLocale().includes('en') ? location.name : location.arabicName}
                            </Option>
                          );
                        }
                      })}
                  </Select>
                )}
              </Form.Item>
            </Col>
          </Row>
        )}

        <div style={{ marginTop: '5px' }}>
          {selectedOrder &&
            selectedOrder.length > 0 &&
            selectedOrder.map((dataVal, index) => {
              const obj =
                dataArr &&
                dataArr.length > 0 &&
                dataArr.find((item) => item.id == dataVal.inventoryId);

              return (
                obj &&
                obj.dataLength.map((itemData, indexObj) => {
                  return (
                    <>
                      <div>
                        <Row gutter={[12, 12]} align="middle">
                          <Col span={11}>
                            <Form.Item label={useIntl().formatMessage({ id: 'Product' })}>
                              <Input
                                name="product"
                                value={
                                  getLocale() === 'ar-EG'
                                    ? dataVal.arabicDescription
                                    : dataVal.description
                                }
                              />
                            </Form.Item>
                          </Col>
                          <Col span={11}>
                            <Form.Item label={useIntl().formatMessage({ id: 'Code' })}>
                              <Input name="product" value={dataVal.code} />
                            </Form.Item>
                          </Col>
                        </Row>
                        {selectedLocation && (
                          <Row gutter={[24, 24]} align="middle">
                            <Col span={11}>
                              <Form.Item
                                label={useIntl().formatMessage({ id: 'Quantity' })}
                                name={`quantity${indexObj}${index}`}
                                rules={[
                                  {
                                    required: true,
                                    message: useIntl().formatMessage({ id: 'MissingQuantity' }),
                                  },
                                  {
                                    type: 'number',
                                    min: 1,
                                    message: 'Should be more than 0',
                                  },
                                ]}
                              >
                                <InputNumber
                                  placeholder="quantity"
                                  precision={0}
                                  style={{ width: '100%' }}
                                  onChange={(value) => {
                                    handleChange(value, `${indexObj}${index}`, 'quantity', dataVal);
                                  }}
                                />
                              </Form.Item>
                            </Col>
                          </Row>
                        )}
                      </div>
                      {/* {indexObj == obj.dataLength.length - 1 && (
                        <Button
                          className={styles.btnText}
                          type="dashed"
                          onClick={() => {
                            const indexData = dataArr.find(
                              (item) => item.id == dataVal.inventoryId,
                            );
                            let arr = [...dataArr];
                            let objData = { ...obj };
                            objData.dataLength.push([]);
                            arr[indexData] = objData;
                            setdataArr(arr);
                          }}
                          block
                        >
                          <PlusOutlined /> {useIntl().formatMessage({ id: 'Add' })}
                        </Button>
                      )} */}
                    </>
                  );
                })
              );
            })}
        </div>

        <Row gutter={[24, 24]}>
          <Col flex={1}>
            <Form.Item>
              {formSubmit ? (
                <Button disabled={formSubmit} type="primary" htmlType="submit" block loading>
                  {useIntl().formatMessage({ id: 'Apply' })}
                </Button>
              ) : (
                <Button disabled={formSubmit} type="primary" htmlType="submit" block>
                  {useIntl().formatMessage({ id: 'Apply' })}
                </Button>
              )}
            </Form.Item>
          </Col>
          <Col flex={1}>
            <Form.Item>
              <Button onClick={onCancel} block>
                {useIntl().formatMessage({ id: 'Cancel' })}
              </Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </>
  );
};

const TransferModal = (props: any) => {
  const {
    currentStatus,
    handleOk,
    handleCancel,
    isVisible,
    locationDetails,
    labType,
    selectedOrder,
    type,
  } = props;
  const [selectedLocation, setSelectedLocation] = useState('');
  const [locations, setLocations] = useState([]);
  const [dataArr, setdataArr] = useState([]);
  const [data, setData] = useState([]);
  const locDropdown: [] = [];
  const [warehouse, setWarehouse] = useState([]);
  const [batchData, setBatchData] = useState([]);
  const [subWarehouses, setsubWarehouses] = useState([]);

  async function fetchMyAPI(selectedOrder) {
    if (selectedOrder && selectedOrder.length > 0) {
      const arrayData = [];
      let arr = [];
      for (let i = 0; i < selectedOrder.length; i++) {
        let obj = { id: selectedOrder[i].inventoryId, dataLength: [[]] };
        if (!arr.find((item) => item.id == obj.id)) {
          arr.push(obj);
        }
        setdataArr(arr);

        arrayData.push(...selectedOrder[i].batches);
      }
      setBatchData(arrayData);
    }
  }
  useEffect(() => {
    if (selectedOrder != null && isVisible) {
      redCrescentService.getLocations('medicalredcrescent').then((locations: any) => {
        locations.map((lab: any) => {
          locDropdown.push(lab);
        });
        setLocations(locDropdown);
      });
    }
    fetchMyAPI(selectedOrder);
    if (isVisible) {
      redCrescentService.getWareHouses('medicalredcrescent').then((data) => {
        setWarehouse(data);
      });
    }
  }, [selectedOrder, isVisible]);
  return (
    <>
      <Modal
        title={
          type === 'Transfer'
            ? useIntl().formatMessage({ id: 'TRANSFER' })
            : useIntl().formatMessage({ id: 'ISSUE' })
        }
        visible={isVisible}
        afterClose={() => handleCancel()}
        destroyOnClose
        closable={false}
        footer={false}
        width="50%"
      >
        <BasicTransferForm
          batchData={batchData}
          setsubWarehouses={setsubWarehouses}
          subWarehouses={subWarehouses}
          type={type}
          setdataArr={setdataArr}
          dataArr={dataArr}
          setData={setData}
          data={data}
          warehouse={warehouse}
          setWarehouse={setWarehouse}
          currentStatus={currentStatus}
          labType={labType}
          selectedLocation={selectedLocation}
          setSelectedLocation={setSelectedLocation}
          locations={locations}
          locationDetails={locationDetails}
          handleOk={(updatedBatches: any) => handleOk(updatedBatches)}
          handleCancel={() => {
            handleCancel();
            setSelectedLocation('');
            setdataArr([]);
            setData([]);
            setsubWarehouses([]);
          }}
          selectedOrder={selectedOrder}
        />
      </Modal>
    </>
  );
};

export default TransferModal;

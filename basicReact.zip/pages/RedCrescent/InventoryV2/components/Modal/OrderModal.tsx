import React from 'react';
import { history, useModel, FormattedMessage, getLocale, formatMessage } from 'umi';
import {
  Modal,
  Button,
  Input,
  Alert,
  Row,
  Col,
  Tooltip,
  InputNumber,
  message,
  Form,
  DatePicker,
  Divider,
  Select,
  Tabs,
} from 'antd';
import { ExclamationCircleFilled, SkinOutlined } from '@ant-design/icons';
import apiService from '@/shared/services/api.service';
import { countries } from './countries';
import moment from 'moment';
import styles from './index.less';

enum PurchaseRoutes {
  'bgi' = '/bgi/purchase',
  'nonmoh' = '/non-moh/purchase',
  'centralbloodbank' = '/blood-bank/purchase',
  'branchbloodbank' = '/blood-bank/purchase',
  'peripheralbloodbank' = '/blood-bank/purchase',
  'medicalredcrescent' = '/redcrescent/medical/purchase',
  'nonmedicalredcrescent' = '/redcrescent/non-medical/purchase',
}
const { TabPane } = Tabs;
class OrderModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      orderName: 'DefaultOrder',
      orderNotes: '',
      inputList: [{ product: '', quantity: '' }],
      deliveryCost: null,
      srcaNumber: null,
      nupcoNumber: null,
      dateFormat: 'YYYY-MM-DD',
    };
  }
  componentDidMount() {
    const { inputList } = this.props;
    this.setState({ inputList });
  }

  componentDidUpdate(prevProps) {
    if (prevProps.inputList !== this.props.inputList) {
      this.setState({ inputList: this.props.inputList });
    }
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  };



  handleOk = async (e) => {
    const { locationId } = this.props;
    const { orderName, orderNotes, inputList, deliveryCost, nupcoNumber, srcaNumber } = this.state;
    // array.forEach(function(v){ delete v.bad });
    const regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    const numberRegex = /^\d+$/;

    if (this.props.type === 'PlaceOrder') {
      if (
        !inputList.some(
          (sku) =>
            sku.quantity <= 0 ||
            sku.quantity.toString().length > 9 ||
            !sku.supplierName ||
            !sku.expiryDate ||
            !sku.manufacturingCountry ||
            !sku.eta ||
            !sku.itemPrice ||
            !sku.totalValueWithTax ||
            !sku.issueDate ||
            !sku.issueNumber ||
            !sku.email ||
            !deliveryCost ||
            !sku.placeOfSupply ||
            !srcaNumber ||
            !sku.mailBox ||
            !sku.phoneNumber ||
            !sku.faxNumber ||
            !nupcoNumber ||
            !regex.test(sku.email) ||
            !numberRegex.test(sku.mailBox) ||
            !numberRegex.test(sku.phoneNumber) ||
            srcaNumber <= 0 ||
            nupcoNumber <= 0 ||
            !numberRegex.test(sku.faxNumber),
        )
      ) {

        this.setState({
          visible: false,
        });

        await apiService
          .createPurchaseOrder({
            name: orderName,
            // location: locationId,
            userName: this.props.user.name,
            email: this.props.user.email,
            orderItems: inputList,
            notes: orderNotes,
            deliveryCost,
            srcaNumber,
            nupcoNumber,
            labType: this.props.module,
          })
          .then(() => message.success(formatMessage({ id: 'OrderCreationSuccess' })));

        const urlFragment = PurchaseRoutes[this.props.module];
        history.push(urlFragment);
      } else {
        if (inputList.some((sku) => sku.quantity <= 0)) {
          const index = inputList.findIndex((sku) => { return sku.quantity <= 0 });
          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'SKUQuantityError' }))
        }
        else if (deliveryCost <= 0) {
          message.error('Delivery cost is missing');
        } else if (inputList.some((sku) => !sku.supplierName)) {
          const index = inputList.findIndex((sku) => { return !sku.supplierName });
          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'MissingSupplierName' }));
        } else if (inputList.some((sku) => !sku.expiryDate)) {
          const index = inputList.findIndex((sku) => { return !sku.expiryDate });
          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'MissingExpiryDate' }));
        } else if (inputList.some((sku) => !sku.manufacturingCountry)) {
          const index = inputList.findIndex((sku) => { return !sku.manufacturingCountry });
          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'MissingManufacturingCountry' }));
        } else if (inputList.some((sku) => !sku.eta || sku.eta <= 0)) {
          const index = inputList.findIndex((sku) => { return !sku.eta || sku.eta <= 0 });
          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'MissingExpectedLeadTime' }));
        } else if (inputList.some((sku) => !sku.itemPrice || sku.itemPrice <= 0)) {
          const index = inputList.findIndex((sku) => { return !sku.itemPrice || sku.itemPrice <= 0 });

          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'ItemPriceShouldBeNumericAndGreaterThan0' }));
        } else if (inputList.some((sku) => !sku.totalValueWithTax || sku.totalValueWithTax <= 0)) {
          const index = inputList.findIndex((sku) => { return !sku.totalValueWithTax || sku.totalValueWithTax <= 0 });

          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'TotalValueWithTaxShouldBeNumericAndGreaterThan0' }));
        } else if (inputList.some((sku) => !sku.issueDate)) {
          const index = inputList.findIndex((sku) => { return !sku.issueDate });
          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'MissingIssueDate' }));
        } else if (inputList.some((sku) => !sku.issueNumber || sku.issueNumber <= 0)) {
          const index = inputList.findIndex((sku) => { return !sku.issueNumber || sku.issueNumber <= 0 });
          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'IssueNumberShouldBeNumericAndGreaterThan0' }));
        } else if (inputList.some((sku) => !sku.mailBox || !numberRegex.test(sku.mailBox))) {
          const index = inputList.findIndex((sku) => { return !sku.mailBox || !numberRegex.test(sku.mailBox) });

          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'MissingOrInvalidMailBox' }));
        } else if (inputList.some((sku) => !sku.phoneNumber)) {
          const index = inputList.findIndex((sku) => { return !sku.phoneNumber });

          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'MissingPhoneNumber' }));
        } else if (inputList.some((sku) => !numberRegex.test(sku.phoneNumber))) {
          const index = inputList.findIndex((sku) => { return !numberRegex.test(sku.phoneNumber) });

          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'InvalidPhoneNumber' }));
        } else if (inputList.some((sku) => !sku.faxNumber || !numberRegex.test(sku.faxNumber))) {
          const index = inputList.findIndex((sku) => { return !sku.faxNumber || !numberRegex.test(sku.faxNumber) });

          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'MissingOrInvalidFaxNumber' }));
        } else if (inputList.some((sku) => !sku.placeOfSupply)) {
          const index = inputList.findIndex((sku) => { return !sku.placeOfSupply });

          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'MissingPlaceOfSupply' }));
        } else if (!(srcaNumber) || srcaNumber <= 0) {
          message.error(formatMessage({ id: 'MissingOrInvalidSrcaNumber' }));
        } else if (!(nupcoNumber) || nupcoNumber <= 0) {

          message.error(formatMessage({ id: 'MissingOrInvalidNupcoNumber' }));
        } else if (inputList.some((sku) => !sku.email)) {
          const index = inputList.findIndex((sku) => { return !sku.email });

          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'MissingEmailOrInvalidEmail' }));
        } else if (inputList.some((sku) => !regex.test(sku.email))) {
          const index = inputList.findIndex((sku) => { return !regex.test(sku.email) });

          message.error(getLocale() === 'ar-EG' ? inputList[index].arabicDescription : inputList[index].description + " " + formatMessage({ id: 'InvalidEmail' }));
        }
      }
    } else {
      if (!inputList.some((sku) => sku.quantity <= 0)) {
        this.setState({
          visible: false,
        });

        await apiService
          .createPurchaseOrder({
            name: orderName,
            // location: locationId,
            userName: this.props.user.name,
            email: this.props.user.email,
            orderItems: inputList,
            notes: orderNotes,
            deliveryCost: deliveryCost,
            labType: this.props.module,
          })
          .then(() => message.success(formatMessage({ id: 'OrderCreationSuccess' })));

        const urlFragment = PurchaseRoutes[this.props.module];
        history.push(urlFragment);
      } else {
        if (inputList.some((sku) => sku.quantity <= 0)) {
          message.error(formatMessage({ id: 'SKUQuantityError' }));
        } else {
          message.error(formatMessage({ id: 'QuantityShouldBeNumericAndGreaterThan0' }));
        }
      }
    }
  };

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  };

  handleInputChange = (e, index) => {
    const { name, value } = e.target;
    const list = this.state.inputList;
    list[index][name] = value;
    this.setState({ inputList: list });
  };

  // handle click event of the Remove button
  handleRemoveClick = (index) => {
    const list = this.state.inputList;
    list.splice(index, 1);
    this.setState({ inputList: list });
  };

  // handle click event of the Add button
  handleAddClick = () => {
    const list = this.state.inputList;
    list.push({ product: '', quantity: '' });
    this.setState({ inputList: list });
  };
  disabledPastDates = (current: any) => {
    // Can not select days after today
    return current && current < moment().add(1, 'days');
  };

  render() {
    const { visible, orderName, inputList } = this.state;
    const { count, style, btnName } = this.props;
    const locale = getLocale();

    return (
      <div>
        <Button
          // disabled={this.checkPermission()}
          // style={style}
          type="primary"
          onClick={this.showModal}
        >
          {btnName}
        </Button>
        <Modal
          title={<FormattedMessage id="CreatePurchaseOrder" />}
          visible={visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          width="58%"
          destroyOnClose
        >
          {inputList.some((item) => item.quantitiesInTransit > 0) ? (
            <Row gutter={[12, 12]}>
              <Col>
                <Alert
                  message={formatMessage({ id: 'Warning' })}
                  description={formatMessage({ id: 'ItemsInTransitWarning' })}
                  type="warning"
                  showIcon
                  closable
                />
              </Col>
            </Row>
          ) : null}

          <Form layout="vertical" name="basicEditForm" onFinish={this.onFinish}>
            <div className="issue-required" style={{ marginTop: '5px' }}>
              <Tabs type="card">
                {inputList.map((x, i) => {
                  if (typeof x.quantity !== 'number') {
                    x.quantity = 0;
                  }

                  return (
                    <TabPane tab={locale === 'ar-EG' ? x.arabicDescription : x.description} key={i}>
                      <Row gutter={[12, 12]} align="middle">
                        {/* <Divider orientation="left" plain>
                          {locale === 'ar-EG' ? x.arabicDescription : x.description}
                        </Divider> */}
                        <Col span={8}>
                          <Form.Item
                            label={formatMessage({
                              id: 'Product',
                            })}
                          >
                            <Input
                              name="product"
                              value={locale === 'ar-EG' ? x.arabicDescription : x.description}
                              onChange={(e) => this.handleInputChange(e, i)}
                            />
                          </Form.Item>
                          {this.state.inputList[i].quantity > x.nupcoInventoryQuantity &&
                            this.state.inputList[i].quantity !== x.nupcoInventoryQuantity ? (
                            <p style={{ color: 'red', height: '20px' }}> </p>
                          ) : (
                            <p> </p>
                          )}
                        </Col>
                        <Col span={8}>
                          <Form.Item label={formatMessage({ id: `Code` })}>
                            <Input name="product" value={x.code} />
                          </Form.Item>
                        </Col>
                        <Col span={x.quantitiesInTransit > 0 ? 7 : 8}>
                          <Form.Item
                            label={formatMessage({ id: 'Quantity' })}
                            name={`quantity${i}`}
                            rules={[
                              {
                                required: true,
                                message: formatMessage({ id: 'MissingQuantity' }),
                              },
                            ]}
                          >
                            <InputNumber
                              placeholder={formatMessage({ id: 'Quantity' })}
                              precision={0}
                              style={{ width: '100%' }}
                              onChange={(value) =>
                                this.handleInputChange({ target: { value, name: 'quantity' } }, i)
                              }
                            />
                          </Form.Item>
                          {/* <Form.Item
                      label={formatMessage({
                        id: 'Quantity',
                      })}
                    
                      name={`quantity${i}`}
                      rules={[
                        {
                          required: true,
                          message: formatMessage({ id: 'MissingQuantity' }),
                        },
                        {
                          type: 'number',
                          min: 0,
                        },
                      ]}
                    >
                      <InputNumber
                         precision={0}
                        onChange={(value) =>
                          this.handleInputChange({ target: { value, name: 'quantity' } }, i)
                        }
                        style={{ width: '100%' }}
                      />
                    </Form.Item> */}
                          {this.state.inputList[i].quantity > x.nupcoInventoryQuantity &&
                            this.state.inputList[i].quantity !== x.nupcoInventoryQuantity ? (
                            <p style={{ color: 'red', height: '20px' }}>
                              {formatMessage({ id: 'CannotBeMoreThan' }) + x.nupcoInventoryQuantity}
                            </p>
                          ) : this.state.inputList[i].quantity &&
                            (isNaN(this.state.inputList[i].quantity) ||
                              this.state.inputList[i].quantity <= 0) ? (
                            <p style={{ color: 'red' }}>
                              {/* {formatMessage({
                          id: 'QuantityShouldBeNumericAndGreaterThan0',
                        })}{' '} */}
                            </p>
                          ) : this.state.inputList[i].quantity &&
                            this.state.inputList[i].quantity.toString().length > 9 &&
                            this.props.type === 'PlaceOrder' ? (
                            <p style={{ color: 'red', height: '20px' }}>
                              {' '}
                              {formatMessage({
                                id: 'QuantityShouldBeLessThan9Digits',
                              })}{' '}
                            </p>
                          ) : (
                            <p></p>
                          )}
                        </Col>
                        {x.quantitiesInTransit > 0 ? (
                          <Col span={1}>
                            <Tooltip
                              placement="top"
                              title={
                                formatMessage({ id: 'QuantitiesinTransit' }) +
                                `: ${x.quantitiesInTransit}`
                              }
                            >
                              <ExclamationCircleFilled style={{ color: '#ad8b00' }} />
                            </Tooltip>
                          </Col>
                        ) : null}
                        <Col span={8}>
                          <Form.Item
                            label={formatMessage({
                              id: 'SupplierName',
                            })}
                            name={`supplier${i}`}
                            rules={[
                              {
                                required: true,
                                message: formatMessage({
                                  id: 'MissingSupplierName',
                                }),
                              },
                            ]}
                          >
                            <Input
                              onChange={(value) =>
                                this.handleInputChange(
                                  { target: { value: value.target.value, name: 'supplierName' } },
                                  i,
                                )
                              }
                              style={{ width: '100%' }}
                            />
                          </Form.Item>
                        </Col>
                        <Col span={8}>
                          <Form.Item
                            className={styles.formInput}
                            label={formatMessage({
                              id: 'ExpiryDate',
                            })}
                            name={`expiryDate${i}`}
                            rules={[
                              {
                                required: true,
                                message: formatMessage({ id: 'MissingExpiryDate' }),
                              },
                            ]}
                          // initialValue={updateModalData && moment(updateModalData?.expiryDate, dateFormat)}
                          >
                            <DatePicker
                              format={this.state.dateFormat}
                              disabledDate={this.disabledPastDates}
                              style={{ width: '100%' }}
                              onChange={(value) =>
                                this.handleInputChange({ target: { value, name: 'expiryDate' } }, i)
                              }
                            />
                          </Form.Item>
                        </Col>
                        <Col span={8}>
                          <Form.Item
                            label={formatMessage({
                              id: 'ManufacturingCountry',
                            })}
                            name={`manufacturingCountry${i}`}
                            rules={[
                              {
                                required: true,
                                message: formatMessage({
                                  id: 'ManufacturingCountry',
                                }),
                              },
                            ]}
                          >
                            <Select
                              onChange={(value) =>
                                this.handleInputChange(
                                  { target: { value: value, name: 'manufacturingCountry' } },
                                  i,
                                )
                              }
                            >
                              {countries?.map((ele) => {
                                return (
                                  <Select.Option value={ele} key={ele}>
                                    {ele}
                                  </Select.Option>
                                );
                              })}
                            </Select>
                          </Form.Item>
                        </Col>
                        <Col span={8}>
                          <Form.Item
                            label={formatMessage({
                              id: 'ExpectedLeadTime',
                            })}
                            name={`eta${i}`}
                            rules={[
                              {
                                required: true,
                                message: formatMessage({
                                  id: 'ExpectedLeadTime',
                                }),
                              },
                            ]}
                          >
                            <InputNumber
                              className="ml10"
                              value={this.state.inputList[i].eta}
                              min={1}
                              onChange={(value) =>
                                this.handleInputChange({ target: { value, name: 'eta' } }, i)
                              }
                              style={{ width: '100%' }}
                            />
                          </Form.Item>
                        </Col>
                        <Col span={8}>
                          <Form.Item
                            label={formatMessage({
                              id: 'ItemPrice',
                            })}
                            name={`itemPrice${i}`}
                            rules={[
                              {
                                required: true,
                                message: formatMessage({
                                  id: 'ItemPrice',
                                }),
                              },
                            ]}
                          >
                            <InputNumber
                              min={1}
                              className="ml10"
                              value={this.state.inputList[i].itemPrice}
                              onChange={(value) =>
                                this.handleInputChange({ target: { value, name: 'itemPrice' } }, i)
                              }
                              style={{ width: '100%' }}
                            />
                          </Form.Item>
                        </Col>
                        <Col span={8}>
                          <Form.Item
                            label={formatMessage({
                              id: 'TotalValueWithTax',
                            })}
                            name={`totalValueWithTax${i}`}
                            rules={[
                              {
                                required: true,
                                message: formatMessage({
                                  id: 'TotalValueWithTax',
                                }),
                              },
                            ]}
                          >
                            <InputNumber
                              min={1}
                              value={this.state.inputList[i].totalValueWithTax}
                              onChange={(value) =>
                                this.handleInputChange(
                                  { target: { value, name: 'totalValueWithTax' } },
                                  i,
                                )
                              }
                              style={{ width: '100%' }}
                            />
                          </Form.Item>
                        </Col>
                        {/* <div
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          padding: '0px 42px',
                          width: '100%',
                        }}
                      >
                        <span>
                          <FormattedMessage id="IssueDate" />
                        </span>
                        <span style={{ marginLeft: '36%' }}>
                          <FormattedMessage id="IssueNumber" />
                        </span>
                      </div> */}
                        <Col span={8}>
                          <Form.Item
                            label={formatMessage({
                              id: 'IssueDate',
                            })}
                            name={`issueDate${i}`}
                            rules={[
                              {
                                required: true,
                                message: formatMessage({
                                  id: 'IssueDate',
                                }),
                              },
                            ]}
                          >
                            <DatePicker
                              onChange={(value) =>
                                this.handleInputChange({ target: { value, name: 'issueDate' } }, i)
                              }
                              format={this.state.dateFormat}
                              disabledDate={this.disabledPastDates}
                              style={{ width: '100%' }}
                            />
                          </Form.Item>
                        </Col>
                        <Col span={8}>
                          <Form.Item
                            label={formatMessage({
                              id: 'IssueNumber',
                            })}
                            name={`issueNumber${i}`}
                            rules={[
                              {
                                required: true,
                                message: formatMessage({
                                  id: 'IssueNumber',
                                }),
                              },
                            ]}
                          >
                            <InputNumber
                              min={1}
                              className="ml10"
                              onChange={(value) =>
                                this.handleInputChange(
                                  { target: { value, name: 'issueNumber' } },
                                  i,
                                )
                              }
                              style={{ width: '100%' }}
                            />
                          </Form.Item>
                        </Col>
                        <Col span={8}>
                          <Form.Item
                            label={formatMessage({
                              id: 'MailBox',
                            })}
                            name={`mailBox${i}`}
                            rules={[
                              {
                                required: true,
                                message: formatMessage({
                                  id: 'MissingMailBox',
                                }),
                              },
                            ]}
                          >
                            <InputNumber
                              onChange={(value) =>
                                this.handleInputChange({ target: { value, name: 'mailBox' } }, i)
                              }
                              style={{ width: '100%' }}
                            />
                          </Form.Item>
                        </Col>

                        <Col span={8}>
                          <Form.Item
                            label={formatMessage({
                              id: 'PhoneNumber',
                            })}
                            name={`phoneNumber${i}`}
                            rules={[
                              {
                                required: true,
                                message: formatMessage({
                                  id: 'MissingPhoneNumber',
                                }),
                              },
                            ]}
                          >
                            <Input
                              onChange={(value) =>
                                this.handleInputChange(
                                  { target: { value: value.target.value, name: 'phoneNumber' } },
                                  i,
                                )
                              }
                              style={{ width: '100%' }}
                            />
                          </Form.Item>
                        </Col>
                        <Col span={8}>
                          <Form.Item
                            label={formatMessage({
                              id: 'Fax',
                            })}
                            name={`faxNumber${i}`}
                            rules={[
                              {
                                required: true,
                                message: formatMessage({
                                  id: 'MissingFax',
                                }),
                              },
                            ]}
                          >
                            <Input
                              onChange={(value) =>
                                this.handleInputChange(
                                  { target: { value: value.target.value, name: 'faxNumber' } },
                                  i,
                                )
                              }
                              style={{ width: '100%' }}
                            />
                          </Form.Item>
                        </Col>
                        <Col span={8}>
                          <Form.Item
                            label={formatMessage({
                              id: 'PlaceOfSupply',
                            })}
                            name={`placeOfSupply${i}`}
                            rules={[
                              {
                                required: true,
                                message: formatMessage({
                                  id: 'MissingPlaceOfSupply',
                                }),
                              },
                            ]}
                          >
                            <Input
                              onChange={(value) =>
                                this.handleInputChange(
                                  { target: { value: value.target.value, name: 'placeOfSupply' } },
                                  i,
                                )
                              }
                              style={{ width: '100%' }}
                            />
                          </Form.Item>
                        </Col>

                        <Col span={8}>
                          <Form.Item
                            label={formatMessage({
                              id: 'Email',
                            })}
                            name={`email${i}`}
                            rules={[
                              {
                                required: true,
                                message: formatMessage({
                                  id: 'MissingEmail',
                                }),
                              },
                            ]}
                          >
                            <Input
                              type="email"
                              onChange={(value) =>
                                this.handleInputChange(
                                  { target: { value: value.target.value, name: 'email' } },
                                  i,
                                )
                              }
                              style={{ width: '100%' }}
                            />
                          </Form.Item>
                        </Col>
                      </Row>
                    </TabPane>
                  );
                })}


              </Tabs>
              <Divider plain />
              <Row gutter={[12, 12]} align="middle">
                <Col span={12}>
                  <Form.Item
                    label={formatMessage({
                      id: 'SRCAPONumber',
                    })}
                    name={`srcaNumber`}
                    rules={[
                      {
                        required: true,
                        message: formatMessage({
                          id: 'MissingSRCAPONumber',
                        }),
                      },
                    ]}
                  >
                    <InputNumber
                      value={this.state.srcaNumber}
                      onChange={(value) => {

                        this.setState({
                          srcaNumber: value,
                        })
                      }}
                      style={{ width: '100%' }}
                    />
                  </Form.Item>
                </Col>
                <Col span={12}>
                  <Form.Item
                    label={formatMessage({
                      id: 'NUPCOPONumber',
                    })}
                    name={`nupcoNumber`}
                    rules={[
                      {
                        required: true,
                        message: formatMessage({
                          id: 'MissingNUPCOPONumber',
                        }),
                      },
                    ]}
                  >
                    <InputNumber
                      value={this.state.nupcoNumber}
                      onChange={(value) =>
                        this.setState({
                          nupcoNumber: value,
                        })
                      }
                      style={{ width: '100%' }}
                    />
                  </Form.Item>
                </Col>
                <Col span={12}>
                  <Form.Item
                    className="ant-form-item-required"
                    label={formatMessage({
                      id: 'DeliveryCost',
                    })}
                    name={`deliveryCost`}
                    rules={[
                      {
                        required: true,
                        message: formatMessage({
                          id: 'MissingDeliveryCost',
                        }),
                      },
                    ]}
                  >
                    <InputNumber
                      value={this.state.deliveryCost}
                      onChange={(value) =>
                        this.setState({
                          deliveryCost: value,
                        })
                      }
                      style={{ width: '100%' }}
                    />
                  </Form.Item>
                </Col>
                <Col span={12}>
                  <Form.Item
                    name={`notes`}
                    label={formatMessage({
                      id: 'Note',
                    })}
                  >
                    <Input
                      placeholder={formatMessage({ id: 'Note' })}
                      onChange={(event) => this.setState({ orderNotes: event.target.value })}
                      style={{ width: '100%' }}
                    />
                  </Form.Item>
                </Col>
              </Row>
            </div>
          </Form>
          <Row gutter={[12, 12]}></Row>
        </Modal>
      </div>
    );
  }
}

const OrderModalWrapper = (props: any) => {
  const { initialState } = useModel('@@initialState');
  const userDetails = {
    name: initialState?.currentUser?.name || '',
    email: initialState?.currentUser?.email || '',
  };

  return <OrderModal {...props} user={userDetails} />;
};

export default OrderModalWrapper;
/* eslint-disable class-methods-use-this */
import React, { Component } from 'react';
import { Access, useAccess, history, FormattedMessage, getLocale } from 'umi';
import {
  Table,
  Button,
  Col,
  Row,
  Badge,
  Space,
  Popconfirm,
  Tooltip,
  Typography,
  Switch,
  Spin,
  Input,
} from 'antd';
import moment from 'moment';
import { INVENTORY_CATEGORIES } from '../../../POSearch/Constants';

import TransferModal from '../TransferModal/TransferModal';
import IssueModal from '../IssueModal/Issue';
import AddItemModal from '../AddItemModal/AddItem';
import IntraWarehouseTransferModal from '../IntrawarehouseTransfer/IntraWarehouseTransferModal';
// import OrderModal from '@/components/Modal/OrderModal';
import OrderModal from '../../components/Modal/OrderModal';
import {
  DeleteOutlined,
  EditOutlined,
  FastForwardOutlined,
  QrcodeOutlined,
  InfoOutlined,
} from '@ant-design/icons';
import { LabTypes } from '@/services/Constants';
import redcrescentService from '../../../services/redcrescent.service';
import { ColumnType, SKUType } from '../../Types';
import EditModal from '../EditModal/EditModal';
import styles from './index.less';
import SearchBar from '../SearchBar/SearchBar';
import InfoModal from '../InfoModal/InfoModal';
const { Text } = Typography;
const { Search } = Input;
// Excluding Checkbox column
const getTotalColumnWidth = (columns: ColumnType[]): number => {
  return columns.reduce((acc, cur) => acc + parseInt(cur.width, 10), 0);
};

const onViewBatches = async (skuId) => {
  const res = await redcrescentService.getBatches(skuId);
};

const ViewBatchesButton = (props) => {
  const { skuId } = props;
  return <Button onClick={() => onViewBatches(skuId)}>View batches</Button>;
};

interface StateType {
  skuColumns: ColumnType[];
  skus: SKUType[];
  showEditModal: boolean;
  showInfoModal: boolean;
  infoModalBatches: any | null;
  infoModalContent: any | null;
  userLocationId: number;
  editModalContent: SKUType | null;
  editModalBatches: any | null;
  selectedRowKeys: any;
  selectedOrder: any;
  userAccess: any;
  expandRowData: any[];
  nestedColumns: any[];
  loadEpandableRowdata: boolean;
  expandedRowKeys: any[];
  inventoryLocationId: number;
  autoReplenishment: any[];
  activeColumn: any[];
}

interface PropsType {
  skus: SKUType[];
  userLocationId: number;
  inventoryLocationId: number;
  tableHeight: number;
  access: any;
}

class InventoryTable extends Component<PropsType, StateType> {
  constructor(props) {
    super(props);
    this.state = {
      results: [],
      currentStatus: '',
      isLoading: false,
      userAccess: this.props.access,
      category: INVENTORY_CATEGORIES[0],
      expandedRowFullData: [],
      expandedBatchNumber: '',
      skuColumns: [
        {
          title: <FormattedMessage id="SerialNumber" />,
          width: '100px',
          fixed: 'left',
          dataIndex: 'serialNum',
          key: 'serialNum',
          // fixed: 'left',
          render: (text, record, index) => {
            const indexV = this.state.skus.findIndex((i) => i.id === record.id);
            return (
              <Space>
                <Badge status={record.hasUpdated ? 'success' : 'error'} />
                <Text>{indexV + 1}</Text>
              </Space>
            );
          },
        },
        {
          title: <FormattedMessage id="Code" />,
          width: '200',
          dataIndex: ['product', 'code'],

          key: 'code',
          width: '100',
          fixed: 'left',
        },
        {
          title: <FormattedMessage id="Description" />,
          width: '100',
          fixed: 'left',
          dataIndex:
            getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : ['product', 'description'],
          key: 'description',
          // fixed: 'left',
        },
        {
          title: <FormattedMessage id="Quantity" />,
          width: '200',
          dataIndex: 'quantity',
          key: 'quantity',
        },
        {
          title: <FormattedMessage id="QuantitiesinTransit" />,
          width: '200',
          dataIndex: 'quantitiesInTransit',
          key: 'quantitiesInTransit',
        },
        {
          title: <FormattedMessage id="UnitofMeasurement" />,
          width: '200',
          dataIndex: ['product', 'unitOfMeasures'],
          key: 'unitOfMeasures',
        },
        {
          title: <FormattedMessage id="ActualDailyConsumption" />,
          width: '200',
          dataIndex: 'dailyConsumption',
          key: 'dailyConsumption',
          render: (text, record) => text.toFixed(3),
        },
        {
          title: <FormattedMessage id="AvgActualConsumption" />,
          width: '200',
          dataIndex: 'consumption',
          key: 'consumption',
          render: (text, record) => Math.round(text),
        },
        {
          title: <FormattedMessage id="ReorderLevel" />,
          width: '200',
          dataIndex: 'reOrderLevel',
          key: 'reOrderLevel',
          render: (text, record) => Math.round(text),
        },
        {
          title: <FormattedMessage id="ReorderQuantity" />,
          width: '200',
          dataIndex: 'reOrderQuantity',
          key: 'reOrderQuantity',
          render: (text, record) => Math.round(text),
        },

        {
          title: <FormattedMessage id="ExpectedCoveringDays" />,
          width: '200',
          dataIndex: 'consumableDays',
          key: 'consumableDays',
        },
        {
          title: <FormattedMessage id="LastUpdatedAt" />,
          width: '200',
          dataIndex: 'updatedAt',
          key: 'updatedAt',
          render: (text) => (
            <Text>
              {!getLocale() || getLocale().includes('en')
                ? moment(text).locale(getLocale()).format('YYYY-MM-DD, HH:mm')
                : moment(text).locale(getLocale()).format('YYYY-MM-DD, HH:mm')}
            </Text>
          ),
        },
      ],
      activeColumn: [
        {
          title: <FormattedMessage id="Active" />,
          width: '100px',
          dataIndex: 'active',
          key: 'active',
          fixed: 'right',
          render: (text, record, index) => (
            <Access
              accessible={this.state.userAccess.canUpdateRedCrescentInventory(
                this.props.locationDetails.id,
              )}
            >
              <Switch
                defaultChecked={record.active}
                className={styles.switchButton}
                disabled={this.state.isLoading}
                onChange={(value) => this.toggleActiveStatus(value, record)}
              ></Switch>
            </Access>
          ),
        },
      ],
      skus: this.props.skus,
      autoReplenishment: this.props.skus.filter(function (item: any) {
        return item.reOrderQuantity > 0 && item.quantitiesInTransit == 0 && item.active;
      }),
      tmpSkus: this.props.skus,
      showEditModal: false,
      loadEpandableRowdata: true,
      showInfoModal: false,
      expandedRowKeys: [],
      record: [],
      expandRowData: [],
      userLocationId: this.props.userLocationId,
      inventoryLocationId: this.props.inventoryLocationId,
      editModalContent: null,
      infoModalContent: null,
      infoModalBatches: null,
      selectedRowKeys: [],
      selectedOrder: null,
      showRequestTransferModal: false,
      showRequestIssueModal: false,
      showRequestIntraTransferModal: false,
      showAddItemRequestModal: false,
      searchData: false,
      searchTermItem: '',
      nestedColumns: [
        {
          title: <FormattedMessage id="SerialNumber" />,
          width: '100',
          dataIndex: 'serialNum',
          key: 'serialNum',
          // fixed: 'left',
          render: (text, record, index) => <Text>{index + 1}</Text>,
        },
        {
          title: <FormattedMessage id="BatchNumber" />,
          // width: '200',
          dataIndex: 'batchNumber',
          key: 'batchNumber',
        },
        {
          title: <FormattedMessage id="BatchQuantity" />,
          // width: '200',
          dataIndex: 'quantity',
          key: 'quantity',
        },
        {
          title: <FormattedMessage id="ManufacturedDate" />,
          // width: '200',
          dataIndex: 'manufactureDate',
          key: 'manufactureDate',
        },
        {
          title: <FormattedMessage id="ExpiryDate" />,
          // width: '200',
          dataIndex: 'expiryDate',
          key: 'expiryDate',
          render: (text) => (
            <Text>
              {text && text !== '' && text !== null
                ? !getLocale() || getLocale().includes('en')
                  ? moment(text).locale(getLocale()).format('YYYY-MM-DD, HH:mm')
                  : moment(text).locale(getLocale()).format('YYYY-MM-DD, HH:mm')
                : ''}
            </Text>
          ),
        },
      ],
    };

    this.configureRowSelction = this.configureRowSelction.bind(this);
    this.editButton = this.editButton.bind(this);
    this.onEdit = this.onEdit.bind(this);
    this.onInfo = this.onInfo.bind(this);
    this.handleSearchInput = this.handleSearchInput.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
  }

  shouldComponentUpdate(nextProps, nextState) {
    const repl = nextProps.skus.filter(function (item: any) {
      return item.reOrderQuantity > 0 && item.quantitiesInTransit == 0 && item.active;
    });

    if (nextState.autoReplenishment.length == 0 && repl.length > 0) {
      this.setState({
        autoReplenishment: repl,
      });
    }

    return true;
  }

  static getDerivedStateFromProps(props, currentState) {
    if (JSON.stringify(currentState.tmpSkus) !== JSON.stringify(props.skus)) {
      return {
        skus: props.skus,
        tmpSkus: props.skus,
      };
    }
    return {
      tmpSkus: props.skus,
    };
  }

  toggleActiveStatus = async (value, record) => {
    if (this.state.isLoading) {
      return;
    }
    const skus = [...this.state.skus];
    const index = skus.findIndex((i) => i.id === record.id);
    const updatedRecord = {
      ...record,
      active: value ? 1 : 0,
    };
    skus.splice(index, 1, updatedRecord);
    const selectedRowKeys = this.state.selectedRowKeys.filter((r) => r !== record.product.id);
    this.setState({ skus, selectedRowKeys, isLoading: true });

    try {
      redcrescentService
        .changeActiveStatus(value, record)
        .then((res) => {
          let page = this.props.page === 2 ? 1 : this.props.page;
          this.props.onUpdate(this.props.filters, page);
          setTimeout(() => {
            this.setState({
              isLoading: false,
            });
          }, 2000);
        })
        .catch((err) => {
          skus.splice(index, 1, record);
          this.setState({ skus, isLoading: false });
        });
    } catch (ex) {
      skus.splice(index, 1, record);
      this.setState({ skus, isLoading: false });
    }
  };

  private async onEdit(sku) {
    const skuBatchDetails = await redcrescentService.getBatches(sku.id);

    this.setState({
      editModalContent: sku,
      editModalBatches: skuBatchDetails,
      showEditModal: true,
      currentStatus: sku.state,
    });
  }

  private async onInfo(sku) {
    const skuBatchDetails = await redcrescentService.getBatches(sku.id);

    this.setState({
      infoModalBatches: skuBatchDetails,
      infoModalContent: sku,
      showInfoModal: true,
      currentStatus: sku.state,
    });
  }

  private isUpdatedToday(sku: SKUType) {
    const lastUpdatedOn = sku.updatedAt;
    const today = moment();

    return moment(lastUpdatedOn).isSame(today, 'day');
  }

  // Excluding Checkbox column
  private getTotalColumnWidth(columns: ColumnType[]): number {
    return columns.reduce((acc, cur) => acc + parseInt(cur.width, 10), 0);
  }
  handleUpdateLocators = async (updates) => {
    // const dailyConsumptionPayload = {
    //   dailyConsumption: updates.dailyConsumption,
    //   productId: this.state.editModalContent?.productId,
    //   locationId: this.state.editModalContent?.locationId,
    //   inventoryId: this.state.editModalContent?.id,
    // };

    //
    if (updates) {
      await redcrescentService.updateLocators(updates);
      //await redcrescentService.updateDailyConsumption(dailyConsumptionPayload);
    }
    if (this.state.searchData) {
      this.getResults(this.state.searchTermItem, this.state.category);
    } else {
      let page = this.props.page === 2 ? 1 : this.props.page;
      this.props.onUpdate(this.props.filters, page);
    }

    this.fetchBatches(this.state.editModalContent?.id);
    this.setState({
      showEditModal: false,
      editModalBatches: null,
      editModalContent: null,
    });
    this.setState({
      selectedOrder: [],
      selectedRowKeys: [],
    });
  };

  handleOk = async (updates) => {
    const dailyConsumptionPayload = {
      dailyConsumption: updates.dailyConsumption,
      productId: this.state.editModalContent?.productId,
      locationId: this.state.editModalContent?.locationId,
      inventoryId: this.state.editModalContent?.id,
    };

    const batchesPayload = updates?.batches?.map((batch) => {
      return {
        ...batch,
        productId: this.state.editModalContent?.productId,
        locationId: this.state.editModalContent?.locationId,
        inventoryId: this.state.editModalContent?.id,
        hasExpiry: !!batch.expiryDate,
      };
    });
    //
    if (updates.callUpdateApi) {
      await redcrescentService.updateBatches(batchesPayload);
      await redcrescentService.updateDailyConsumption(dailyConsumptionPayload);
    }
    if (this.state.searchData) {
      this.getResults(this.state.searchTermItem, this.state.category);
    } else {
      let page = this.props.page === 2 ? 1 : this.props.page;
      this.props.onUpdate(this.props.filters, page);
    }

    this.fetchBatches(this.state.editModalContent?.id);
    this.setState({
      showEditModal: false,
      editModalBatches: null,
      editModalContent: null,
    });
    this.setState({
      selectedOrder: [],
      selectedRowKeys: [],
    });
    // window.location.reload();
  };

  handleTransfer = async (transferData: any) => {
    const { selectedOrder } = this.state;
    const { locationDetails } = this.props;
    const items = [...transferData.item];
    if (transferData.type === 'Transfer') {
      items.forEach(function (v) {
        delete v.index;
        delete v.batchId;
      });
      let data = {
        items: items,
      };
      data = {
        ...data,
        toLocationId: transferData.location.id,
        toLabType: transferData.labType,
        toLocationName: transferData.location.name,
        toLocationCode: transferData.location.code,
      };
      await redcrescentService.createTransferRequest(data, transferData.type);
    } else {
      const extraFields = [...transferData.extraFields];
      extraFields.forEach(function (v) {
        delete v.index;
      });

      items.forEach(function (v) {
        delete v.index;
      });
      let data = {};
      if (!!extraFields[0]?.remarks) {
        data = {
          requester: extraFields[0]?.requester,
          requestingCity: extraFields[0]?.requestingCity,
          remarks: extraFields[0]?.remarks,
          locationId: locationDetails.id,
          labType: this.props.labtype,
          locators: items,
        };
      } else {
        data = {
          requester: extraFields[0]?.requester,
          requestingCity: extraFields[0]?.requestingCity,
          locationId: locationDetails.id,
          labType: this.props.labtype,
          locators: items,
        };
      }

      data = { ...data };
      await redcrescentService.createIssue(data, transferData.type);
    }

    let url = '';
    if (transferData.type === 'Transfer') {
      url = transferData.labType.includes('non')
        ? '/redcrescent/non-medical/transfer'
        : '/redcrescent/medical/transfer';
    } else {
      url = window.location.href.includes('non-medical')
        ? '/redcrescent/non-medical/issue'
        : '/redcrescent/medical/issue';
    }

    history.push(url);
    this.setState({
      showRequestTransferModal: false,
      showRequestIntraTransferModal: false,
      selectedOrder: [],
      selectedRowKeys: [],
    });
  };

  handleIntraTransfer = async (transferData: any) => {
    let locators = [...transferData.locators];
    locators.forEach(function (v) {
      delete v.index;
      delete v.batchNumber;
      delete v.batchId;
      delete v.productId;
      delete v.inventoryId;
    });
    let destination = [...transferData.destination];

    destination.forEach(function (v) {
      if (window.location.href.includes('non-medical')) {
        delete v.inventoryId;
        delete v.labType;
        delete v.locationCode;
        delete v.locationName;
        delete v.productId;
        delete v.locationId;
      }
      delete v.index;
    });
    const data = {
      batchId: transferData.batchId,
      locators,
      destination,
    };
    await redcrescentService.createIntraWareHouseTransferRequest(data);
    this.setState({
      showRequestTransferModal: false,
      showRequestIntraTransferModal: false,
      selectedOrder: [],
      selectedRowKeys: [],
      expandedRowKeys: [],
      expandRowData: [],
    });
    this.keys = [];
    let page = this.props.page === 2 ? 1 : this.props.page;
    this.props.onUpdate(this.props.filters, page);
  };

  handleCancel = () => {
    this.setState({
      showEditModal: false,
      showInfoModal: false,
      infoModalContent: null,
      infoModalBatches: null,
      editModalBatches: null,
      editModalContent: null,
      showRequestTransferModal: false,
      showRequestIntraTransferModal: false,
      showRequestIssueModal: false,
      showAddItemRequestModal: false,
    });
    // this.props.onUpdate();
    // window.location.reload();
  };

  // Row checkbox config
  private configureRowSelction() {
    return {
      selectedRowKeys: this.state.selectedRowKeys,
      onChange: (selectedRowKeys, selectedRows) => {
        this.onSelectChange(selectedRowKeys);
      },
      getCheckboxProps: (record: SKUType) => {
        return {
          code: record.product.code,
          disabled: !(
            this.state.userAccess.canPlaceRedCrescentPurchaseOrder(this.props.locationDetails.id) ||
            this.state.userAccess.canStoreKeeper(this.props.locationDetails.id) ||
            this.state.userAccess.purchaseUser(this.props.locationDetails.id)
          ),
        };
      },
    };
  }

  editButton(sku) {
    const { userAccess } = this.state;
    const { locationDetails } = this.props;
    return (
      <Access accessible={userAccess.canUpdateRedCrescentLocatorsBatches(locationDetails.id)}>
        <Tooltip title={<FormattedMessage id="Edit" />}>
          <Button
            type="primary"
            shape="circle"
            icon={<EditOutlined />}
            onClick={() => this.onEdit(sku)}
          />
        </Tooltip>
      </Access>
    );
  }

  keys: any[] = [];

  getExpandableData = (inventoryId, rowId, record) => {
    this.keys[0] === inventoryId ? (this.keys = []) : (this.keys[0] = inventoryId);
    this.setState({
      expandRowData: [],
      loadEpandableRowdata: true,
      expandedRowKeys: this.keys,
      expandedRowFullData: record,
    });
    this.fetchBatches(inventoryId);
  };

  fetchBatches = async (inventoryId: number) => {
    const data = await redcrescentService.getBatches(inventoryId);

    if (data) {
      this.setState({
        expandRowData: data.batches,
        loadEpandableRowdata: false,
      });
    }
  };

  expandedRowRender = () => {
    let extraColumns = [];
    let filePdfName = 'pdf';
    if (
      this.state.expandRowData.length &&
      this.state.userAccess.canUpdateRedCrescentInventory(this.state.inventoryLocationId)
    ) {
      extraColumns = [
        {
          title: <FormattedMessage id="Actions" />,
          dataIndex: 'delete',
          key: 'delete',
          render: (text, record) =>
            this.state.expandRowData.length >= 1 ? (
              <>
                <div className={styles.actionDiv}>
                  <Popconfirm
                    title={<FormattedMessage id="SureToDelete" />}
                    onConfirm={() => this.handleDelete(record.id)}
                  >
                    <Tooltip title={<FormattedMessage id="Delete" />}>
                      <Button
                        className={styles.editbtn}
                        type="primary"
                        shape="circle"
                        icon={<DeleteOutlined />}
                      />
                    </Tooltip>
                  </Popconfirm>

                  <Tooltip title={<FormattedMessage id="IntraWarehouseTransfer" />}>
                    <Button
                      className={styles.editbtn}
                      type="primary"
                      shape="circle"
                      icon={<FastForwardOutlined />}
                      onClick={() => this.requestIntraTransfer(record)}
                    />
                  </Tooltip>
                  <Tooltip title={<FormattedMessage id="DownloadQR" />}>
                    <Button
                      className={styles.editbtn}
                      type="primary"
                      disabled={!(record && record.content)}
                      icon={<QrcodeOutlined />}
                      shape="circle"
                      onClick={() =>
                        record &&
                        record.content &&
                        redcrescentService.downloadQrCode(
                          JSON.parse(record.content).fileKey,
                          JSON.parse(record.content).fileName,
                          filePdfName,
                        )
                      }
                    />
                  </Tooltip>
                </div>
              </>
            ) : null,
        },
      ];
    }

    return (
      <Table
        columns={[...this.state.nestedColumns, ...extraColumns]}
        dataSource={this.state.expandRowData}
        pagination={false}
        loading={this.state.loadEpandableRowdata}
      />
    );
  };
  handleDelete = async (id) => {
    await redcrescentService.deleteBatch(id).then((response) => {
      const dataSource = [...this.state.expandRowData];
      this.setState({ expandRowData: dataSource.filter((item) => item.id !== id) });
      let page = this.props.page === 2 ? 1 : this.props.page;
      this.props.onUpdate(this.props.filters, page);
    });
  };

  onSelectChange = (selectedRowKeys) => {
    const { skus, selectedOrder } = this.state;
    let arr = [];
    const selectedOrderData = [];

    selectedRowKeys.forEach((el, index) => {
      const selectedRow = skus.find((sku) => sku.id === el);
      if (selectedRow.active) {
        arr.push(el);
        if (selectedRow.reOrderQuantity === 0) {
          selectedOrderData.push({
            binNumber: selectedRow.binNumber,
            inventoryId: selectedRow.id,
            productId: selectedRow.productId,
            locationId: selectedRow.locationId,
            quantity: selectedRow.reOrderQuantity,
            code: selectedRow.product.code,
            arabicDescription: selectedRow?.product.arabicDescription,
            description: selectedRow.product.description,
            quantitiesInTransit: selectedRow.quantitiesInTransit,
            quantity: selectedRow.quantity,
            reOrderQuantity: selectedRow.reOrderQuantity,
            batches: selectedRow.batches || [],
          });
        } else {
          selectedOrderData.push({
            binNumber: selectedRow.binNumber,
            inventoryId: selectedRow.id,
            productId: selectedRow.productId,
            locationId: selectedRow.locationId,
            quantity: selectedRow.reOrderQuantity,
            code: selectedRow.product.code,
            arabicDescription: selectedRow?.product.arabicDescription,
            description: selectedRow.product.description,
            quantitiesInTransit: selectedRow.quantitiesInTransit,
            quantity: selectedRow.quantity,
            reOrderQuantity: selectedRow.reOrderQuantity,
            batches: selectedRow.batches || [],
          });
        }
      }
    });
    if (JSON.stringify(this.state.selectedRowKeys) === JSON.stringify(arr)) {
      arr = [];
    }
    this.setState({ selectedOrder: selectedOrderData, selectedRowKeys: arr });
  };

  downloadInventory = async () => {
    const { labtype, locationsKeys } = this.props;
    await redcrescentService.downloadInventory(
      this.state.inventoryLocationId,
      locationsKeys[this.state.inventoryLocationId],
      labtype,
    );
  };
  requestTransfer = () => {
    const { showRequestTransferModal } = this.state;
    this.setState({
      showRequestTransferModal: !showRequestTransferModal,
    });
  };

  addItemRequest = () => {
    const { showAddItemRequestModal } = this.state;
    this.setState({
      showAddItemRequestModal: !showAddItemRequestModal,
    });
  };
  requestIssue = () => {
    const { showRequestIssueModal } = this.state;
    this.setState({
      showRequestIssueModal: !showRequestIssueModal,
    });
  };
  requestIntraTransfer = (record) => {
    const labType = window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC;
    const { showRequestIntraTransferModal, expandedRowFullData, expandedBatchNumber } = this.state;
    let batchNumber = '';
    let r = [];
    if (labType !== 'medicalredcrescent') {
      r.push(record);
      batchNumber = record?.batches[0].batchNumber;
    } else {
      r.push(expandedRowFullData);
      batchNumber = record?.batchNumber;
    }
    this.setState({
      showRequestIntraTransferModal: !showRequestIntraTransferModal,
      record: r,
      expandedBatchNumber: batchNumber,
    });
  };

  getMoreInventoryRequest = (current) => {
    this.props.getMoreInventoryRequest(current, this.props.filters);
  };
  async handleSearch() {
    const { searchText } = this.state;
    const labType = window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC;
    await redcrescentService.getSerachData(searchText, labType).then((response) => {
      this.setState({ skus: response });
    });
  }
  handleSearchInput(e: any) {
    this.setState(
      {
        searchText: e.target.value.toLowerCase(),
      },
      () => {
        this.handleSearch();
      },
    );
  }

  getResults = async (searchTerm, optionDetail) => {
    if (searchTerm !== '') {
      const selectedCategory =
        optionDetail.category === 'productCodes'
          ? 'productCode'
          : optionDetail.category === 'productDescriptions'
            ? 'productDescription'
            : optionDetail.category;
      await redcrescentService
        .getSelectData(
          { category: selectedCategory, value: searchTerm },
          this.state.inventoryLocationId,
        )
        .then((response) => {
          this.setState({
            skus: response.results.data,
            searchData: true,
          });
        });
      this.setState({
        category: optionDetail,
        searchTermItem: searchTerm,
      });
    } else {
      this.setState({ skus: this.props.skus });
    }
  };

  render() {
    let extraColumns = [];
    let filePdfName = null;
    if (
      (this.state.skus.length &&
        this.state.userAccess.canUpdateRedCrescentInventory(this.state.inventoryLocationId)) ||
      this.state.userAccess.canUpdateRedCrescentInventoryQuantity(this.state.inventoryLocationId)
    ) {
      extraColumns = [
        {
          title: <FormattedMessage id="Actions" />,
          // width: '150px',
          dataIndex: 'actions',
          key: 'actions',
          fixed: 'right',
          render: (text, record) => (
            <div className={styles.actionDiv}>
              <Tooltip title={<FormattedMessage id="Edit" />}>
                <Button
                  className={styles.editbtn}
                  type="primary"
                  shape="circle"
                  icon={<EditOutlined />}
                  onClick={() => this.onEdit(record)}
                />
              </Tooltip>
              <Tooltip title={<FormattedMessage id="Info" />}>
                <Button
                  className={styles.editbtn}
                  type="primary"
                  shape="circle"
                  icon={<InfoOutlined />}
                  onClick={() => this.onInfo(record)}
                />
              </Tooltip>
              {labType !== 'medicalredcrescent' && (
                <>
                  <Tooltip title={<FormattedMessage id="IntraWarehouseTransfer" />}>
                    <Button
                      className={styles.editbtn}
                      disabled={
                        !(
                          record &&
                          record.batches &&
                          record.batches[0] &&
                          record.batches[0].content
                        )
                      }
                      type="primary"
                      shape="circle"
                      icon={<FastForwardOutlined />}
                      onClick={() => this.requestIntraTransfer(record)}
                    />
                  </Tooltip>
                  <Tooltip title={<FormattedMessage id="DownloadQR" />}>
                    <Button
                      className={styles.editbtn}
                      type="primary"
                      disabled={
                        !(
                          record &&
                          record.batches &&
                          record.batches[0] &&
                          record.batches[0].content
                        )
                      }
                      icon={<QrcodeOutlined />}
                      shape="circle"
                      onClick={() =>
                        record &&
                        record.batches[0] &&
                        record.batches[0].content &&
                        redcrescentService.downloadQrCode(
                          JSON.parse(record.batches[0]?.content).fileKey,
                          JSON.parse(record.batches[0]?.content).fileName,
                          filePdfName,
                        )
                      }
                    />
                  </Tooltip>
                </>
              )}
            </div>
          ),
        },
      ];
    }
    if (
      this.state.skus.length &&
      !this.state.userAccess.purchaseUser(this.state.inventoryLocationId)
    ) {
      extraColumns = [...extraColumns, ...this.state.activeColumn];
    }
    const labType = window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC;
    // if (this.state.isLoading ) {
    //   return <Spin spinning={this.state.isLoading} size="large" />;
    // }

    const checkBoxAccess = this.state.userAccess.canCheckRedcrescentDeactivatedBox();
    const loc = this.props.locationsKeys[this.props.locationDetails.id];
    return (
      <div className={styles.loaderContainer} key={JSON.stringify(this.props.filters)}>
        <div style={{ textAlign: 'right' }}>
          <div className={styles.searchBarContainer}>
            <SearchBar labtype={labType} handleSearchResults={this.getResults} />
          </div>
        </div>
        <Table
          id={`table-element_${JSON.stringify(this.props.filters)}_${labType}_${this.props.userLocationId
            }`}
          columns={[...this.state.skuColumns, ...extraColumns]}
          dataSource={this.state.skus}
          rowClassName={(record) => (checkBoxAccess ? '' : !record?.active && styles.disabledRow)}
          rowKey={(record) => record.id}
          rowSelection={this.configureRowSelction()}
          onExpand={(expanded, record) =>
            this.getExpandableData(record.id, record.product.code, record)
          }
          expandedRowRender={(record) => this.expandedRowRender()}
          expandIconColumnIndex={0}
          expandedRowKeys={this.state.expandedRowKeys}
          expandIconAsCell
          rowExpandable={(record: any) => record.labType === 'medicalredcrescent'}
          pagination={{ pageSize: 100, showSizeChanger: false }}
          onChange={(e) => {
            this.getMoreInventoryRequest(e.current);
          }}
          scroll={{
            x:
              this.getTotalColumnWidth(this.state.skuColumns) +
              this.getTotalColumnWidth(this.state.activeColumn) + // All columns
              300, // Checkbox
          }}
        />
        {this.state.isLoading && (
          <div>
            {' '}
            <Spin className={styles.loader} spinning={this.state.isLoading} size="large" />{' '}
          </div>
        )}
        <AddItemModal
          labType={labType}
          locationDetails={this.props.locationDetails}
          isVisible={this.state.showAddItemRequestModal}
          currentStatus={this.state.currentStatus}
          handleCancel={this.handleCancel}
        />
        <EditModal
          searchData={this.state.searchData}
          searchApi={this.getResults}
          isVisible={this.state.showEditModal}
          skuDetails={this.state.editModalContent}
          skuBatchDetails={this.state.editModalBatches}
          handleUpdateLocators={(edits) => this.handleUpdateLocators(edits)}
          handleCancel={this.handleCancel}
          currentPage={this.props.page}
          labType={labType}
          editModalContent={this.state.editModalContent}
        />

        <InfoModal
          searchData={this.state.searchData}
          searchApi={this.getResults}
          isVisible={this.state.showInfoModal}
          skuDetails={this.state.infoModalContent}
          skuBatchDetails={this.state.infoModalBatches}
          handleCancel={this.handleCancel}
          currentPage={this.props.page}
          labType={labType}
        />

        <TransferModal
          labType={labType}
          locationDetails={this.props.locationDetails}
          isVisible={this.state.showRequestTransferModal}
          currentStatus={this.state.currentStatus}
          handleOk={(transferData: any) => this.handleTransfer(transferData)}
          handleCancel={this.handleCancel}
          selectedOrder={this.state.selectedOrder}
          type={'Transfer'}
        />
        <IssueModal
          labType={labType}
          locationDetails={this.props.locationDetails}
          isVisible={this.state.showRequestIssueModal}
          currentStatus={this.state.currentStatus}
          handleOk={(transferData: any) => this.handleTransfer(transferData)}
          handleCancel={this.handleCancel}
          selectedOrder={this.state.selectedOrder}
          type={'Issue'}
        />
        <IntraWarehouseTransferModal
          labType={labType}
          locationDetails={this.props.locationDetails}
          isVisible={this.state.showRequestIntraTransferModal}
          currentStatus={this.state.currentStatus}
          handleOk={(transferData: any) => this.handleIntraTransfer(transferData)}
          handleCancel={this.handleCancel}
          selectedOrder={this.state.record}
          expandedBatchNumber={this.state.expandedBatchNumber}
        />
        <Access
          accessible={this.state.userAccess.canPlaceRedCrescentDownloadOrder(
            this.props.locationDetails.id,
          )}
        >
          <Row className={styles.stickyFooter} gutter={[12, 0]}>
            {(this.state.userAccess.canStoreKeeper(this.props.locationDetails.id) ||
              this.state.userAccess.canPurchaseRedCrescentPurchaseOrder(
                this.props.locationDetails.id,
              )) && (
                <Col>
                  <Button type="primary" onClick={this.downloadInventory}>
                    <FormattedMessage id="Download" />
                  </Button>
                </Col>
              )}

            {this.state.autoReplenishment?.length > 0 && this.state.selectedRowKeys.length === 0 && (
              <Col>
                <OrderModal
                  inputList={this.state.autoReplenishment.map((item) => {
                    return {
                      inventoryId: item.id,
                      productId: item.productId,
                      locationId: item.locationId,
                      quantity: Math.round(item.reOrderQuantity),
                      code: item.product.code,
                      description: item.product.description,
                      arabicDescription: item.product.arabicDescription,
                      quantitiesInTransit: item.quantitiesInTransit,
                    };
                  })}
                  type="AutoReplenish"
                  locationId={this.state.inventoryLocationId}
                  count={this.state.autoReplenishment?.length}
                  btnName={<FormattedMessage id="AutoReplenish" />}
                />
              </Col>
            )}

            {!(loc === 'RIY' || loc === 'DER') && this.state.selectedRowKeys.length > 0 && (
              <Col>
                <Button
                  disabled={
                    !(
                      this.state.userAccess.canPlaceRedCrescentPurchaseOrder(
                        this.props.locationDetails.id,
                      ) || this.state.userAccess.canStoreKeeper(this.props.locationDetails.id)
                    ) || this.state.userAccess.purchaseUser(this.props.locationDetails.id)
                  }
                  type="primary"
                  onClick={this.requestTransfer}
                >
                  <FormattedMessage id="RequestTransfer" />
                </Button>
              </Col>
            )}

            {this.state.userAccess.canAddItemRedCrescent(this.props.locationDetails.id) &&
              this.state.selectedRowKeys.length === 0 && (
                <Col>
                  <Button type="primary" onClick={this.addItemRequest}>
                    <FormattedMessage id="AddItem" />
                  </Button>
                </Col>
              )}

            {/* {labType !== 'medicalredcrescent' && this.state.selectedRowKeys.length > 0 && (
              <Col>
                <Button
                  disabled={
                    !(this.state.userAccess.canPlaceRedCrescentPurchaseOrder(
                      this.props.locationDetails.id,
                    ) || this.state.userAccess.canStoreKeeper(
                      this.props.locationDetails.id,
                    )) || this.state.userAccess.purchaseUser(this.props.locationDetails.id)
                  }
                  type="primary"
                  onClick={this.requestIntraTransfer}
                >
                  <FormattedMessage id="IntraWarehouseTransfer" />
                </Button>
              </Col>
            )} */}

            {this.state.selectedRowKeys.length > 0 && (
              <Col>
                <Button
                  disabled={
                    !(
                      this.state.userAccess.canPlaceRedCrescentPurchaseOrder(
                        this.props.locationDetails.id,
                      ) || this.state.userAccess.canStoreKeeper(this.props.locationDetails.id)
                    ) || this.state.userAccess.purchaseUser(this.props.locationDetails.id)
                  }
                  type="primary"
                  onClick={this.requestIssue}
                >
                  <FormattedMessage id="Issue" />
                </Button>
              </Col>
            )}

            {this.state.selectedRowKeys.length > 0 &&
              !this.state.userAccess.cannotPlaceOrderRedCrescent(this.props.locationDetails.id) && (
                <Col>
                  <OrderModal
                    // style={this.orderModalStyles}
                    inputList={this.state.selectedOrder.map((item) => {
                      return {
                        ...item,
                        quantity: Math.round(item.reOrderQuantity),
                      };
                    })}
                    type="PlaceOrder"
                    locationId={this.state.inventoryLocationId}
                    count={this.state.selectedOrder.length}
                    btnName={<FormattedMessage id="PlaceOrder" />}
                    module={
                      window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC
                    }
                  />
                </Col>
              )}
          </Row>
        </Access>
      </div>
    );
  }
}

const InventoryTableWrapper = (props: any) => <InventoryTable {...props} access={useAccess()} />;
export default InventoryTableWrapper;

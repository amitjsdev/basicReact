import React, { useState } from 'react';
import { Row, Col, Spin, Input, Select, AutoComplete } from 'antd';
import debounce from 'lodash.debounce';
import { AutocompleteCategories, SearchCategoryNames } from '../../../POSearch/Constants';
import redcrescentService from '../../../services/redcrescent.service';
import styles from './index.less';
import { getDirection, useIntl, getLocale } from 'umi';
import { LabTypes } from '@/services/Constants';
import { ContactsOutlined } from '@ant-design/icons';
const { Option } = Select;

export default (props) => {
    const { handleSearchResults, searchLocation, onLocationChange, labtype } = props;
    const [currentLocation, setCurrentLocation] = useState(286);
    const [value, setValue] = useState('');
    const [options, setOptions] = useState([]);
    const [isLoading, setLoading] = useState(false);

    const getRelatedSearchTerms = async (searchText, currentLocation) => {
        setLoading(true);
        const labType = window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC;

        const results = await redcrescentService.getSerachData(searchText, labType);
      
        const parsedResults =
        results && results.data && Object.keys(results.data).length > 0
                ? Object.keys(results.data)
                    ?.map((category) => {
                        return {
                            label: AutocompleteCategories[category],
                            options: results.data[category].map((value) => ({ value, category: category })),
                          };
                    })
                    .filter((category) => category.options.length)
                : [];
        setOptions(parsedResults);
        setLoading(false);
    };

    const handleSearch = debounce(getRelatedSearchTerms, 200);

    const clearSearchValue = () => {
        handleSearchResults('');
        setValue('');
        setOptions([]);
    };
    return (
        <div className={styles.container}>
            <Row gutter={[24, 24]}>
                <Col>
                    <Input.Group size="large">
                        <Row>
                            <Col span={23}>
                                {getLocale() === 'ar-EG' && (
                                    <button className={styles.close} onClick={clearSearchValue}>
                                        X
                                    </button>
                                )}
                                 <AutoComplete
                  style={{ width: 400 }}
                  className={getDirection() === 'rtl' ? 'search-rtl' : ''}
                  options={options}
                  value={value}
                  direction={getDirection()}
                  onChange={(x, y, data) => {
                    setOptions([]);
                    setValue(x);
                    handleSearchResults('');
                  }}
                  onSearch={(searchText) => {
                    if (searchText && searchText.length >= 1)
                      handleSearch(searchText, currentLocation, labtype);
                  }}
                  onSelect={handleSearchResults}
                  notFoundContent={useIntl().formatMessage({ id: 'NoDataFound' })}
                  allowClear={getDirection() !== 'rtl'}
                />
                            </Col>
                        </Row>
                    </Input.Group>
                </Col>
                <Col>
                    <Spin spinning={isLoading} />
                </Col>
            </Row>
        </div>
    );
};

import React, { useEffect, useState } from 'react';
import { Modal, Form, Button, Radio, Input, InputNumber, Space, DatePicker } from 'antd';
import moment from 'moment';
import { PlusOutlined } from '@ant-design/icons';
import { Row, Col, Select, Divider, message } from 'antd/es';
import { useIntl, FormattedMessage, formatMessage, getLocale } from 'umi';
import redCrescentService from '../../../services/redcrescent.service';

import styles from './index.less';

const AddItem: React.FC<any> = (props) => {
  const { updateModalData, labType, isVisible } = props;
  const [form] = Form.useForm();
  const [formSubmit, setFormSubmit] = useState(false);
  const [loading, setLoading] = useState(false);
  const [dataArr, setdataArr] = useState([0]);
  const [hasEmergency, seHasEmergency] = useState(false);
  const [inputList, setInputList] = useState([]);
  const [engClassification, setEngClassification] = useState([]);
  const [arabicClassification, setArabicClassification] = useState([]);
  const [engCategory, setEngCategory] = useState([]);
  const [arabicCategory, setArabicCategory] = useState([]);
  const [resultData, setResultData] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState([]);
  const [selectedClassification, setSelectedClassification] = useState([]);

  const dateFormat = 'YYYY-MM-DD';

  const onCancel = () => {
    setdataArr([0]);
    props.handleCancel();
  };

  useEffect(() => {
    (async () => {
      let engCategory = [];
      let category = [];
      const locale = getLocale();
      const resultVal = (await redCrescentService.getPopulatedClassifications(labType)) || [];
      setResultData(resultVal?.results?.data);
      resultVal &&
        resultVal.results &&
        resultVal.results.data.map((res) => {
          if (!category.includes(res.category)) {
            category.push(res.category);
            engCategory.push({ label: res.category, value: res.arabicCategory });
          }
        });

      setEngCategory(engCategory);

    })();
  }, [labType, isVisible]);

  const onFinish = (values) => {
    let data = [...inputList];


    let sameCode = false;
    if (data.length > 0) {

      for (let i = 0; i < data.length; i++) {
        for (let j = 0; j < data.length; j++) {
          if (i != j && data[i].code == data[j].code) {
            message.error("SameCode");
            return (sameCode = true);
          }
        }
      }
    }
    if (data && !sameCode) {
      data.forEach(function (v) {
        delete v.index;

      });

      redCrescentService.addItemRequest(data).then(() => {
        props.handleCancel();
        setLoading(false);
        setFormSubmit(false);
        setInputList([]);
      });
      setFormSubmit(true);
      form.resetFields();
    }
  };

  const handleCancel = () => {
    props.handleCancel();
    form.resetFields();
    setInputList([]);
  };

  const handleInputChange = (e, index) => {

    const { name, value } = e.target;
    let arabic = '';
    let arabicCl = '';
    let classification = [];
    let eng = [];
    let flag = 0;
    let ob = {};
    if (name == 'category') {
      setEngClassification([]);
      resultData.map((res) => {
        if ((res.category) === value && flag === 0) {

          if (!classification.includes(res.classification)) {
            classification.push(res.classification);
            eng.push({ label: res.classification, value: res.arabicClassification });
          }
          arabic = res.arabicCategory;

        }

        let catIndexData = selectedCategory.findIndex((x) => x.index == index);
        ob = {
          index,
          category: res.category,
          arabicCategory: res.arabicCategory,
          classifications: eng,
        }
        if (catIndexData !== -1) {

          selectedCategory.splice(catIndexData, 1, { index, ob, classifications: eng });
          setSelectedCategory([...selectedCategory]);
        } else {

          setSelectedCategory([...selectedCategory, { index, ob, classifications: eng }]);
        }

      });
      setEngClassification(eng);
    }


    if (name === 'classification' && labType !== 'medicalredcrescent') {

      engClassification.map((c) => {

        if (c.label === value) {

          const obj = {
            index,
            classification: c.label,
            arabicClassification: c.value
          }
          let catIndexData = selectedClassification.findIndex((x) => x.index == index);
          arabicCl = c.value;
          if (catIndexData !== -1) {
            selectedClassification.splice(catIndexData, 1);
            setSelectedClassification([...selectedClassification, { index, obj }]);
          } else {

            setSelectedClassification([...selectedClassification, { index, obj }]);
          }
        }
      })
    }

    let arr = [...inputList];
    let indexData = inputList.findIndex((x) => x.index == index);
    let obj = { labType: props.labType, hasEmergency: false };
    if (indexData > -1) {

      obj = { ...arr[indexData] };

    } else {
      obj.index = index;
    }
    if (name === 'category') {
      obj['arabicCategory'] = arabic;
    }
    if (name === 'classification' && labType !== 'medicalredcrescent') {

      obj['arabicClassification'] = arabicCl;
    }
    obj[name] = value;

    if (indexData > -1) {
      arr.splice(indexData, 1, obj);
      // arr[indexData] = obj;

    } else {
      arr.push(obj);
    }
    setInputList(arr);

  };

  const obj = [];
  return (
    <Modal
      title={useIntl().formatMessage({ id: 'AddItem' })}
      visible={props.isVisible}
      footer={null}
      afterClose={() => handleCancel()}
      closable={false}
      width="50%"
      destroyOnClose
    >
      <>
        {/* <Spin className={styles.loader} spinning={isLoading} size="large" /> */}
        <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
          {dataArr &&
            dataArr.map((v, i) => {
              return (
                <>
                  <div style={{ marginTop: '5px' }}>
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        padding: '0px 42px',
                      }}
                    ></div>
                    <Row gutter={[24, 24]} align="middle">
                      <Col span={11}>
                        <Form.Item
                          label={useIntl().formatMessage({ id: 'Code' })}
                          name={`code_${i}`}
                          rules={[
                            {
                              required: true,
                              message: useIntl().formatMessage({ id: 'MissingCode' }),
                            },
                          ]}
                        >
                          <Input
                            name="code"
                            style={{ width: '100%' }}
                            onChange={(value) =>
                              handleInputChange(
                                { target: { value: value.target.value, name: 'code' } },
                                i,
                              )
                            }
                          />
                        </Form.Item>
                      </Col>
                      <Col span={11}>
                        <Form.Item
                          label={useIntl().formatMessage({ id: 'Description' })}
                          name={`description_${i}`}
                          rules={[
                            {
                              required: true,
                              message: useIntl().formatMessage({ id: 'MissingDescription' }),
                            },
                          ]}
                        >
                          <Input
                            name="description"
                            style={{ width: '100%' }}
                            onChange={(value) =>
                              handleInputChange(
                                { target: { value: value.target.value, name: 'description' } },
                                i,
                              )
                            }
                          />
                        </Form.Item>
                      </Col>
                      {engCategory && engCategory.length > 0 && (
                        <Col span={11}>
                          <Form.Item
                            label={useIntl().formatMessage({ id: 'Category' })}
                            // name={`category_${i}`}
                            rules={[
                              {
                                required: true,
                                message: useIntl().formatMessage({ id: 'MissingCategory' }),
                              },
                            ]}
                          >
                            <Select
                              onChange={(value) =>
                                handleInputChange({ target: { value: value, name: 'category' } }, i)
                              }
                            >
                              {engCategory &&
                                engCategory.map((category) => {

                                  return (
                                    <Option key={category.label} value={category.label}>
                                      {`${category.label}(`}{`${category.value})`}
                                    </Option>
                                  );
                                })}
                            </Select>

                            {/* <Input name="category" style={{ width: '100%' }} /> */}
                          </Form.Item>
                        </Col>
                      )}
                      {labType !== 'medicalredcrescent' &&
                        selectedCategory &&
                        selectedCategory.length > 0 && (
                          <Col span={11} >
                            <Form.Item
                              label={useIntl().formatMessage({ id: 'Classification' })}
                              name={`classification_${i}`}
                              rules={[
                                {
                                  required: true,
                                  message: useIntl().formatMessage({ id: 'MissingClassification' }),
                                },
                              ]}
                            >
                              <Select
                                onChange={(value) =>
                                  handleInputChange(
                                    { target: { value: value, name: 'classification' } },
                                    i,
                                  )
                                }
                              >
                                {selectedCategory && selectedCategory.length > i &&
                                  selectedCategory[i].classifications.map((classification) => {

                                    return (
                                      <Option key={classification.label} value={classification.label}>
                                        {`${classification.label}(`}{`${classification.value})`}
                                      </Option>
                                    );
                                  })}
                              </Select>
                            </Form.Item>
                          </Col>
                        )}

                      <Col span={11}>
                        <Form.Item
                          label={useIntl().formatMessage({ id: 'ArabicDescription' })}
                          name={`arabicDescription_${i}`}
                          rules={[
                            {
                              required: true,
                              message: useIntl().formatMessage({
                                id: 'MissingArabicClassification',
                              }),
                            },
                          ]}
                        >
                          <Input
                            name="arabicDescription"
                            style={{ width: '100%' }}
                            onChange={(value) =>
                              handleInputChange(
                                {
                                  target: { value: value.target.value, name: 'arabicDescription' },
                                },
                                i,
                              )
                            }
                          />
                        </Form.Item>
                      </Col>

                      <Col span={11}>
                        <Form.Item
                          label={useIntl().formatMessage({ id: 'UnitOfMeasures' })}
                          name={`unitOfMeasures_${i}`}
                          rules={[
                            {
                              required: true,
                              message: useIntl().formatMessage({ id: 'MissingUnitOfMeasures' }),
                            },
                          ]}
                        >
                          <Input
                            name="unitOfMeasures"
                            style={{ width: '100%' }}
                            onChange={(value) =>
                              handleInputChange(
                                { target: { value: value.target.value, name: 'unitOfMeasures' } },
                                i,
                              )
                            }
                          />
                        </Form.Item>
                      </Col>
                    </Row>
                    {/* <Row gutter={[24, 24]} align="middle">
                      <div
                        style={{
                          justifyContent: 'space-between',
                          // marginBottom: '10px',
                        }}
                      >
                        <span>{useIntl().formatMessage({ id: 'HasEmergency' })}:</span>
                      </div>
                      <Col span={11}>
                        <Space align="center">
                          <Radio.Group
                            onChange={(value) =>
                              handleInputChange(
                                { target: { value: value.target.value, name: 'hasEmergency' } },
                                i,
                              )
                            }
                            value={hasEmergency}
                          >
                            <Radio value={false}>{formatMessage({ id: 'No' })}</Radio>
                            <Radio value={true}>{formatMessage({ id: 'Yes' })}</Radio>
                          </Radio.Group>
                        </Space>
                      </Col>
                    </Row> */}
                  </div>
                </>
              );
            })}
          <Button
            className={styles.btnText}
            type="dashed"
            style={{ marginBottom: '20px' }}
            onClick={() => {
              let incObj = obj.length;
              obj.push(incObj);
              setdataArr([...dataArr, obj]);
            }}
            block
          >
            <PlusOutlined /> {useIntl().formatMessage({ id: 'Add' })}
          </Button>
          <Row gutter={[24, 24]}>
            <Col flex={1}>
              <Form.Item>
                <Button
                  disabled={formSubmit}
                  type="primary"
                  htmlType="submit"
                  block
                  loading={formSubmit}
                >
                  {useIntl().formatMessage({ id: 'Update' })}
                </Button>
              </Form.Item>
            </Col>
            <Col flex={1}>
              <Form.Item>
                <Button onClick={onCancel} block>
                  {useIntl().formatMessage({ id: 'Cancel' })}
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </>
    </Modal>
  );
};

export default AddItem;


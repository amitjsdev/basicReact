import React, { useEffect, useState } from 'react';
import { PlusOutlined } from '@ant-design/icons';
import {
  Form,
  Button,
  Row,
  Col,
  Modal,
  Select,
  Input,
  InputNumber,
  message,
  Spin,
  Radio,
  Divider,
} from 'antd';
import redCrescentService from '../../../services/redcrescent.service';
import styles from './index.less';
import { useIntl, getLocale, formatMessage } from 'umi';
const { Option } = Select;

const BasicIssueForm = (props: any) => {
  const {
    selectedLocation,
    setSelectedLocation,
    locations,
    locationDetails,
    locationName,
    quantity,
    labType,
    selectedOrder,
    batchData,
    setdataArr,
    dataArr,
    data,
    setData,
    warehouse,
    subWarehouses,
    setsubWarehouses,
    type,
  } = props;
  const [isLoading, setIsLoading] = useState(false);
  const [formSubmit, setFormSubmit] = useState(false);
  const [selectedBatchNumber, setSelectedBatchNumber] = useState([]);
  const [batchLocators, setLocators] = useState([]);
  const [selectedWareHouse, setSelectedWareHouse] = useState([]);
  const [form] = Form.useForm();
  const [extraFields, setExtraFields] = useState([]);
  const onFinish = (values: any) => {
   
    if (data && data.length > 0) {
      let wareHouseCheck = false;
      for (let i = 0; i < data.length; i++) {
        if (data[i]?.mainWarehouseId) {
        } else {
          wareHouseCheck = true;
          break;
        }
      }

      if (wareHouseCheck) {
        message.error(formatMessage({ id: 'MissingWareHouse' }));
        return;
      }

      let nonData = false;
      let checkWareHouse = false;
      if (selectedWareHouse.length > 0 && labType == 'medicalredcrescent') {
        for (let i = 0; i < selectedWareHouse.length; i++) {
          if (
            selectedWareHouse.indexOf(selectedWareHouse[i]) !==
            selectedWareHouse.lastIndexOf(selectedWareHouse[i])
          ) {
            checkWareHouse = true;
            break;
          }
        }
      }
      if (checkWareHouse) {
        message.error('CanNotSelectSameWarehouseMultipleTimes.');
      } else {
        if (labType === 'nonmedicalredcrescent') {
          if (data && data.length > 0) {
            let total = 0;
            for (var i = 0; i < data.length; i++) {
              //  data[i]['batchId'] = batchData[0].id;

              let dataQty = selectedOrder.find(
                (dataItem) => dataItem.productId == data[i].productId,
              );

              let particularLocators = dataQty.batches[0].locators;

              let index = particularLocators.findIndex(
                (loc) =>
                  loc.mainWarehouseId === data[i].mainWarehouseId &&
                  loc.locatorId === data[i].locatorId,
              );

              if (particularLocators[index].quantity < data[i].approvedQuantity) {
                message.error(
                  particularLocators[index].quantity +
                  ' ' +
                  formatMessage({ id: 'QuantityAvailableIn' }) +
                  ' ' +
                  particularLocators[index]?.mainWarehouseName +
                  ' ' +
                  (particularLocators[index]?.subWarehouseId != null
                    ? particularLocators[index]?.subWarehouseName
                    : '') +
                  ' ' +
                  (particularLocators[index]?.locatorId != null
                    ? particularLocators[index]?.locatorId
                    : ''),
                );
                return;
              }
            }
          }
        }

        if (nonData) {
          // message.error(formatMessage({ id: 'CannotBeMoreThanCurrentQuantity' }));
        } else {
          let dataCheck = false;
          let qtyVal;
          let batchName;
          let locatorsError = false;
          // return false
          batchData &&
            batchData.length > 0 &&
            batchData.map((batch) => {
              let dataFind = data.filter((dataItem) => dataItem.batchId == batch.id);
              if (dataFind && dataFind.length > 0) {
                dataFind.map((data) => {
                  let dataQty = selectedOrder.find(
                    (dataItem) => dataItem.productId == data.productId,
                  );
                  let i = dataQty.batches.findIndex((d) => data.batchId == d.id);
                  if (i !== -1) {
                    let particularLocators = dataQty.batches[i]?.locators;
                    let index = particularLocators.findIndex(
                      (loc) =>
                        loc.mainWarehouseId === data.mainWarehouseId &&
                        loc.locatorId === data.locatorId,
                    );

                    if (particularLocators[index].quantity < data.approvedQuantity) {
                      dataCheck = true;
                      qtyVal = particularLocators[index].quantity;
                      batchName =
                        particularLocators[index].mainWarehouseName +
                        ' ' +
                        (particularLocators[index].subWarehouseId != null
                          ? particularLocators[index].subWarehouseName
                          : '') +
                        ' ' +
                        particularLocators[index].locatorId;
                      return;
                    }
                  }
                });
              }
            });
          if (dataCheck) {
            message.error(
              qtyVal + ' ' + formatMessage({ id: 'QuantityAvailableIn' }) + ' ' + batchName,
            );
          } else {
            const quantityCheck = data.find(
              (item) => isNaN(item.approvedQuantity) || item.approvedQuantity <= 0,
            );
            if (quantityCheck) {
              message.error(formatMessage({ id: 'QuantityShouldBeNumericAndGreaterThan0' }));
            } else {
              const payload = {
                item: [...data],
                type,
                extraFields,
              };

              props.handleOk(payload);

              setIsLoading(true);
              setFormSubmit(true);
            }
          }
        }
      }
    } else {
      let wareHouseCheck = false;
      for (let i = 0; i < data.length; i++) {
        if (data[i]?.mainWarehouseId) {
        } else {
          wareHouseCheck = true;
        }
      }

      if (wareHouseCheck) {
        message.error(formatMessage({ id: 'MissingWareHouse' }));
        return;
      }
      if (quantity.length == 0) {
        message.error(formatMessage({ id: 'PleaseEnterQuantity' }));
      } else {
        message.error(formatMessage({ id: 'PleaseSelectLocation' }));
      }
    }
  };

  const onCancel = () => {
    props.handleCancel();
  };

  const handleChangeExtraFields = (value, index, name, type) => {

    let arr = [...extraFields];
    let indexData = extraFields.findIndex((x) => x.index == index);
    let obj = {};
    if (indexData > -1) {
      obj = { ...extraFields[indexData] };
    } else {
      obj.index = index;
    }
    obj[name] = value;
    if (indexData > -1) {
      arr[indexData] = obj;
    } else {
      arr.push(obj);
    }
    setExtraFields(arr)
  }

  const handleChange = (value, index, type, productId, wareHouseindex) => {



    let arr = [...data];
    let indexData = data.findIndex((x) => x.index == index);
    let obj = {};
    if (indexData > -1) {
      obj = { ...data[indexData] };
    } else {
      obj.index = index;
    }

    if (type === 'mainWarehouseId') {
      const tmpArr = value.split('__');
      const mainWarehouseId = tmpArr[0].split('main_')[1];
      const subWarehouseId = tmpArr[1].split('sub_')[1];
      const locatorId = tmpArr[2].split('loc_')[1];
      if (typeof mainWarehouseId !== 'undefined') {
        obj[type] = parseInt(mainWarehouseId);
      } else {
        delete obj['mainWarehouseId'];
      }
      if (typeof subWarehouseId != 'undefined') {
        obj['subWarehouseId'] = parseInt(subWarehouseId);
      } else {
        delete obj['subWarehouseId'];
      }
      if (locatorId !== 'undefined') {
        obj['locatorId'] = locatorId;
      } else {
        obj['locatorId'] = null;
      }
      if (selectedWareHouse.length > 0) {
        selectedWareHouse.splice(wareHouseindex, 1);
      }
      setSelectedWareHouse([...selectedWareHouse, value]);
    } else if (type === 'batchId' && labType !== 'nonmedicalredcrescent') {
      const batch = batchData && batchData.length > 0 && batchData.find((item) => item.id == value);
      let locators = [];

      for (let i = 0; i < batchData.length; i++) {
        if (batchData[i].id == value && batchData[i].locators) {
          locators.push(...batchData[i].locators);
        }
      }
      const subwareHouseVal =
        locators[0]?.subWarehouseId != '' || locators[0]?.subWarehouseId != null
          ? parseInt(locators[0]?.subWarehouseId)
          : '';
      if (subwareHouseVal !== '') {
        obj = {
          ...obj,
          inventoryId: batch.inventoryId,
          batchId: batch.id,
          productId: batch.productId,
          mainWarehouseId: parseInt(locators[0]?.mainWarehouseId),
          subWarehouseId: parseInt(locators[0]?.subWarehouseId),
          locatorId: locators[0]?.locatorId,
        };
      } else {
        obj = {
          ...obj,
          inventoryId: batch.inventoryId,
          batchId: batch.id,
          productId: batch.productId,
          mainWarehouseId: parseInt(locators[0]?.mainWarehouseId),
          locatorId: locators[0]?.locatorId,
        };
      }
      const id = `main_${locators[0]?.mainWarehouseId}__sub_${!!locators[0]?.subWarehouseId ? batch?.subWarehouseId : ''
        }__loc_${locators[0]?.locatorId}`;

      if (id !== "main_undefined__sub___loc_undefined") {
        if (!selectedWareHouse.includes(id)) {
          setSelectedWareHouse([...selectedWareHouse, id]);
        }


      }
      if (selectedBatchNumber.length >= productId) {
        selectedBatchNumber.splice(productId, 1);
      }


      const locIndex = batchLocators.findIndex((locI) => locI.index === index);
      if (locIndex !== -1) {
        setFormSubmit(false);
        batchLocators.splice(locIndex, 1, locators);
      }

      setSelectedBatchNumber([...selectedWareHouse, batch.id]);
      setLocators([...batchLocators, { index, locators }]);

    } else {
      obj[type] = value;
      let locIndex = -1;
      if (batchLocators.length > 0) {
        locIndex = batchLocators.findIndex((locI) => locI.index === index);
      }

      if (labType !== 'medicalredcrescent' && type === 'approvedQuantity') {
        const batch =
          batchData && batchData.length > 0 && batchData.find((item) => item.id == productId);
        let locators = batch?.locators;

        if (locators && locators.length > 0) {
          const subwareHouseVal =
            locators[0]?.subWarehouseId != '' || locators[0]?.subWarehouseId != null
              ? parseInt(locators[0]?.subWarehouseId)
              : '';
          if (subwareHouseVal !== '') {
            obj = {
              ...obj,
              inventoryId: batch.inventoryId,
              batchId: productId,
              productId: batch.productId,
              mainWarehouseId: parseInt(locators[0]?.mainWarehouseId),
              subWarehouseId: parseInt(locators[0]?.subWarehouseId),
              locatorId: locators[0]?.locatorId,
            };
          } else {
            obj = {
              ...obj,
              inventoryId: batch.inventoryId,
              batchId: productId,
              productId: batch.productId,
              mainWarehouseId: parseInt(locators[0]?.mainWarehouseId),
              locatorId: locators[0]?.locatorId,
            };
          }
          if (selectedWareHouse.length > 0) {
            selectedWareHouse.splice(wareHouseindex, 1);
          }

          setSelectedWareHouse([...selectedWareHouse, value]);
          if (selectedBatchNumber.length >= productId) {
            selectedBatchNumber.splice(productId, 1);
          }

          const locIndex = batchLocators.findIndex((locI) => locI.index === index);
          if (locIndex !== -1) {
            setFormSubmit(false);
            batchLocators.splice(locIndex, 1, locators);
          }

          setSelectedBatchNumber([...selectedWareHouse, batch.id]);
          setLocators([...batchLocators, { index, locators }]);
        }

      }
    }

    if (indexData > -1) {
      arr[indexData] = obj;
    } else {
      arr.push(obj);
    }
    setData(arr);
  };
  return (
    <>
      <Spin className={styles.loader} spinning={isLoading} size="large" />
      <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
        {type === 'Transfer' && (
          <Row gutter={[24, 24]}>
            <Col flex={1}>
              <Form.Item
                label={useIntl().formatMessage({ id: 'ToLocation' })}
                name={locationName}
                rules={[
                  {
                    required: true,
                    message: formatMessage({ id: 'PleaseChangeTheLocation' }),
                  },
                ]}
              >
                {locations && locations.length > 0 && (
                  <Select onChange={(value) => setSelectedLocation(value)}>
                    {locations &&
                      locations.map((location) => {
                        if (location.id !== locationDetails.id) {
                          return (
                            <Option key={location.id} value={location.id}>
                              {location.name}
                            </Option>
                          );
                        }
                      })}
                  </Select>
                )}
              </Form.Item>
            </Col>
          </Row>
        )}

        <div style={{ marginTop: '5px' }}>
          {selectedOrder &&
            selectedOrder.length > 0 &&
            selectedOrder.map((dataVal, index) => {
              const obj =
                dataArr &&
                dataArr.length > 0 &&
                dataArr.find((item) => item.id == dataVal.inventoryId);

              return (
                obj &&
                obj.dataLength.map((itemData, indexObj) => {
                  return (
                    <>
                      <div>
                        <Row gutter={[12, 12]} align="middle">
                          <Col span={11}>
                            <Form.Item label={useIntl().formatMessage({ id: 'Product' })}>
                              <Input
                                name="product"
                                value={
                                  getLocale() === 'ar-EG'
                                    ? dataVal.arabicDescription
                                    : dataVal.description
                                }
                              />
                            </Form.Item>
                          </Col>
                          <Col span={11} className={styles.colheight}>
                            <Form.Item label={useIntl().formatMessage({ id: 'Code' })}>
                              <Input name="product" value={dataVal.code} />
                            </Form.Item>
                          </Col>
                        </Row>
                        <Row gutter={[24, 24]} align="middle">
                          {labType === 'medicalredcrescent' && (
                            <Col span={11}>
                              <Form.Item
                                label={useIntl().formatMessage({ id: 'FromBatchNumber' })}
                                name={`batch${indexObj}${index}`}
                                rules={[
                                  {
                                    required: true,
                                    message: formatMessage({ id: 'PleaseSelectTheBatch' }),
                                  },
                                ]}
                              >
                                <Select
                                  onChange={(value) => {
                                    handleChange(
                                      value,
                                      `${indexObj}${index}`,
                                      'batchId',
                                      indexObj,
                                      dataVal.productId,
                                    );
                                  }}
                                >
                                  {batchData &&
                                    batchData.length > 0 &&
                                    batchData.map((batch) => {
                                      if (batch.productId === dataVal.productId) {
                                        return (
                                          <Option
                                            key={batch.id}
                                            value={batch.id}
                                          >
                                            {batch.batchNumber}
                                          </Option>
                                        );
                                      }
                                    })}
                                </Select>
                              </Form.Item>
                            </Col>
                          )}
                          <Col span={11} className={styles.colheight}>
                            <Form.Item
                              className={styles.colInput}
                              label={useIntl().formatMessage({ id: 'Quantity' })}
                              name={`approvedQuantity${indexObj}${index}`}
                              rules={[
                                {
                                  required: true,
                                  message: useIntl().formatMessage({ id: 'MissingQuantity' }),
                                },
                                {
                                  type: 'number',
                                  min: 1,
                                  message: 'Should be more than 0',
                                },
                              ]}
                            >
                              <InputNumber
                                placeholder="quantity"
                                precision={0}
                                style={{ width: '100%' }}
                                onChange={(value) => {
                                  handleChange(
                                    value,
                                    `${indexObj}${index}`,
                                    'approvedQuantity',
                                    dataVal?.batches[0]?.id,
                                  );
                                }}
                              />

                            </Form.Item>
                            {data && data.map((d) => {
                              return (
                                d.index == `${indexObj}${index}` &&
                                batchLocators && batchLocators.map((batch) => {
                                  return (
                                    batch.index == `${indexObj}${index}` &&
                                    batch.locators.map((loc) => {
                                      if (loc.mainWarehouseId == d.mainWarehouseId &&
                                        loc.locatorId == d.locatorId) {

                                        return <span className={styles.alignright}>{useIntl().formatMessage({ id: `MaximumQuantity` })}  :{loc.quantity}</span>;
                                      }
                                    })
                                  )
                                })
                              )
                            })}
                          </Col>

                        </Row>
                        {batchLocators.find(
                          (locator) => locator.index == `${indexObj}${index}`,
                        ) && (
                            <>
                              <div
                                style={{
                                  justifyContent: 'space-between',
                                  marginBottom: '10px',
                                }}
                              >
                                {/* <span>{useIntl().formatMessage({ id: 'FromWareHouse' })}:</span> */}
                              </div>

                              <Row gutter={[12, 12]} align="middle">
                                {batchLocators.map((batch) => {
                                  if (
                                    batch.index == `${indexObj}${index}` &&
                                    batch?.locators &&
                                    batch?.locators.length > 0
                                  ) {
                                    const batchValId = labType === "medicalredcrescent" ? batch.locators[0].batchId : dataVal.productId
                                    return (
                                      <Radio.Group
                                        name={`locator${indexObj}${index}`}
                                        defaultValue={
                                          batch.index == `${indexObj}${index}`
                                            ? `main_${batch.locators[0]?.mainWarehouseId}__sub_${batch.locators[0]?.subWarehouseId}__loc_${batch.locators[0]?.locatorId}`
                                            : null
                                        }
                                        className={styles.radioFormat}
                                        onChange={(e) =>
                                          handleChange(
                                            e.target.value,
                                            `${indexObj}${index}`,
                                            'mainWarehouseId',
                                            batchValId,
                                            index,
                                          )
                                        }
                                      >
                                        {batch.locators.map((locator) => {
                                          const id = `main_${locator.mainWarehouseId}__sub_${locator.subWarehouseId}__loc_${locator.locatorId}`;

                                          return (
                                            <Col className={styles.maxWidthRadio} span={11}>
                                              <Radio value={id}>{`${!!locator.mainWarehouseName
                                                ? `${locator.mainWarehouseName} `
                                                : ''
                                                } ${!!locator.subWarehouseName
                                                  ? `${locator.subWarehouseName} `
                                                  : ''
                                                } ${!!locator.locatorId ? `${locator.locatorId} ` : ''
                                                }`}</Radio>
                                            </Col>
                                          );
                                        })}
                                      </Radio.Group>
                                    );
                                  }
                                })}

                              </Row>


                            </>
                          )}

                      </div>
                      {
                        indexObj == obj.dataLength.length - 1 &&
                        labType !== 'nonmedicalredcrescent' && (
                          <Button
                            className={styles.btnText}
                            type="dashed"
                            onClick={() => {
                              const indexData = dataArr.find(
                                (item) => item.id == dataVal.inventoryId,
                              );
                              let arr = [...dataArr];
                              let objData = { ...obj };
                              objData.dataLength.push([]);
                              arr[indexData] = objData;
                              setdataArr(arr);
                            }}
                            block
                          >
                            <PlusOutlined /> {useIntl().formatMessage({ id: 'Add' })}
                          </Button>
                        )
                      }
                    </>
                  );
                })
              );
            })}
              <Divider plain />
          <Row gutter={[24, 24]} align="middle">
            <Col span={11}>
              <Form.Item
                label={formatMessage({
                  id: 'NameOfRequester',
                })}
                name={`requester`}
                rules={[
                  {
                    required: true,
                    message: formatMessage({
                      id: 'MissingRequester',
                    }),
                  },
                ]}
              >
                <Input
                  onChange={(value) =>
                    handleChangeExtraFields(
                      value.target.value,
                      `0`,
                      'requester',
                      'outSide',
                    )
                  }
                  style={{ width: '100%' }}
                />
              </Form.Item>
            </Col>
            <Col span={11} className={styles.colheight}>
              <Form.Item
                label={formatMessage({
                  id: 'NameOfRequestingCenter',
                })}
                name={`requestingCity`}
                rules={[
                  {
                    required: true,
                    message: formatMessage({
                      id: 'MissingRequestingCity',
                    }),
                  },
                ]}
              >
                <Input
                  onChange={(value) =>
                    handleChangeExtraFields(
                      value.target.value,
                      `0`,
                      'requestingCity',
                      'outSide',
                    )
                  }
                  style={{ width: '100%' }}
                />
              </Form.Item>
            </Col>

          </Row>

          <Row gutter={[24, 24]} align="middle">
            <Col span={11}>
              <Form.Item
                label={formatMessage({
                  id: 'Remarks',
                })}
                name={`remarks`}
                rules={[
                  {
                    type: 'string'
                  },
                ]}

              >
                <Input
                  onChange={(value) =>
                    handleChangeExtraFields(
                      value.target.value,
                      `0`,
                      'remarks',
                      'outSide',
                    )
                  }
                  style={{ width: '100%' }}
                />
              </Form.Item>
            </Col>


          </Row>
        </div>

        <Row gutter={[24, 24]}>
          <Col flex={1}>
            <Form.Item>
              {formSubmit && isLoading ? (
                <Button disabled={formSubmit} type="primary" htmlType="submit" block loading>
                  {useIntl().formatMessage({ id: 'Apply' })}
                </Button>
              ) : (
                <Button disabled={formSubmit} type="primary" htmlType="submit" block>
                  {useIntl().formatMessage({ id: 'Apply' })}
                </Button>
              )}
            </Form.Item>
          </Col>
          <Col flex={1}>
            <Form.Item>
              <Button onClick={onCancel} block>
                {useIntl().formatMessage({ id: 'Cancel' })}
              </Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </>
  );
};

const IssueModal = (props: any) => {
  const {
    currentStatus,
    handleOk,
    handleCancel,
    isVisible,
    locationDetails,
    labType,
    selectedOrder,
    type,
  } = props;
  const [selectedLocation, setSelectedLocation] = useState('');
  const [locations, setLocations] = useState([]);
  const [dataArr, setdataArr] = useState([]);
  const [data, setData] = useState([]);
  const locDropdown: [] = [];
  const [warehouse, setWarehouse] = useState([]);
  const [batchData, setBatchData] = useState([]);
  const [subWarehouses, setsubWarehouses] = useState([]);

  async function fetchMyAPI(selectedOrder) {
    if (selectedOrder && selectedOrder.length > 0) {
      const arrayData = [];
      let arr = [];
      for (let i = 0; i < selectedOrder.length; i++) {
        let obj = { id: selectedOrder[i].inventoryId, dataLength: [[]] };
        if (!arr.find((item) => item.id == obj.id)) {
          arr.push(obj);
        }
        setdataArr(arr);
        // const skuBatchDetails = await redCrescentService.getBatches(selectedOrder[i].inventoryId);

        arrayData.push(...selectedOrder[i].batches);
      }
      setBatchData(arrayData);
    }
  }
  useEffect(() => {
    if (selectedOrder != null && isVisible) {
      redCrescentService.getLocations('medicalredcrescent').then((locations: any) => {
        locations.map((lab: any) => {
          locDropdown.push(lab);
        });
        setLocations(locDropdown);
      });
    }

    fetchMyAPI(selectedOrder);
    // var labtype = window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC;
    if (isVisible) {
      redCrescentService.getWareHouses('medicalredcrescent').then((data) => {
        setWarehouse(data);
      });
    }
  }, [selectedOrder, isVisible]);
  return (
    <>
      <Modal
        title={
          type === 'Transfer'
            ? useIntl().formatMessage({ id: 'TRANSFER' })
            : useIntl().formatMessage({ id: 'Issue' })
        }
        visible={isVisible}
        afterClose={() => handleCancel()}
        destroyOnClose
        closable={false}
        footer={false}
        width="50%"
      >
        <BasicIssueForm
          batchData={batchData}
          setsubWarehouses={setsubWarehouses}
          subWarehouses={subWarehouses}
          type={type}
          setdataArr={setdataArr}
          dataArr={dataArr}
          setData={setData}
          data={data}
          warehouse={warehouse}
          setWarehouse={setWarehouse}
          currentStatus={currentStatus}
          labType={labType}
          selectedLocation={selectedLocation}
          setSelectedLocation={setSelectedLocation}
          locations={locations}
          locationDetails={locationDetails}
          handleOk={(updatedBatches: any) => handleOk(updatedBatches)}
          handleCancel={() => {
            handleCancel();
            setSelectedLocation('');
            setdataArr([]);
            setData([]);
            setsubWarehouses([]);
          }}
          selectedOrder={selectedOrder}
        />
      </Modal>
    </>
  );
};

export default IssueModal;

import React, { useEffect, useState } from 'react';
import { PlusOutlined } from '@ant-design/icons';
import {
  Form,
  Button,
  Row,
  Col,
  Modal,
  Select,
  Input,
  InputNumber,
  message,
  Spin,
  Radio,
  Typography,
} from 'antd';
import redCrescentService from '../../../services/redcrescent.service';
import styles from './index.less';
import { useIntl, getLocale, formatMessage } from 'umi';
const { Option } = Select;

const BasicTransferForm = (props: any) => {
  const {
    isVisible,
    selectedLocation,
    locations,
    locationDetails,
    locationName,
    setQuantity,
    quantity,
    labType,
    selectedOrder,
    batchData,
    setdataArr,
    dataArr,
    dataFrom,
    dataTo,
    setDataTo,
    setDataFrom,
    warehouse,
    toSubWarehouses,
    setTosubWarehouses,
    expandedBatchNumber,
    batchLocators,
  } = props;
  const [isLoading, setIsLoading] = useState(false);
  const [formSubmit, setFormSubmit] = useState(false);
  const [selectedBatchNumber, setSelectedBatchNumber] = useState([]);
  const [form] = Form.useForm();
  const [selectedWareHouse, setSelectedWareHouse] = useState([]);

  const onFinish = (values: any) => {
    if (dataFrom && dataFrom.length > 0) {
      var location = (locations || []).find((loc) => loc.id === selectedLocation);
      let checkDuplicateWarehouse = false;
      let checkWarehouse = false;
      let nonData = false;
      if (selectedWareHouse.length > 0) {
        for (let i = 0; i < selectedWareHouse.length; i++) {
          if (
            selectedWareHouse.indexOf(selectedWareHouse[i]) !==
            selectedWareHouse.lastIndexOf(selectedWareHouse[i])
          ) {
            checkDuplicateWarehouse = true;
            break;
          }
        }
      }
      if (checkDuplicateWarehouse) {
        message.error('CanNotSelectSameWarehouseMultipleTimes.');
      } else {
        if (dataFrom && dataFrom.length > 0) {
          let total = 0;

          for (var i = 0; i < dataFrom.length; i++) {
            if (!dataFrom[i]?.mainWarehouseId) {
              message.error(formatMessage({ id: 'MissingFromWareHouse' }));
              return (checkWarehouse = true);
            }
          }
        }

        if (checkWarehouse) {
          // message.error(formatMessage({ id: 'MissingFromWareHouse' }));
        } else {
          if (nonData) {
            message.error(formatMessage({ id: 'CannotBeMoreThanCurrentQuantity' }));
          } else {
            let dataCheck = false;
            let qtyVal;
            let batchName;

            const batch =
              batchData &&
              batchData.length > 0 &&
              batchData.find((item) => item.batchNumber == expandedBatchNumber);

            const particularLocators = batch && batch.locators;

            dataFrom &&
              dataFrom.map((data) => {
                const index =
                  particularLocators &&
                  particularLocators.findIndex(
                    (loc) =>
                      loc.mainWarehouseId === data.mainWarehouseId &&
                      loc.locatorId === data.locatorId,
                  );

                if (particularLocators[index].quantity < data.quantity) {
                  dataCheck = true;
                  message.error(
                    particularLocators[index].quantity +
                      ' ' +
                      formatMessage({ id: 'QuantityAvailableIn' }) +
                      ' ' +
                      particularLocators[index].mainWarehouseName +
                      ' ' +
                      (particularLocators[index].subWarehouseId != null
                        ? particularLocators[index].subWarehouseName
                        : '') +
                      ' ' +
                      particularLocators[index].locatorId,
                  );
                }
              });

            if (dataCheck) {
              // message.error(
              //   qtyVal + ' ' + formatMessage({ id: 'QuantityAvailableIn' }) + ' ' + batchName,
              // );
            } else {
              const quantityCheck = dataFrom.find(
                (item) => isNaN(item.quantity) || item.quantity < 0,
              );
              if (quantityCheck) {
                message.error(formatMessage({ id: 'QuantityShouldBeNumericAndGreaterThan0' }));
              } else {
                let batchId = '';
                batchData.map((batch) => {
                  if (batch.batchNumber === expandedBatchNumber) {
                    batchId = batch.id;
                  }
                });

                const payload = {
                  batchId: batchId,
                  locators: dataFrom,
                  destination: dataTo,
                };
                props.handleOk(payload);
                setSelectedWareHouse([]);
                setIsLoading(true);
                setFormSubmit(true);
                setDataFrom([]);
                setDataTo([]);
              }
            }
          }
        }
      }
    } else {
      let wareHouseCheck = false;
      for (let i = 0; i < dataFrom.length; i++) {
        if (dataFrom[i]?.mainWarehouseId) {
        } else {
          wareHouseCheck = true;
        }
      }
      if (wareHouseCheck) {
        message.error(formatMessage({ id: 'MissingWareHouse' }));
      } else if (quantity.length == 0) {
        message.error(formatMessage({ id: 'PleaseEnterQuantity' }));
      } else {
        message.error(formatMessage({ id: 'PleaseSelectLocation' }));
      }
    }
  };

  const onCancel = () => {
    props.handleCancel();
    form.resetFields();
    setSelectedWareHouse([]);
  };

  const handleChange = (value, index, type, productId) => {
    let arr = [];
    let finalType = type;
    if (type.includes('from')) {
      finalType = finalType.replace('from', '');
      arr = [...dataFrom];
    } else {
      finalType = finalType.replace('to', '');
      arr = [...dataTo];
    }
    let indexData = arr.findIndex((x) => x.index == index);
    let obj = {};
    if (indexData > -1) {
      obj = { ...arr[indexData] };
    } else {
      obj.index = index;
    }
    obj[finalType] = value;

    if (labType !== 'medicalredcrescent' && type === 'tomainWarehouseId') {
      const currentProduct =
        selectedOrder &&
        selectedOrder.length > 0 &&
        selectedOrder.find((item) => item.productId == productId);

      obj = {
        ...obj,
        labType: labType,
        locationId: currentProduct.locationId,
        inventoryId: currentProduct.inventoryId,
        productId: currentProduct.productId,
        locationName: locationDetails.name,
        locationCode: locationDetails.code,
      };
    }
    if (type === 'frommainWarehouseId') {
      const tmpArr = value.split('__');
      const mainWarehouseId = tmpArr[0].split('main_')[1];
      const subWarehouseId = tmpArr[1].split('sub_')[1];
      const locatorId = tmpArr[2].split('loc_')[1];
      if (typeof mainWarehouseId !== 'undefined') {
        obj[finalType] = parseInt(mainWarehouseId);
      } else {
        obj[finalType] = null;
      }
      if (typeof subWarehouseId != 'undefined') {
        obj['subWarehouseId'] = parseInt(subWarehouseId);
      } else {
        delete obj['subWarehouseId'];
      }
      if (typeof locatorId !== 'undefined') {
        obj['locatorId'] = locatorId;
      } else {
        obj['locatorId'] = null;
      }
      if (selectedWareHouse.length > 0) {
        selectedWareHouse.splice(productId, 1);
      }
      setSelectedWareHouse([...selectedWareHouse, value]);
    }

    if (indexData > -1) {
      arr[indexData] = obj;
    } else {
      arr.push(obj);
    }
    if (type === 'tomainWarehouseId') {
      if (arr[indexData] && arr[indexData].subWarehouseId) {
        delete arr[indexData].subWarehouseId;
      }
      let indexSub = toSubWarehouses.findIndex((subhouse) => subhouse.index == index);
      let sub = warehouse && warehouse.length > 0 && warehouse.find((item) => item.id == value);
      if (sub.subWarehouses && sub.subWarehouses.length > 0) {
        if (indexSub == -1) {
          setTosubWarehouses([...toSubWarehouses, { index, value: sub.subWarehouses }]);
        } else {
          toSubWarehouses[indexSub] = { index, value: sub.subWarehouses };
        }
      } else {
        if (indexSub !== -1) {
          toSubWarehouses.splice(indexSub, 1);
        }
      }
      // tosubWarehouseId
    }
    if (type.includes('from') || type.includes('batchNumber')) {
      setDataFrom(arr);
    } else {
      setDataTo(arr);
    }
    if (type === 'quantity' || type === 'batchNumber') {
      let arrData = [...dataFrom];

      let indexFrom = arrData.findIndex((x) => x.index == index);

      let objData = {};
      if (indexFrom > -1) {
        objData = { ...arrData[indexFrom] };
        arrData.splice(indexFrom, 1);
      } else {
        objData.index = index;
      }
      objData[finalType] = value;

      const batch =
        batchData &&
        batchData.length > 0 &&
        batchData.find((item) => item.batchNumber == expandedBatchNumber);
      let locators = [];
      for (let i = 0; i < batchData.length; i++) {
        if (batchData[i].batchNumber == value && batchData[i].locators) {
          locators.push(...batchData[i].locators);
        }
      }

      const locIndex = batchLocators.findIndex((locI) => locI.index === index);
      if (locIndex !== -1) {
        batchLocators.splice(locIndex, 1, locators);
      }
      if (selectedBatchNumber.length >= productId) {
        selectedBatchNumber.splice(productId, 1);
      }
      const batchofExpanded =
        batchData &&
        batchData.length > 0 &&
        batchData.find((item) => item.batchNumber == expandedBatchNumber);
      objData = {
        ...objData,
        inventoryId: batch.inventoryId,
        batchId: batch.id,
        productId: batch.productId,
        batchId: batchofExpanded.id,
      };

      if (indexFrom > -1) {
        arrData[indexFrom] = objData;
      } else {
        arrData.push(objData);
      }
      setDataFrom(arrData);
    }
  };

  return (
    <>
      <Spin className={styles.loader} spinning={isLoading} size="large" />
      <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
        <div style={{ marginTop: '5px' }}>
          {selectedOrder.map((dataVal, index) => {
            const obj =
              dataArr &&
              dataArr.length > 0 &&
              dataArr.find((item) => item.id == dataVal.inventoryId);

            return (
              obj &&
              obj.dataLength.map((itemData, indexObj) => {
                return (
                  <>
                    <div key={itemData}>
                      {indexObj === 0 && (
                        <>
                          <Row gutter={[12, 12]} align="middle">
                            <Col span={11}>
                              <Form.Item
                                label={formatMessage({
                                  id: 'Product',
                                })}
                              >
                                <Input
                                  name="product"
                                  value={
                                    getLocale() === 'ar-EG'
                                      ? dataVal.product.arabicDescription
                                      : dataVal.product.description
                                  }
                                />
                              </Form.Item>
                            </Col>
                            <Col span={11}>
                              <Form.Item
                                label={formatMessage({
                                  id: 'Code',
                                })}
                              >
                                <Input
                                  name="code"
                                  value={
                                    getLocale() === 'ar-EG'
                                      ? dataVal.product.code
                                      : dataVal.product.code
                                  }
                                />
                              </Form.Item>
                            </Col>
                          </Row>
                          {labType === 'medicalredcrescent' && (
                            <Row gutter={[24, 24]} align="middle">
                              {
                                <Col span={24}>
                                  <Form.Item
                                    initialValue={expandedBatchNumber}
                                    label={useIntl().formatMessage({ id: `BatchNumber` })}
                                    name={`batch${indexObj}${index}`}
                                    rules={[
                                      {
                                        required: true,
                                        message: formatMessage({ id: 'PleaseSelectTheBatch' }),
                                      },
                                    ]}
                                  >
                                    <Input
                                      name="product"
                                      value={expandedBatchNumber}
                                      onChange={(value) => {
                                        handleChange(
                                          value.target.value,
                                          `${indexObj}${index}`,
                                          'batchNumber',
                                          indexObj,
                                        );
                                      }}
                                    />
                                  </Form.Item>
                                </Col>
                              }
                            </Row>
                          )}
                        </>
                      )}
                      {batchLocators && batchLocators.length > 0 && (
                        <>
                          <div
                            style={{
                              justifyContent: 'space-between',
                              marginBottom: '10px',
                            }}
                          >
                            {useIntl().formatMessage({ id: 'FromWareHouse' })}
                          </div>
                          <Row gutter={[12, 12]} align="middle">
                            <Col className={styles.maxWidthRadio} span={11}>
                              <Radio.Group
                                name={`locator${indexObj}${index}`}
                                // defaultValue={i==0 &&id}
                                className={styles.radioFormat}
                                onChange={(e) =>
                                  handleChange(
                                    e.target.value,
                                    `${indexObj}${index}`,
                                    'frommainWarehouseId',
                                    indexObj,
                                  )
                                }
                              >
                                {batchLocators.map((batch, i) => {
                                  const id = `main_${batch?.mainWarehouseId}__sub_${
                                    !!batch?.subWarehouseId ? batch?.subWarehouseId : ''
                                  }__loc_${batch?.locatorId}`;
                                  return (
                                    <Radio
                                      className="wareHouseRadio"
                                      // key={id} onChange={()=>setIdChekedFromRequest(id)} checked={id===idChekedFromRequest}
                                      value={id}
                                    >{`${
                                      !!batch.mainWarehouseName ? `${batch.mainWarehouseName} ` : ''
                                    } ${
                                      !!batch.subWarehouseName ? `${batch.subWarehouseName} ` : ''
                                    } ${!!batch.locatorId ? `${batch.locatorId} ` : ''}`}</Radio>
                                  );
                                })}
                              </Radio.Group>
                            </Col>
                          </Row>
                        </>
                      )}
                      <Row gutter={[24, 24]} align="middle">
                        <Col span={24}>
                          <Form.Item
                            label={useIntl().formatMessage({ id: `ToWareHouse` })}
                            name={`ToWareHouse${indexObj}${index}`}
                            rules={[
                              {
                                required: true,
                                message: useIntl().formatMessage({ id: 'MissingWareHouse' }),
                              },
                            ]}
                          >
                            <Select
                              onChange={(value) => {
                                handleChange(
                                  value,
                                  `${indexObj}${index}`,
                                  'tomainWarehouseId',
                                  dataVal.productId,
                                );
                              }}
                            >
                              {warehouse &&
                                warehouse.length > 0 &&
                                warehouse.map((house) => {
                                  return <Option value={house.id}>{house.name}</Option>;
                                })}
                            </Select>
                          </Form.Item>
                        </Col>
                        {dataTo.length > 0 &&
                          toSubWarehouses.length > 0 &&
                          dataTo.find(
                            (x) => x.index == `${indexObj}${index}` && x.mainWarehouseId,
                          ) &&
                          toSubWarehouses.find((item) => item.index == `${indexObj}${index}`) && (
                            <Col span={24}>
                              <Form.Item
                                label={useIntl().formatMessage({ id: `ToSubWareHouse` })}
                                name={`ToSubWareHouse${indexObj}${index}`}
                                rules={[
                                  {
                                    required: true,
                                    message: useIntl().formatMessage({
                                      id: 'MissingSubWareHouse',
                                    }),
                                  },
                                ]}
                              >
                                <Select
                                  onChange={(value) => {
                                    handleChange(value, `${indexObj}${index}`, 'tosubWarehouseId');
                                  }}
                                >
                                  {toSubWarehouses &&
                                    toSubWarehouses.length > 0 &&
                                    toSubWarehouses.map((house) => {
                                      if (house.index == `${indexObj}${index}`) {
                                        return house.value.map((item) => {
                                          return <Option value={item.id}>{item.name}</Option>;
                                        });
                                      }
                                    })}
                                </Select>
                              </Form.Item>
                            </Col>
                          )}
                      </Row>
                      <Row gutter={[12, 12]} align="middle">
                        <Col span={11} className={styles.colheight}>
                          <Form.Item
                            label={useIntl().formatMessage({ id: 'ToLocatorID' })}
                            name={`TobinNumber${indexObj}${index}`}
                            rules={[
                              {
                                required: true,
                                message: useIntl().formatMessage({ id: 'MissingToLocatorID' }),
                              },
                            ]}
                          >
                            <Input
                              style={{ width: '100%' }}
                              onChange={(value) => {
                                handleChange(
                                  value.target.value,
                                  `${indexObj}${index}`,
                                  'tolocatorId',
                                  dataVal.productId,
                                );
                              }}
                            />
                          </Form.Item>
                        </Col>

                        <Col span={11} className={styles.colheight}>
                          <Form.Item
                            className={styles.colInput}
                            label={useIntl().formatMessage({ id: 'Quantity' })}
                            name={`quantity${indexObj}${index}`}
                            rules={[
                              {
                                required: true,
                                message: useIntl().formatMessage({ id: 'MissingQuantity' }),
                              },
                              {
                                type: 'number',
                                min: 1,
                              },
                            ]}
                          >
                            <InputNumber
                              placeholder={useIntl().formatMessage({ id: 'Quantity' })}
                              precision={0}
                              style={{ width: '100%' }}
                              onChange={(value) => {
                                handleChange(
                                  value,
                                  `${indexObj}${index}`,
                                  'quantity',
                                  dataVal.productId,
                                );
                              }}
                            />
                          </Form.Item>

                          {dataFrom &&
                            dataFrom[indexObj] &&
                            dataFrom[indexObj].mainWarehouseId &&
                            batchLocators &&
                            batchLocators.map((batch) => {
                              if (
                                batch.mainWarehouseId == dataFrom[indexObj].mainWarehouseId &&
                                batch.locatorId == dataFrom[indexObj].locatorId
                              ) {
                                return (
                                  <span className={styles.alignright}>
                                    {useIntl().formatMessage({ id: `MaximumQuantity` })} :
                                    {batch.quantity}
                                  </span>
                                );
                              }
                            })}
                        </Col>
                      </Row>
                    </div>
                    {indexObj == obj.dataLength.length - 1 && (
                      <Button
                        className={styles.btnText}
                        type="dashed"
                        onClick={() => {
                          const indexData = dataArr.find((item) => item.id == dataVal.inventoryId);
                          let arr = [...dataArr];
                          let objData = { ...obj };
                          objData.dataLength.push([]);
                          arr[indexData] = objData;
                          setdataArr(arr);
                        }}
                        block
                      >
                        <PlusOutlined /> {useIntl().formatMessage({ id: 'Add' })}
                      </Button>
                    )}
                  </>
                );
              })
            );
          })}
        </div>

        <Row gutter={[24, 24]}>
          <Col flex={1}>
            <Form.Item>
              {formSubmit ? (
                <Button disabled={formSubmit} type="primary" htmlType="submit" block loading>
                  {useIntl().formatMessage({ id: 'Apply' })}
                </Button>
              ) : (
                <Button disabled={formSubmit} type="primary" htmlType="submit" block>
                  {useIntl().formatMessage({ id: 'Apply' })}
                </Button>
              )}
            </Form.Item>
          </Col>
          <Col flex={1}>
            <Form.Item>
              <Button onClick={onCancel} block>
                {useIntl().formatMessage({ id: 'Cancel' })}
              </Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </>
  );
};

const IntraWareHouseTransferModal = (props: any) => {
  const {
    currentStatus,
    handleOk,
    handleCancel,
    isVisible,
    locationDetails,
    labType,
    selectedOrder,
    expandedBatchNumber,
  } = props;
  const [selectedLocation, setSelectedLocation] = useState('');
  const [locations, setLocations] = useState([]);
  const [dataArr, setdataArr] = useState([]);
  const [dataFrom, setDataFrom] = useState([]);
  const [dataTo, setDataTo] = useState([]);
  const locDropdown: [] = [];
  const [warehouse, setWarehouse] = useState([]);
  const [batchData, setBatchData] = useState([]);
  const [toSubWarehouses, setTosubWarehouses] = useState([]);
  const [fromSubWarehouses, setFromsubWarehouses] = useState([]);
  const [batchLocators, setLocators] = useState([]);

  useEffect(() => {
    if (selectedOrder != null && isVisible) {
      redCrescentService.getLocations('medicalredcrescent').then((locations: any) => {
        locations.map((lab: any) => {
          locDropdown.push(lab);
        });
        setLocations(locDropdown);
      });
    }
    async function fetchMyAPI(selectedOrder) {
      let arr = [];
      const arrayData = [];
      if (selectedOrder && selectedOrder.length > 0) {
        for (let i = 0; i < selectedOrder.length; i++) {
          let obj = { id: selectedOrder[i].inventoryId, dataLength: [[]] };
          arr.push(obj);
          setdataArr(arr);

          // const skuBatchDetails = await redCrescentService.getBatches(selectedOrder[i].inventoryId);
          arrayData.push(...selectedOrder[i].batches);
        }
        setBatchData(arrayData);
      }

      const batch =
        arrayData &&
        arrayData.length > 0 &&
        arrayData.find((item) => item.batchNumber == expandedBatchNumber);
      let locators = [];
      for (let i = 0; i < arrayData.length; i++) {
        if (arrayData[i].batchNumber == expandedBatchNumber && arrayData[i].locators) {
          locators.push(...arrayData[i].locators);
        }
      }
      setLocators(locators);
    }
    fetchMyAPI(selectedOrder);
    // var labtype = window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC;
    if (isVisible) {
      redCrescentService
        .getWareHouses('medicalredcrescent', props.locationDetails.id)
        .then((data) => {
          let d = data.filter((item) => item.locationId === props.locationDetails.id);

          setWarehouse(d);
        });
    }
  }, [selectedOrder, isVisible]);
  return (
    <>
      <Modal
        width="50%"
        title={useIntl().formatMessage({ id: 'IntraWarehouseTransfer' })}
        visible={isVisible}
        afterClose={() => handleCancel()}
        destroyOnClose
        closable={false}
        footer={false}
      >
        <BasicTransferForm
          batchLocators={batchLocators}
          batchData={batchData}
          isVisible={isVisible}
          toSubWarehouses={toSubWarehouses}
          fromSubWarehouses={fromSubWarehouses}
          setFromsubWarehouses={setFromsubWarehouses}
          setTosubWarehouses={setTosubWarehouses}
          setdataArr={setdataArr}
          dataArr={dataArr}
          setDataFrom={setDataFrom}
          dataFrom={dataFrom}
          dataTo={dataTo}
          setDataTo={setDataTo}
          warehouse={warehouse}
          setWarehouse={setWarehouse}
          currentStatus={currentStatus}
          labType={labType}
          selectedLocation={selectedLocation}
          setSelectedLocation={setSelectedLocation}
          locations={locations}
          locationDetails={locationDetails}
          expandedBatchNumber={expandedBatchNumber}
          handleOk={(updatedBatches: any) => handleOk(updatedBatches)}
          handleCancel={() => {
            handleCancel();
            setSelectedLocation('');
            setdataArr([]);
            setDataTo([]);
            setDataFrom([]);
            setTosubWarehouses([]);
            setFromsubWarehouses([]);
          }}
          selectedOrder={selectedOrder}
        />
      </Modal>
    </>
  );
};

export default IntraWareHouseTransferModal;

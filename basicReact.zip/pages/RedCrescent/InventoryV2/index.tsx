import React, { useState, useEffect, Component, useRef } from 'react';
import { connect, useModel, getLocale, useIntl, useAccess } from 'umi';
import { Col, Row, Tabs, Menu, Dropdown, Button, Badge, Tooltip, Cascader, Input } from 'antd';
import { ModuleTypes, LabTypes } from '@/services/Constants';
import InventoryTable from './components/InventoryTable/InventoryTable';
import redcrescentService from '../services/redcrescent.service';
import { InventoryType } from './Types';
import { StateType } from './model';
import styles from './index.less';

const { TabPane } = Tabs;

enum StatusNames {
  'outOfStock' = 'OOS',
  'nearOutOfStock' = 'NOOS',
  'safeStock' = 'SS',
  'overStock' = 'OS',
}

enum StatusFilterName {
  'true' = 'Active',
  'false' = 'Inactive',
}

enum ExpiryFrequeny {
  'perWeek' = 'Every Week',
  'perMonth' = 'Every Month',
  'perDay' = 'Every Day',
  'once' = 'Once',
}
const InventoryContainer = (props) => {
  const {
    inventories,
    userLocationId,
    onChangeTab,
    currentInventoryLocationId,
    onFilter,
    locationsKeys,
    labtype,
    page,
    setPage,
    getMoreInventoryRequest,
    resetInventory,
    redcrescentProfile,
    access,
  } = props;

  const [typeFilterData, setTypeFilterData] = useState([
    { value: 'All Categories', label: useIntl().formatMessage({ id: 'AllCategories' }) },
  ]);
  const [height, setHeight] = useState(0);
  const ref = useRef(null);

  useEffect(() => {
    if (ref && ref.current) {
      setHeight(ref.current.clientHeight);
    }
  }, [ref]);

  const [filters, setFilters] = useState({
    status: 'clear',
    active: 'clear',
    category: 'All Categories',
    classification: 'All Categories',
    expiry: 'clear',
  });

  const Filters = (props) => {
    const onFilterChange = (value, key) => {
      resetInventory(newFilters, 1);
      var newFilters;
      if (key === 'category') {
        newFilters = { ...filters, [key]: value, classification: 'All Categories' };
      } else {
        newFilters = { ...filters, [key]: value };
      }
      setFilters(newFilters);
      onFilter(newFilters, 1);
    };

    useEffect(() => {
      (async () => {
        let arr = [];
        const locale = getLocale();
        const resultVal = (await redcrescentService.getPopulatedClassifications(labtype)) || [];
        resultVal &&
          resultVal.results &&
          resultVal.results.data.map((res) => {
            let hasAccess =
              redcrescentProfile?.role === 'storeKeeper'
                ? redcrescentProfile.classificationAccesses &&
                  redcrescentProfile.classificationAccesses.filter((item) => {
                    if (item.isDelegate) {
                      if (item.delegateAccepted) {
                        return item.category == res.category;
                      }
                    } else {
                      return item.category == res.category;
                    }
                  })
                : ['true'];
            if (locale.includes('en') && hasAccess && hasAccess.length > 0) {
              if (arr.length > 0) {
                const found = arr.findIndex((cat) => cat.label == res.category);
                if (found > -1) {
                  if (res.classification !== '' && arr[found].children) {
                    let children = arr[found].children;
                    arr[found].children = [
                      ...children,
                      { label: res.classification, value: res.classification },
                    ];
                  }
                } else {
                  let obj = { label: res.category, value: res.category };
                  if (res.classification !== '') {
                    obj.children = [{ label: res.classification, value: res.classification }];
                  }
                  arr.push(obj);
                }
              } else {
                let obj = { label: res.category, value: res.category };
                if (res.classification !== '') {
                  obj.children = [{ label: res.classification, value: res.classification }];
                }
                arr.push(obj);
              }
            } else {
              if (hasAccess && hasAccess.length > 0) {
                if (arr.length > 0) {
                  const found = arr.findIndex((cat) => cat.label == res.arabicCategory);
                  if (found > -1) {
                    if (res.arabicClassification !== '' && arr[found].children) {
                      let children = arr[found].children;
                      arr[found].children = [
                        ...children,
                        { label: res.arabicClassification, value: res.classification },
                      ];
                    }
                  } else {
                    let obj = { label: res.arabicCategory, value: res.category };
                    if (res.arabicClassification !== '') {
                      obj.children = [
                        { label: res.arabicClassification, value: res.classification },
                      ];
                    }
                    arr.push(obj);
                  }
                } else {
                  let obj = { label: res.arabicCategory, value: res.category };

                  arr.push(obj);
                }
              }
            }
          });

        redcrescentProfile?.role === 'storeKeeper' &&
          redcrescentProfile.delegationAccesses &&
          redcrescentProfile.delegationAccesses.map((item) => {
            resultVal.results.data.map((res) => {
              if (
                res.category === item.delegateFrom.category &&
                item.hasExpired === 0 &&
                item.delegateAccepted === 1
              ) {
                let obj = {};
                if (locale.includes('en')) {
                  obj = { label: res.category, value: res.category };
                } else {
                  obj = { label: res.arabicCategory, value: res.category };
                }

                arr.push(obj);
              }
            });
          });
        const dataVal = arr.filter((v, i, a) => a.findIndex((t) => t.value === v.value) === i);
        setTypeFilterData(typeFilterData.concat(dataVal));
      })();
    }, [labtype]);

    const menu = (
      <Menu onClick={(e) => onFilterChange(e.key, 'status')}>
        <Menu.Item key="outOfStock">
          <Badge color="red" /> OOS
        </Menu.Item>
        <Menu.Item key="nearOutOfStock">
          <Badge color="orange" /> NOOS
        </Menu.Item>
        <Menu.Item key="safeStock">
          <Badge color="green" />
          SS
        </Menu.Item>
        <Menu.Item key="overStock">
          <Badge color="purple" />
          OS
        </Menu.Item>
        <Menu.Item key="clear">{useIntl().formatMessage({ id: 'ClearStatus' })}</Menu.Item>
      </Menu>
    );

    const statusFilter = (
      <Menu onClick={(e) => onFilterChange(e.key, 'active')}>
        <Menu.Item key="true">
          <Badge /> {useIntl().formatMessage({ id: 'Active' })}
        </Menu.Item>
        <Menu.Item key="false">
          <Badge /> {useIntl().formatMessage({ id: 'InActive' })}
        </Menu.Item>
        <Menu.Item key="clear">{useIntl().formatMessage({ id: 'ClearStatus' })}</Menu.Item>
      </Menu>
    );

    const onChange = (value) => {
      const [category, classification] = value;
      if (category === 'All Categories') {
        onFilterChange('All Categories', 'classification');
        onFilterChange('All Categories', 'category');
      } else {
        if (classification) {
          onFilterChange(classification, 'classification');
        } else {
          onFilterChange(category, 'category');
        }
      }
    };

    return (
      <>
        <Cascader
          allowClear={false}
          options={typeFilterData}
          onChange={(value) => onChange(value)}
          changeOnSelect
          placeholder="Category"
          defaultValue={['All Categories']}
          displayRender={(value) => {
            const [category, classification] = value;
            return classification || category;
          }}
        />
        <Dropdown className={styles.filterDropdown} overlay={menu} placement="bottomRight">
          <Button type={filters.status !== 'clear' ? 'primary' : 'default'}>
            {filters.status !== 'clear'
              ? StatusNames[filters.status]
              : useIntl().formatMessage({ id: 'Status' })}
          </Button>
        </Dropdown>

        <Dropdown className={styles.filterDropdown} overlay={statusFilter} placement="bottomRight">
          <Button type={filters.active !== 'clear' ? 'primary' : 'default'}>
            {filters.active !== 'clear'
              ? useIntl().formatMessage({
                  id: StatusFilterName[filters.active] === 'Active' ? 'Active' : 'InActive',
                })
              : useIntl().formatMessage({ id: 'ActivityStatus' })}
          </Button>
        </Dropdown>
      </>
    );
  };

  const onChangeLocation = (activeKey?) => {
    setFilters({
      status: 'clear',
      expiry: 'clear',
      classification: 'All Categories',
      category: 'All Categories',
      active: 'clear',
    });
    onChangeTab(activeKey);
    // setCurrentTab(activeKey);
  };
  const getInventories = (inventories: any[]) => {
    const inventoryList = Object.keys(inventories).map((locationsKeys) => {
      return inventories[locationsKeys];
    });
    return access.canReadAllRedCrescentInventories(labtype)
      ? inventoryList
      : redcrescentProfile?.role === 'storeKeeper'
      ? inventoryList.filter(
          (inventory) => inventory?.locationDetails?.id === redcrescentProfile.locationId,
        )
      : inventoryList.filter(
          (inventory) => inventory?.locationDetails?.id === redcrescentProfile.locationId,
        );
  };
  return (
    <>
      {Object.keys(locationsKeys).length > 0 ? (
        <div className={styles.main}>
          <div className={styles.container}>
            <Row gutter={[24, 24]}>
              <Col>
                <div ref={ref}>
                  <Tabs
                    activeKey={
                      labtype == 'nonmedicalredcrescent'
                        ? locationsKeys[currentInventoryLocationId] == 'RIY'
                          ? 'DER'
                          : locationsKeys[currentInventoryLocationId]
                        : locationsKeys[currentInventoryLocationId]
                    }
                    onChange={onChangeLocation}
                    tabBarExtraContent={Filters(props.onFilter)}
                  >
                    {getInventories(inventories).map((inventory: InventoryType) => {
                      const key = locationsKeys[inventory.locationDetails.id];

                      if (
                        (labtype == 'nonmedicalredcrescent' && key != 'RIY') ||
                        (labtype == 'medicalredcrescent' && key != 'DER')
                      ) {
                        return (
                          <TabPane
                            key={key}
                            tab={
                              <Tooltip
                                title={
                                  getLocale().includes('en')
                                    ? inventory.locationDetails.name
                                    : inventory.locationDetails.arabicName
                                }
                              >
                                {inventory.locationDetails.code}
                              </Tooltip>
                            }
                          >
                            <InventoryTable
                              labtype={labtype}
                              page={page}
                              setPage={setPage}
                              skus={inventory.skus}
                              locationDetails={inventory.locationDetails}
                              userLocationId={userLocationId}
                              inventoryLocationId={inventory.locationDetails.id}
                              onUpdate={props.onUpdate}
                              tableHeight={height}
                              filters={filters}
                              locationsKeys={locationsKeys}
                              getMoreInventoryRequest={getMoreInventoryRequest}
                            />
                          </TabPane>
                        );
                      }
                    })}
                  </Tabs>
                </div>
              </Col>
            </Row>
          </div>
        </div>
      ) : (
        <></>
      )}
    </>
  );
};

// const locationsKeys = ['nhl', 'mak', 'mad', 'asr', 'dam'];
interface PropsType {
  currentUser: App.CurrentUser;
  labType: App.LabType;
  access: any;
  dispatch: any;
}
class Inventory extends Component<PropsType, any> {
  redcrescentProfile: App.Module | undefined;
  constructor(props) {
    super(props);
    let moduleData = window.location.href.includes('non-medical')
      ? ModuleTypes.NON_MRC
      : ModuleTypes.MRC;
    const { currentUser }: App.InitialStateType = props;
    this.redcrescentProfile = currentUser?.modules.find((module) => {
      return module.name === moduleData;
    });
    const userLocationId =
      this.redcrescentProfile?.name == 'nonmedicalredcrescent'
        ? this.redcrescentProfile?.locationId == 286
          ? 287
          : this.redcrescentProfile?.locationId
        : this.redcrescentProfile?.locationId;
    this.state = {
      userLocationId,
      userLocation: '',
      locationsKeys: {},
      page: 1,
      currentInventoryLocationId: userLocationId,
      labtype: window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC,
      totalPages: 0,
    };
    this.onChangeTab = this.onChangeTab.bind(this);
  }
  setPage = (page) => {
    this.setState({
      page: page,
    });
  };
  async componentDidMount() {
    const { dispatch, currentUser } = this.props;
    const { labtype, userLocationId } = this.state;
    const locationsKeysData = {};
    const allLocationDetails = (await redcrescentService.getLocations('medicalredcrescent')) || [];
    allLocationDetails.forEach((location: any) => {
      locationsKeysData[location.id] = location.code;
    });
    this.setState(
      {
        locationsKeys: locationsKeysData,
      },
      () => {
        this.setState((prevState) => ({
          userLocation: this.state.locationsKeys[this.state.userLocationId],
          labtype: window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC,
          locationsKeys: locationsKeysData,
        }));
        dispatch({
          type: 'RedCrescentInventory/initInventories',
          payload: {
            allLocationDetails,
            userLocation: this.state.locationsKeys[this.state.userLocationId],
            locationId: this.state.userLocationId,
            page: this.state.page,
            labtype,
          },
        });
      },
    );
  }

  onChangeTab(activeKey) {
    const { dispatch } = this.props;
    const { labtype, locationsKeys, page } = this.state;
    const locationId = Object.keys(locationsKeys).find((key) => locationsKeys[key] === activeKey);
    this.setState({
      currentInventoryLocationId: locationId,
      userLocation: activeKey,
      page: 1,
    });
    dispatch({
      type: 'RedCrescentInventory/fetchInventory',
      payload: {
        locationKey: activeKey,
        locationId,
        page: 1,
        labtype,
      },
    });
  }
  resetInventory = async (filter, page) => {
    const { dispatch } = this.props;
    const { labtype, locationsKeys } = this.state;
    this.setState(
      {
        page: 1,
      },
      () => {
        const payload = {
          filter,
          locationId: this.state.currentInventoryLocationId,
          page,
          locationKey: locationsKeys[this.state.currentInventoryLocationId],
          labtype,
        };

        dispatch({
          type: 'RedCrescentInventory/resetInventories',
          payload,
        });
      },
    );
  };
  onUpdate = async (filter, page) => {
    const { dispatch } = this.props;
    const { labtype, locationsKeys } = this.state;
    this.setState(
      {
        page,
      },
      () => {
        dispatch({
          type: 'RedCrescentInventory/fetchUpdatedData',
          payload: {
            locationId: this.state.currentInventoryLocationId,
            page: this.state.page,
            locationKey: locationsKeys[this.state.currentInventoryLocationId],
            labtype,
            filter,
          },
        });
      },
    );
  };
  refreshInventory = async (filter, page) => {
    const { dispatch } = this.props;
    const { labtype, locationsKeys } = this.state;

    this.setState(
      {
        page,
      },
      () => {
        if (
          filter.status === 'clear' &&
          filter.expiry === 'clear' &&
          filter.category === 'All Categories' &&
          filter.active === 'clear'
        ) {
          dispatch({
            type: 'RedCrescentInventory/fetchInventory',
            payload: {
              locationId: this.state.currentInventoryLocationId,
              page: this.state.page,
              locationKey: locationsKeys[this.state.currentInventoryLocationId],
              labtype,
            },
          });
        } else {
          const payload = {
            filter,
            locationId: this.state.currentInventoryLocationId,
            page: this.state.page,
            locationKey: locationsKeys[this.state.currentInventoryLocationId],
            labtype,
          };

          dispatch({
            type: 'RedCrescentInventory/fetchFilteredInventory',
            payload,
          });
        }
      },
    );
  };
  getMoreInventoryRequest = (page, filter) => {
    const { labtype, locationsKeys, currentInventoryLocationId, userLocation } = this.state;
    const { inventories } = this.props;
    const { dispatch } = this.props;
    let previousPage = this.state.page;
    this.setState(
      {
        page,
      },
      () => {
        if (page > previousPage) {
          dispatch({
            type: 'RedCrescentInventory/fetchFilteredInventory',
            payload: {
              locationKey: locationsKeys[currentInventoryLocationId],
              locationId: currentInventoryLocationId,
              filter,
              page,
              labtype,
            },
          });
        }
      },
    );
  };
  render() {
    const { inventories, access } = this.props;

    const {
      labtype,
      userLocation,
      userLocationId,
      currentInventoryLocationId,
      locationsKeys,
      page,
    } = this.state;
    return (
      <div key={JSON.stringify(locationsKeys)}>
        <InventoryContainer
          inventories={inventories}
          page={page}
          userLocation={userLocation}
          userLocationId={userLocationId}
          onChangeTab={this.onChangeTab}
          currentInventoryLocationId={currentInventoryLocationId}
          setPage={this.setPage}
          onFilter={(filter, page) => this.refreshInventory(filter, page)}
          resetInventory={(filter, page) => this.resetInventory(filter, page)}
          getMoreInventoryRequest={this.getMoreInventoryRequest}
          onUpdate={(filter, page) => this.onUpdate(filter, page)}
          labtype={labtype}
          locationsKeys={locationsKeys}
          redcrescentProfile={this.redcrescentProfile}
          access={access}
        />
      </div>
    );
  }
}

const InventoryWrapper: React.FC<any> = (props) => {
  const { initialState } = useModel('@@initialState');
  const access = useAccess();
  return <Inventory {...props} currentUser={initialState?.currentUser} access={access} />;
};

export default connect(({ RedCrescentInventory }: { RedCrescentInventory: StateType }) => {
  const labtype = window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC;
  return {
    inventories: RedCrescentInventory || [],
  };
})(InventoryWrapper);

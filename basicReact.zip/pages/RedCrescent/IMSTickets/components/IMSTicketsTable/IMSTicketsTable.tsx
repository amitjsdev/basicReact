/* eslint-disable react/no-unused-state */
import React, { Component } from 'react';
import { useAccess, FormattedMessage, getLocale, formatMessage } from 'umi';
import { Table, Button, Tooltip, Typography, Tag, Modal } from 'antd';
import moment from 'moment';
import { FileDoneOutlined, InfoCircleFilled } from '@ant-design/icons';

import redcrescentService from '../../../services/redcrescent.service';
import { TicketTypeNames, PriorityColors, ITicket } from '../../Types';

import styles from './index.less';

const { Text } = Typography;

const DATE_FORMAT = 'YYYY-MM-DD';

class IMSTicketsTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      columns: [
        /* {
          title: 'Lab code',
          width: '100px',
          dataIndex: 'locationCode',
          key: 'locationCode',
          fixed: 'left',
        }, */
        {
          title: <FormattedMessage id="TicketNo" />,
          width: '100px',
          dataIndex: 'id',
          key: 'id',
          fixed: 'left',
        },
        {
          title: <FormattedMessage id="ProductCode" />,
          width: '100px',
          dataIndex: 'productCode',
          key: 'productCode',
        },
        {
          title: '',
          width: '20px',
          dataIndex:
            getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : 'productDescription',
          key: 'productDescription',
          render: (text) => {
            return (
              <Tooltip placement="top" title={text}>
                <InfoCircleFilled />
              </Tooltip>
            );
          },
        },
        {
          title: <FormattedMessage id="Type" />,
          width: '100px',
          dataIndex: 'type',
          key: 'type',
          render: (text, record) => {
            return formatMessage({ id: `${TicketTypeNames[text].split(' ').join('')}` });
          },
        },
        {
          title: <FormattedMessage id="Status" />,
          width: '100px',
          dataIndex: 'status',
          key: 'status',
          render: (text) => (
            <Text className={styles.status}>
              {formatMessage({ id: `${text.charAt(0).toUpperCase() + text.slice(1)}` })}
            </Text>
          ),
        },
        {
          title: <FormattedMessage id="DueDate" />,
          width: '100px',
          dataIndex: 'dueDate',
          key: 'dueDate',
          render: (text) => {
            return getLocale().includes( 'en')
              ? moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
              : moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD');
          },
        },
        {
          title: <FormattedMessage id="Priority" />,
          width: '100px',
          dataIndex: 'priority',
          key: 'priority',
          render: (text) => (
            <Tag color={PriorityColors[text]} className={styles.priorityTags}>
              {text}
            </Tag>
          ),
        },
        {
          title: <FormattedMessage id="CreatedOn" />,
          width: '100px',
          dataIndex: 'createdAt',
          key: 'createdAt',
          render: (text) => {
            return getLocale().includes( 'en')
              ? moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
              : moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD');
          },
        },
      ],
    };
    this.handleCloseTicket = this.handleCloseTicket.bind(this);
  }

  private getTotalColumnWidth(columns: ColumnType[]): number {
    return columns.reduce((acc, cur) => acc + parseInt(cur.width, 10), 0);
  }

  // handleUpdate()

  handleCloseTicket(ticket: ITicket) {
    Modal.confirm({
      title: formatMessage({ id: 'AreYouSureCloseticket' }) + `${ticket.id}?`,
      onOk: () =>
        redcrescentService.closeTicket(ticket.id).then(() => {
          window.location.reload();
          // this.props.onUpdate();
        }),
      okText: formatMessage({ id: 'CloseTicket' }),
    });
  }

  render() {
    const { tickets, tableHeight } = this.props;

    const actionColumn = {
      title: <FormattedMessage id="Actions" />,
      width: '100px',
      dataIndex: 'action',
      key: 'action',
      fixed: 'right',
      render: (text, record) => (
        <Tooltip title={formatMessage({ id: 'CloseTicket' })}>
          <Button
            disabled={record.status === 'completed'}
            type="primary"
            shape="circle"
            icon={<FileDoneOutlined />}
            onClick={() => this.handleCloseTicket(record)}
          />
        </Tooltip>
      ),
    };

    return (
      <Table
        columns={
          this.props.access.canCloseRedCrescentTickets()
            ? [...this.state.columns, actionColumn]
            : this.state.columns
        }
        dataSource={tickets}
        pagination={false}
        scroll={{
          x:
            this.getTotalColumnWidth(this.state.columns) + // All columns
            300, // Checkbox
          y: tableHeight - 100,
        }}
      />
    );
  }
}

const IMSTicketsTableWrapper = (props) => <IMSTicketsTable {...props} access={useAccess()} />;

export default IMSTicketsTableWrapper;

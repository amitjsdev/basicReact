import React, { Component, useState, useEffect, useRef } from 'react';
import { connect, useModel, getLocale, useAccess } from 'umi';
import { Spin, Tabs, Row, Col, Tooltip } from 'antd';
import { ModuleTypes, LabTypes } from '@/services/Constants';
import redcrescentService from '../services/redcrescent.service';

import styles from './index.less';
import IMSTicketsTable from './components/IMSTicketsTable/IMSTicketsTable';

const { TabPane } = Tabs;

const TicketsListContianer = (props) => {
  const {
    tickets,
    locationKeys,
    onChangeTab,
    currentLocationId,
    onUpdate,
    access,
    redcrescentProfile,
    labtype,
  } = props;

  const [height, setHeight] = useState(0);
  const ref = useRef(null);

  useEffect(() => {
    setHeight(ref.current.clientHeight);
  });

  const onChange = (activeKey) => {
    onChangeTab(activeKey);
  };
  const getTickets = (tickets: any[]) => {
    const ticketsData = Object.keys(tickets).map((locationKeys) => {
      return tickets[locationKeys];
    });
    const filterData = ticketsData.filter(
      (ticket) => ticket?.locationDetails?.id === redcrescentProfile.locationId,
    );
    return access.canReadAllRedCrescentInventories(labtype)
      ? ticketsData
      : redcrescentProfile.role === 'storeKeeper'
      ? ticketsData.filter(
          (ticket) => ticket?.locationDetails?.id === redcrescentProfile.locationId,
        )
      : ticketsData.filter(
          (ticket) => ticket?.locationDetails?.id === redcrescentProfile.locationId,
        );
  };
  return (
    <div className={styles.main}>
      <div className={styles.container}>
        <Row gutter={[24, 24]}>
          <Col>
            <div ref={ref} className={styles.tableContainer}>
              <Tabs activeKey={locationKeys[currentLocationId]} onChange={onChange}>
                {getTickets(tickets).map((location) => {
                  const key = locationKeys[location.locationDetails.id];
                  return (
                    <TabPane
                      key={key}
                      tab={
                        <Tooltip
                          title={
                            getLocale().includes( 'en')
                              ? location.locationDetails.name
                              : location.locationDetails.arabicName
                          }
                        >
                          {location.locationDetails.code}
                        </Tooltip>
                      }
                    >
                      <IMSTicketsTable
                        tickets={location.tickets}
                        tableHeight={height}
                        onUpdate={onUpdate}
                      />
                    </TabPane>
                  );
                })}
              </Tabs>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

interface PropsType {
  currentUser: App.CurrentUser;
  labType: App.LabType;
  access: any;
  dispatch: any;
}
class IMSTickets extends Component<PropsType, any> {
  redcrescentProfile: App.Module | undefined;
  constructor(props) {
    super(props);
    const { currentUser }: App.InitialStateType = props;

    this.redcrescentProfile = currentUser?.modules.find((module) => module.name === LabTypes.MRC);
    const userLocationId = this.redcrescentProfile?.locationId;
    this.state = {
      userLocationId,
      userLocation: '',
      currentLocationId: userLocationId,
      locationKeys: null,
      isLoading: true,
      labtype: window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC,
    };

    this.onChangeTab = this.onChangeTab.bind(this);
  }

  async componentDidMount() {
    const { dispatch } = this.props;
    const { labtype } = this.state;
    const allLocations = (await redcrescentService.getLocations(labtype)) || [];
    const locationKeys = {};
    allLocations.forEach((location: any) => {
      locationKeys[location.id] = location.code;
    });

    this.setState((prevState) => ({
      locationKeys,
      userLocation: locationKeys[prevState.userLocationId],
      labtype,
    }));

    dispatch({
      type: 'RedCrescentImsTickets/initTickets',
      payload: {
        allLocations,
        userLocation: this.state.userLocation,
        locationId: this.state.userLocationId,
      },
    });

    this.setState({ isLoading: false });
  }

  onChangeTab(activeKey) {
    this.fetchTicketsByLocation(activeKey);
  }

  getLocationId(locationKey: string) {
    const { locationKeys } = this.state;
    return Object.keys(locationKeys).find((key) => locationKeys[key] === locationKey);
  }

  fetchTicketsByLocation(locationKey) {
    const { dispatch } = this.props;
    const locationId = this.getLocationId(locationKey);

    this.setState({
      currentLocationId: locationId,
    });
    dispatch({
      type: 'RedCrescentImsTickets/fetchTicketsByLocation',
      payload: {
        locationKey,
        locationId,
      },
    });
  }

  handleUpdate() {
    const { currentLocationId: locationId, locationKeys } = this.state;
    const locationKey = locationKeys[locationId];
    this.fetchTicketsByLocation(locationKey);
  }

  render() {
    const { tickets, access } = this.props;
    const {
      isLoading,
      userLocation,
      userLocationId,
      locationKeys,
      currentLocationId,
      labtype,
    } = this.state;

    return !isLoading ? (
      <TicketsListContianer
        tickets={tickets}
        userLocation={userLocation}
        userLocationId={userLocationId}
        locationKeys={locationKeys}
        currentLocationId={currentLocationId}
        onChangeTab={this.onChangeTab}
        onUpdate={this.handleUpdate}
        access={access}
        labtype={labtype}
        redcrescentProfile={this.redcrescentProfile}
      />
    ) : (
      <Spin />
    );
  }
}

const IMSTicketsWrapper: React.FC<any> = (props) => {
  const { initialState } = useModel('@@initialState');
  const access = useAccess();
  return initialState?.currentUser ? (
    <IMSTickets {...props} currentUser={initialState.currentUser} access={access} />
  ) : null;
};

export default connect(({ RedCrescentImsTickets }: { RedCrescentImsTickets: any }) => {
  return {
    tickets: RedCrescentImsTickets,
  };
})(IMSTicketsWrapper);

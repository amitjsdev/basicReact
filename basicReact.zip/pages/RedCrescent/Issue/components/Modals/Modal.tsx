import React from 'react';
import { Modal, Button, Tooltip } from 'antd';
import { CheckOutlined } from '@ant-design/icons';
import { DeleteOutlined } from '@ant-design/icons';
import redCrescentService from '../../../services/redcrescent.service';
import { FormattedMessage, formatMessage } from 'umi';
class ApproveRejectModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      loading: false,
    };
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleOk = async (e) => {
    const { data } = this.props;
    const { status } = this.props;
    this.setState({
      loading: true,
    });
    if (!!this.props.approveManager) {
      const statusVal =
        this.props.approveManager === 'regionManagerApproved'
          ? { regionManagerApproved: true }
          : { generalManagerApproved: true, status: "completed" };
      await redCrescentService.updateIssueRequestStatus(data.id, statusVal);
      this.setState({
        visible: false,
        loading: false,
      });
    } else {
      await redCrescentService.updateTransferRequestStatus(data.id, status);
      this.setState({
        visible: false,
        loading: false,
      });
    }

    this.props.getIssue();
  };

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  };

  render() {
    const { visible, loading } = this.state;
    const { status } = this.props;
    return (
      <>
        <Tooltip
          title={
            status === 'rejected' ? (
              <FormattedMessage id="Reject" />
            ) : status === 'regionManagerApproved' ? (
              <FormattedMessage id="RegionManagerApproval" />
            ) : status === 'generalManagerApproved' ? (
              <FormattedMessage id="GeneralManagerApproval" />
            ) : status === 'AlreadyApproved' ? (
              <FormattedMessage id="AlreadyApproved" />
            ) : (
              <FormattedMessage id="Approve" />
            )
          }
        >
          <Button
            type="primary"
            style={this.props.style}
            shape="circle"
            icon={status === 'rejected' ? <DeleteOutlined /> : <CheckOutlined />}
            onClick={this.showModal}
            disabled={this.props.disabled === true}
          />
        </Tooltip>
        <Modal
          title={formatMessage({ id: 'Issue' })}
          visible={visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          maskClosable={false}
          footer={[
            <Button key="back" onClick={this.handleCancel} disabled={loading}>
              {<FormattedMessage id="Cancel" />}
            </Button>,
            <Button key="submit" type="primary" loading={loading} onClick={this.handleOk}>
              {<FormattedMessage id="Submit" />}
            </Button>,
          ]}
        >
          <span>
            {status === 'rejected' ? (
              <FormattedMessage id="DoYouRejectTheIssueRequest" />
            ) : (
              <FormattedMessage id="DoYouApproveTheIssueRequest" />
            )}
          </span>
        </Modal>
      </>
    );
  }
}

export default ApproveRejectModal;

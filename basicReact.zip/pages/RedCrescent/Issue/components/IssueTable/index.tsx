import React from 'react';
import { Access, useAccess, FormattedMessage } from 'umi';
import { Table, Space, Tooltip, Button } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';

import './index.css';
import { nestedColumns, IncomingColumns, OutcomingColumns } from './columns';
import Modal from '../Modals/Modal';
import redcrescentService from '../../../services/redcrescent.service';

class IssueTable extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      expandRowData: [],
      expandedRowKeys: [],
      pages: [0, 2],
      data: this.props.data.filter((v, i, a) => a.findIndex(t => (t.id === v.id)) === i),
      redCrescentProfile: this.props.redCrescentProfile
    };

  }

  download = async (values: any) => {
   // let filePdfName= 'pdf';
    const content = JSON.parse(values.content)

    await redcrescentService.downloadQrCode(
      content.requestMaterialsFileKey,content.fileName
    );
  }


  actionColumn = {
    title: <FormattedMessage id="Actions" />,
    key: 'action',
    render: (text, record, index) => (
      <>
        <Access accessible={this.props.access.canAccessRedCrescentTransferModule(
          this.props.locationId,
        )}>
          <div>
            <Space size={12}>
              <Modal data={record} getIssue={this.props.onChange} status={'rejected'} />
              <Modal
                disabled={(this.state.redCrescentProfile?.role === 'generalManager') || (record.regionManagerApproved === 1)}
                data={record}
                approveManager={'regionManagerApproved'}
                getIssue={this.props.onChange}
                status={record.regionManagerApproved === 1 ? 'AlreadyApproved' : 'regionManagerApproved'}
              />
              <Modal
                disabled={
                  (this.state.redCrescentProfile?.role == 'generalManager' &&
                    record.regionManagerApproved == 1) ||
                    (this.state.redCrescentProfile?.role === 'superUser' &&
                      record.regionManagerApproved == 1)
                    ? false
                    : true
                }
                data={record}
                approveManager={'generalManagerApproved'}
                getIssue={this.props.onChange}
                status={record.generalManagerApproved === 1 ? 'AlreadyApproved' : 'generalManagerApproved'}
              />

              <Tooltip title={<FormattedMessage id="Download" />}>
                <Button
                  type="primary"
                  shape="circle"
                  icon={<DownloadOutlined />}
                  onClick={() => this.download(record)}
                  disabled={record.content === null}
                />
              </Tooltip>
            </Space>
          </div>
        </Access>
      </>
    ),
  };

  downloadColumn = {
    title: <FormattedMessage id="Actions" />,
    key: 'action2',
    render: (text, record, index) => (

      <Access accessible={this.props.access.canAccessRedCrescentTransferModule(
        this.props.locationId,
      )}>
        <div>
          <Space size={12}>

            <Tooltip title={<FormattedMessage id="Download" />}>
              <Button
                type="primary"
                shape="circle"
                icon={<DownloadOutlined />}
                onClick={() => this.download(record)}
                disabled={record.content === null}
              />
            </Tooltip>
          </Space>
        </div>
      </Access>
    ),
  };



  keys: any[] = [];

  componentDidUpdate() {
    this.getMoreIssueRequest(0, 1, 1);
  }

  getExpandableData = (recordId, dataItems) => {
    this.keys[0] === recordId ? (this.keys = []) : (this.keys[0] = recordId);
    this.setState({
      expandRowData: [],
      expandedRowKeys: this.keys,
    });
    const data = dataItems;
    this.setState({
      expandRowData: data,
    });

  };

  expandedRowRender = () => (

    <Table columns={nestedColumns} dataSource={this.state.expandRowData} pagination={false} />
  );

  getMoreIssueRequest = (skip: any, pageNum: any, size: any) => {
    const { pages, data, getMoreIssueRequest } = this.props;
    if (!pages.includes(pageNum)) {
      const addPage = [...pages, pageNum];
      skip = data.length;
      getMoreIssueRequest({
        offset: skip,
        limit: 10,
      });
      this.props.setPages(addPage);
    }
  };

  render() {
    const columns = (this.state.redCrescentProfile.role === "generalManager" || this.state.redCrescentProfile.role === "regionManager" || this.state.redCrescentProfile.role === "superUser" || this.state.redCrescentProfile.role === "storeSupervisor") && (this.props.status === 'created') ? [...OutcomingColumns, this.actionColumn] : [...OutcomingColumns, this.downloadColumn];
    return (
      <div>
        <div>
          <Table
            id={`table-element_issue_${this.props.status}_${this.props.labType}_${this.props.locationId
              }`}
            columns={columns}
            dataSource={this.props.data}
            size="small"
            rowKey={(record) => record.id}
            pagination={{ pageSize: 10, showSizeChanger: false }}
            onExpand={(expanded, record) => this.getExpandableData(record.id, record.items)}
            expandedRowRender={(record) => this.expandedRowRender()}
            expandIconColumnIndex={0}
            expandedRowKeys={this.state.expandedRowKeys}
            expandIconAsCell={false}
            onChange={(e) => {
              this.getMoreIssueRequest(0, +e.current + 1, e.pageSize);
            }}
          />
        </div>
      </div>
    );
  }
}

const TransferTableWrapper = (props: any) => <IssueTable {...props} access={useAccess()} />;
export default TransferTableWrapper;

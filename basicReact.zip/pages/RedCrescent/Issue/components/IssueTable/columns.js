import React from 'react';
import moment from 'moment';
import { FormattedMessage, getLocale, formatMessage } from 'umi';
const DATE_FORMAT = 'YYYY-MM-DD';


export const OutcomingColumns = [
  {
    title: <FormattedMessage id="IssueNo" />,
    dataIndex: 'id',
    key: 'id',
  },
  // {
  //   title: <FormattedMessage id="ToLocation" />,
  //   dataIndex: 'toLocationName',
  //   key: 'toLocationName',
  // },
  {
    title: <FormattedMessage id="Status" />,
    dataIndex: 'status',
    key: 'status',
    render: (text, record) => {
      return formatMessage({ id: `${text.charAt(0).toUpperCase() + text.slice(1)}` });
    },
  },
  {
    title: <FormattedMessage id="CreatedOn" />,
    key: 'createdOn',
    dataIndex: 'createdAt',
    render: (text, record) => {
      return getLocale().includes( 'en')
        ? moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
        : moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD');
    },
  },
];
export const nestedColumns = [
  {
    title: <FormattedMessage id="ProductId" />,
    width: '200px',
    dataIndex: 'productId',
    key: 'productId',
  },
  {
    title: <FormattedMessage id="Quantity" />,
    width: '200px',
    dataIndex: 'quantity',
    key: 'quantity',
  },
  {
    title: <FormattedMessage id="Description" />,
    width: '200px',
    dataIndex: getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : ['product', 'description'] ,
    key: 'description',
  },
  {
    title: <FormattedMessage id="TransactionId" />,
    width: '150px',
    dataIndex: 'transactionId',
    key: 'transactionId',
  },
  {
    title: <FormattedMessage id="UpdatedAt" />,
    width: '150px',
    dataIndex: 'updatedAt',
    key: 'updatedAt',
    render: (text, record) =>
      getLocale().includes( 'en')
        ? moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD')
        : moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD'),
  },
  {
    title: <FormattedMessage id="CreatedAt" />,
    width: '150px',
    dataIndex: 'createdAt',
    key: 'createdAt',
    render: (text, record) =>
      getLocale().includes( 'en')
        ? moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD')
        : moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD'),
  },
];

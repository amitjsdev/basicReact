/* eslint-disable no-else-return */
import React, { useState, useEffect, Component, useRef, useCallback } from 'react';
import { connect, useModel, useHistory, useAccess, useIntl, getLocale } from 'umi';
import { Col, Row, Tabs, Menu, Button, Tooltip, Spin } from 'antd';
import IssueTable from './components/IssueTable';
import { PageContainer } from '@ant-design/pro-layout';
import redCrescentService from '../services/redcrescent.service';
import { TransferType } from './Types';
import { StateType } from './model';
import { LabTypes } from '@/services/Constants';

import styles from './index.less';

const { TabPane } = Tabs;

const IssueContainer = (props) => {
  const {
    issue = [],
    onChangeTab,
    currentIssueRequestLocationId,
    onUpdate,
    labType,
    access,
    pages,
    setPages,
    locationsKeys,
  } = props;

  const { redCrescentProfile } = props;

  const [filters, setFilters] = useState({ type: 'created' });

  const Filters = (onChange: any) => {
    const filtersData = [
      { value: 'created', key: useIntl().formatMessage({ id: 'Created' }) },
      { value: 'completed', key: useIntl().formatMessage({ id: 'Completed' }) },
      { value: 'rejected', key: useIntl().formatMessage({ id: 'Rejected' }) },
    ];

    // const filtersData = ['created', 'completed', 'rejected'];
    return (
      <>
        {filtersData &&
          filtersData.map((item) => {
            return (
              <Button
                type={filters.type === item.value ? 'primary' : 'default'}
                onClick={(e) => onChange(e, item.value)}
              >
                {item.key.charAt(0).toUpperCase() + item.key.slice(1)}
              </Button>
            );
          })}
      </>
    );
  };

  const onFilterChange = useCallback(
    (e: any, value: string) => {
      setFilters({
        type: value,
      });
      const locationCode = locationsKeys[currentIssueRequestLocationId];
      onChangeTab(locationCode, value);
    },
    [currentIssueRequestLocationId, issue],
  );
  const onChange = (activeKey?) => {
    setFilters({ type: 'created' });
    onChangeTab(activeKey);
  };

  const refreshIssueRequest = () => {
    onChangeTab(
      locationsKeys[currentIssueRequestLocationId],
      filters.type,
    );
  };
  const getMoreIssueRequest = (data) => {
    onChangeTab(
      locationsKeys[currentIssueRequestLocationId],
      filters.type,
      data,
    );
  };
  const getIssue = (allIssues: any[]) => {
    const issueList = Object.keys(allIssues).map((locationKey) => {
      const issueItem = allIssues[locationKey];
      return {

        ...issueItem,
        issue: issueItem.issue.map((item) => {

          return {
            ...item,
            fromRegionName:
              item && item.items && item.items.length > 0 && item.items[0]
                ? item.items[0].regionName
                : '',
            fromLocationName:
              item && item.items && item.items.length > 0 && item.items[0]
                ? getLocale().includes('en')
                  ? item.items[0].locationName
                  : item.items[0].location.arabicName
                : '',
            fromLabType:
              item && item.items && item.items.length > 0 && item.items[0]
                ? item.items[0].labType
                : '',
          };
        }),
      };
    });

    return access.canReadAllRedCrescentInventories(labType)
      ? issueList
      : issueList.filter(
        (issue) => issue?.locationDetails?.id === redCrescentProfile.locationId,
      );


  };

  return (
    <>
      {Object.keys(locationsKeys).length > 0 ? (
        <div className={styles.main}>
          <div className={styles.container}>
            <Row gutter={[24, 24]}>
              <Col span={24}>
                <div>
                  <Tabs
                    activeKey={locationsKeys[currentIssueRequestLocationId]}
                    onChange={onChange}
                    tabBarExtraContent={Filters(onFilterChange)}
                  >
                    {getIssue(issue).map((issueItem: TransferType) => {
                      const key = locationsKeys[issueItem.locationDetails.id];
                      return (
                        <TabPane
                          key={key}
                          tab={
                            <Tooltip
                              title={
                                getLocale().includes('en')
                                  ? issueItem.locationDetails.name
                                  : issueItem.locationDetails.arabicName
                              }
                            >
                              {issueItem.locationDetails.code}
                            </Tooltip>
                          }
                        >
                          <PageContainer content="">
                            <IssueTable
                              data={issueItem.issue}
                              status={filters.type}
                              locationId={issueItem.locationDetails.id}
                              onUpdate={onUpdate}
                              labType={labType}
                              onChange={refreshIssueRequest}
                              getMoreIssueRequest={getMoreIssueRequest}
                              pages={pages}
                              setPages={setPages}
                              redCrescentProfile={redCrescentProfile}
                            />
                          </PageContainer>

                        </TabPane>
                      );
                    })}
                  </Tabs>
                </div>
              </Col>
            </Row>
          </div>
        </div>
      ) : (
        <></>
      )}
    </>
  );
};

interface PropsType {
  currentUser: App.CurrentUser;
  labType: App.LabType;
  access: any;
  dispatch: any;
}

class RedCrescentIssue extends Component<PropsType, any> {
  redCrescentProfile: App.Module | undefined;

  constructor(props) {
    super(props);

    const { currentUser }: App.InitialStateType = props;
    this.redCrescentProfile = currentUser?.modules.find(
      (module) => module.name === this.props.labType,
    );
    const userLocationId = this.redCrescentProfile?.locationId;

    this.state = {
      userLocationId,
      userLocation: '',
      currentIssueRequestLocationId: userLocationId,
      status: '',
      pages: [0, 2],
      locationsKeys: {},
      labType: window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC,
    };

    this.onChangeTab = this.onChangeTab.bind(this);
  }
  setPages = (pages) => {
    this.setState({
      pages,
    });
  };
  async componentDidMount() {
    const { dispatch } = this.props;
    const locationsKeysData = {};
    const allLocationDetails = (await redCrescentService.getLocations('medicalredcrescent')) || [];
    allLocationDetails.forEach((location: any) => {
      locationsKeysData[location.id] = location.code;
    });
    this.setState(
      {
        locationsKeys: locationsKeysData,
      },
      () => {
        this.setState((prevState) => ({
          userLocation: this.state.locationsKeys[this.state.userLocationId],
          currentIssueRequestLocationId: this.state.userLocationId,
          labtype: window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC,
          locationsKeys: locationsKeysData,
        }));
        dispatch({
          type: 'redCrescentIssue/initIssue',
          payload: {
            allLocationDetails,
            userLocation: this.state.locationsKeys[this.state.userLocationId],
            locationId: this.state.userLocationId,
            labType: this.state.labType,
            outGoing: false,
            status: 'created',
            params: { offset: 0, limit: 20 },
          },
        });
      },
    );
  }
  onChangeTab(locationKey, filter = 'created', data) {
    const { locationsKeys, labType } = this.state;
    const { dispatch } = this.props;
    const selectedLocation = Object.keys(locationsKeys).find(
      (location) => locationsKeys[location] === locationKey,
    );
    this.setState({
      currentIssueRequestLocationId: parseInt(selectedLocation),
      userLocationId: parseInt(selectedLocation),
    });
    dispatch({
      type: 'redCrescentIssue/fetchIssue',
      payload: {
        locationKey,
        locationId: parseInt(selectedLocation),
        params: data ? data : { offset: 0, limit: 20 },
        labType,
        status: filter,
      },
    });
  }

  render() {
    const { issue } = this.props;
    const { pages, locationsKeys, currentIssueRequestLocationId } = this.state;

    return (
      <div key={JSON.stringify(locationsKeys)}>
        <Row className={styles.main}>
          <Col span={24}>
            <IssueContainer
              issue={issue}
              userLocation={this.state.userLocation}
              userLocationId={this.state.userLocationId}
              onChangeTab={this.onChangeTab}
              pages={pages}
              setPages={this.setPages}
              currentIssueRequestLocationId={currentIssueRequestLocationId}
              locationsKeys={locationsKeys}
              labType={this.props.labType}
              access={this.props.access}
              redCrescentProfile={this.redCrescentProfile}
            />
          </Col>
        </Row>
      </div>
    );
  }
}

const RedCrescentIssueWrapper: React.FC<any> = (props) => {
  const { initialState, loading } = useModel('@@initialState');
  const access = useAccess();
  const history = useHistory();
  const labType = window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC;
  return loading ? (
    <Spin />
  ) : (
    <RedCrescentIssue
      {...props}
      currentUser={initialState?.currentUser}
      access={access}
      labType={labType}
    />
  );
};

export default connect(({ redCrescentIssue }: { redCrescentIssue: StateType }) => {
  return {
    issue: redCrescentIssue,
  };
})(RedCrescentIssueWrapper);

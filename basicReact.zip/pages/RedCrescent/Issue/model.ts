import { Effect, Reducer } from 'umi';

import redCrescentService from '../services/redcrescent.service';
import { LocationType } from './Types';
import { uniqBy } from 'lodash';
export interface StateType {
  // other: InventoryType | null;
  // RLRI: InventoryType | null;
  // RLJE: InventoryType | null;
  // RLMA: InventoryType | null;
  // RLME: InventoryType | null;
}

export interface ModelType {
  namespace: string;
  state: StateType;
  effects: {
    initIssue: Effect;
    fetchIssue: Effect;
    fetchLocations: Effect;
    updateProduct: Effect;
    placeOrder: Effect;
    fetchFilteredIssue: Effect;
  };
  reducers: {
    updateIssue: Reducer<StateType>;
    addLocations: Reducer<StateType>;
    addIssue: Reducer<StateType>;
    updateQuantity: Reducer<StateType>;
    updateBatch: Reducer<StateType>;
  };
}

const locationsKeys: {} = {};

const Model: ModelType = {
  namespace: 'redCrescentIssue',
  state: {
    // RLRI: null,
    // RLMA: null,
    // RLME: null,
    // RLJE: null,
    // other: null,
  },
  effects: {
    // Init store
    *initIssue({ payload }, { call, put }) {
      const { userLocation, allLocationDetails, ...getTransferParams } = payload;
      const { data } = yield call(redCrescentService.getIssueRequest, getTransferParams);
      const issue = {};
      allLocationDetails.forEach((location: LocationType) => {
        locationsKeys[location.id] = location.code;
        const locationKey = location.code;
        issue[locationKey] = { locationDetails: location, issue: [] };
      });

      issue[userLocation].issue = data;
      yield put({
        type: 'updateIssue',
        payload: issue,
      });
    },
    // Fetch data from server and store
    *fetchIssue({ payload }, { call, put }) {
      const { locationKey, ...getTransferParams } = payload;
      const { data } = yield call(redCrescentService.getIssueRequest, getTransferParams);
      yield put({
        type: 'addIssue',
        payload: {
          locationKey,
          issue: data,
          offset: getTransferParams.params.offset,
        },
      });
    },
    *fetchFilteredIssue({ payload }, { call, put }) {
      const { locationKey, ...getTransferParams } = payload;
      const { data } = yield call(redCrescentService.getFilteredTransfer, getTransferParams);

      yield put({
        type: 'addTransfer',
        payload: {
          locationKey,
          issue: data,
          offset: getTransferParams.offset,
        },
      });
    },
    *fetchLocations({ payload }, { call, put }) {
      const locations = yield call(redCrescentService.getLocations, payload);

      yield put({
        type: 'addLocations',
        payload: locations,
      });
    },
    // Update product
    *updateProduct({ payload }, { call, put }) {
      yield;
    },
    *placeOrder({ payload }, { call, put }) {
      yield;
    },
  },
  reducers: {
    updateIssue(state, { payload }) {
      return { ...state, ...payload };
    },
    // Add location details to inventories
    addLocations(state, { payload }) {
      const transferLocationDetails = {};

      payload.forEach((location: LocationType) => {
        const locationKey = locationsKeys[location.id];
        transferLocationDetails[locationKey] = { locationDetails: location };
      });

      const newState = {};
      Object.values(locationsKeys).forEach((location) => {
        newState[location] = {
          locationDetails: transferLocationDetails[location],
          issue: state[location].issue,
        };
      });

      return newState;
    },
    // Add skus to the store
    addIssue(state, { payload }) {
      const inventoryKey = payload.locationKey;
      const transferToBeAdded = {};
      const issues =
        payload.offset > 0 ? [...state[inventoryKey].issue, ...payload.issue] : payload.issue;
      transferToBeAdded[inventoryKey] = {
        locationDetails: state[inventoryKey].locationDetails,
        issue: uniqBy(issues, 'id'),
      };

      return {
        ...state,
        ...transferToBeAdded,
      };
    },
    // Update quantity in hand of a product
    updateQuantity(state, { payload }) {
      return {
        ...state,
      };
    },
    updateBatch(state, { payload }) {
      return {
        ...state,
      };
    },
  },
};

export default Model;

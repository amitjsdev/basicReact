import { Effect, Reducer } from 'umi';

import redCrescentService from '../services/redcrescent.service';
import { LocationType } from './Types';

export interface StateType {
  // other: InventoryType | null;
  // RLRI: InventoryType | null;
  // RLJE: InventoryType | null;
  // RLMA: InventoryType | null;
  // RLME: InventoryType | null;
}

export interface ModelType {
  namespace: string;
  state: StateType;
  effects: {
    initTransfer: Effect;
    fetchTransfer: Effect;
    fetchLocations: Effect;
    updateProduct: Effect;
    placeOrder: Effect;
    fetchFilteredTransfer: Effect;
  };
  reducers: {
    updateTransfer: Reducer<StateType>;
    addLocations: Reducer<StateType>;
    addTransfer: Reducer<StateType>;
    updateQuantity: Reducer<StateType>;
    updateBatch: Reducer<StateType>;
  };
}

const locationsKeys: {} = {};

const Model: ModelType = {
  namespace: 'redCrescentDelegate',
  state: {
    // RLRI: null,
    // RLMA: null,
    // RLME: null,
    // RLJE: null,
    // other: null,
  },
  effects: {
    // Init store
    *initTransfer({ payload }, { call, put }) {
      const { userLocation, allLocationDetails, ...getTransferParams } = payload;
      const { data } = yield call(redCrescentService.getTransferRequest, getTransferParams);
      const transfer = {};
      allLocationDetails.forEach((location: LocationType) => {
        locationsKeys[location.id] = location.code;
        const locationKey = location.code;
        transfer[locationKey] = { locationDetails: location, transfer: [] };
      });

      transfer[userLocation].transfer = data;
      yield put({
        type: 'updateTransfer',
        payload: transfer,
      });
    },
    // Fetch data from server and store
    *fetchTransfer({ payload }, { call, put }) {
      const { locationKey, ...getTransferParams } = payload;
      const { data } = yield call(redCrescentService.getTransferRequest, getTransferParams);
      yield put({
        type: 'addTransfer',
        payload: {
          locationKey,
          transfer: data,
          offset:getTransferParams.params.offset
        },
      });
    },
    *fetchFilteredTransfer({ payload }, { call, put }) {
      const { locationKey, ...getTransferParams } = payload;
      const { data } = yield call(redCrescentService.getFilteredTransfer, getTransferParams);

      yield put({
        type: 'addTransfer',
        payload: {
          locationKey,
          transfer: data,
          offset:getTransferParams.offset
        },
      });
    },
    *fetchLocations({ payload }, { call, put }) {
      const locations = yield call(redCrescentService.getLocations, payload);

      yield put({
        type: 'addLocations',
        payload: locations,
      });
    },
    // Update product
    *updateProduct({ payload }, { call, put }) {
      yield;
    },
    *placeOrder({ payload }, { call, put }) {
      yield;
    },
  },
  reducers: {
    updateTransfer(state, { payload }) {
      return { ...state, ...payload };
    },
    // Add location details to inventories
    addLocations(state, { payload }) {
      const transferLocationDetails = {};

      payload.forEach((location: LocationType) => {
        const locationKey = locationsKeys[location.id];
        transferLocationDetails[locationKey] = { locationDetails: location };
      });

      const newState = {};
      Object.values(locationsKeys).forEach((location) => {
        newState[location] = {
          locationDetails: transferLocationDetails[location],
          transfer: state[location].transfer,
        };
      });

      return newState;
    },
    // Add skus to the store
    addTransfer(state, { payload }) {
      const inventoryKey = payload.locationKey;
      const transferToBeAdded = {};
      transferToBeAdded[inventoryKey] = {
        locationDetails: state[inventoryKey].locationDetails,
        transfer: payload.offset>0?[...state[inventoryKey].transfer,...payload.transfer]:payload.transfer,
      };

      return {
        ...state,
        ...transferToBeAdded,
      };
    },
    // Update quantity in hand of a product
    updateQuantity(state, { payload }) {
      return {
        ...state,
      };
    },
    updateBatch(state, { payload }) {
      return {
        ...state,
      };
    },
  },
};

export default Model;

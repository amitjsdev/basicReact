import React from 'react';
import { useAccess, FormattedMessage } from 'umi';
import { Table, Space } from 'antd';
import './index.css';
import { nestedColumns, IncomingColumns, OutcomingColumns } from './columns';
import Modal from '../Modals/Modal';
import redCrescentService from '../../../services/redcrescent.service';

class DelegateTable extends React.Component {
  state = {
    expandRowData: [],
    expandedRowKeys: [],
    pages: [0, 2],
  };
  actionIncomingColumn = {
    title: <FormattedMessage id="Actions" />,
    key: 'action',
    render: (text, record, index) => (
      <div>
        <Space size={12}>
          <Modal data={record} filter={'incoming'} getTransfer={this.props.onChange} status={'rejected'} />
          {!record.delegateAccepted && (
            <Modal data={record} filter={'incoming'} getTransfer={this.props.onChange} status={'completed'} />
          )}
        </Space>
      </div>
    ),
  };
  actionOutgoingColumn = {
    title: <FormattedMessage id="Actions" />,
    key: 'action',
    render: (text, record, index) => (
      <div>
        <Space size={12}>
          <Modal data={record} getTransfer={this.props.onChange} status={'revoked'} />
        </Space>
      </div>
    ),
  };
  keys: any[] = [];
  componentDidUpdate() {
    this.getMoreTransferRequest(0, 1, 1);
  }
  getExpandableData = (recordId, dataItems) => {
    this.keys[0] === recordId ? (this.keys = []) : (this.keys[0] = recordId);
    this.setState({
      expandRowData: [],
      expandedRowKeys: this.keys,
    });
    const data = dataItems;
    this.setState({
      expandRowData: data,
    });
  };

  expandedRowRender = () => (
    <Table columns={nestedColumns} dataSource={this.state.expandRowData} pagination={false} />
  );
  getMoreTransferRequest = (skip: any, pageNum: any, size: any) => {
    const { pages, data, getMoreTransferRequest } = this.props;
    if (!pages.includes(pageNum)) {
      const addPage = [...pages, pageNum];
      skip = data && data.length;

      getMoreTransferRequest({
        offset: skip,
        limit: 10,
      });
      this.props.setPages(addPage);
    }
  };
  render() {
    const { data, status, activeTab } = this.props;
    const columns =
      activeTab === 'incoming'
        ? [...IncomingColumns, this.actionIncomingColumn]
        : [...OutcomingColumns, this.actionOutgoingColumn];
    return (
      <div>
        <div>
          <Table
            columns={columns}
            dataSource={data}
            size="small"
            rowKey={(record) => record.id}
            pagination={{ pageSize: 10, showSizeChanger: false }}
            expandIconColumnIndex={0}
            expandIconAsCell={false}
          />
        </div>
      </div>
    );
  }
}

const DelegateTableWrapper = (props: any) => <DelegateTable {...props} access={useAccess()} />;
export default DelegateTableWrapper;

import React from 'react';
import moment from 'moment';
import { FormattedMessage, getLocale, formatMessage } from 'umi';
const DATE_FORMAT = 'YYYY-MM-DD';

export const IncomingColumns = [
  {
    title: <FormattedMessage id="Id" />,
    dataIndex: ['delegateFrom','id'],
    key: 'id',
  },
  {
    title: <FormattedMessage id="Category" />,
    dataIndex: ['delegateFrom','category'],
    key: 'category',
  },
  // {
  //   title: <FormattedMessage id="Classification" />,
  //   dataIndex: ['delegateFrom','classification'],
  //   key: 'classification',
  // },
  {
    title: <FormattedMessage id="DelegateReason" />,
    dataIndex: 'delegateReason',
    key: 'delegateReason',
  },
  {
    title: <FormattedMessage id="DelegateEndDate" />,
    key: 'delegateEndDate',
    dataIndex: 'delegateEndDate',
    render: (text, record) => {
      return getLocale().includes( 'en')
        ? moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
        : moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD');
    },
  },
];

export const OutcomingColumns = [
  {
    title: <FormattedMessage id="Id" />,
    dataIndex: 'id',
    key: 'id',
  },
  {
    title: <FormattedMessage id="Category" />,
    dataIndex: 'category',
    key: 'category',
  },
  // {
  //   title: <FormattedMessage id="Classification" />,
  //   dataIndex: 'classification',
  //   key: 'classification',
  // },
  {
    title: <FormattedMessage id="DelegateReason" />,
    dataIndex: 'delegateReason',
    key: 'delegateReason',
  },
  {
    title: <FormattedMessage id="DelegateEndDate" />,
    key: 'delegateEndDate',
    dataIndex: 'delegateEndDate',
    render: (text, record) => {
      return getLocale().includes( 'en')
        ? moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
        : moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD');
    },
  },
];

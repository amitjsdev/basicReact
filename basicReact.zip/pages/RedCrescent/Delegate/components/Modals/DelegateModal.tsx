import React, { useState } from 'react';
import { Form, Button, Row, Col, Modal, Select, DatePicker, Input } from 'antd';
import redCrescentService from '../../../services/redcrescent.service';
import { formatMessage } from 'umi';
import moment from 'moment';
const { TextArea } = Input;

const BasicDelegateForm = (props: any) => {
  const { handleOk, handleCancel, users, redCrescentProfile } = props;


  const [selectedUser, setSelectedUser] = useState('');
  const [selectedModule, setSelectedModule] = useState('');

  const [formNote, setFormNote] = useState('');

  const [form] = Form.useForm();
  const dateFormat = 'YYYY-MM-DD';
  const onFinish = (value: any) => {
    let accessId = '';
    let locationID = '';
    let labType = ''
    redCrescentProfile.map((module) => {
      if (module.classificationAccesses) {
        module.classificationAccesses.map((classification) => {
          if (classification.id == value.Module) {
            accessId = classification.accessId;
            locationID = classification.locationId
            labType = module.name
          }
        })
      }

    })

    const payload = {
      labType: labType,
      locationId: locationID,
      userId: value.User,
      delegateReason: formNote,
      classificationAccessId: value.Module,

      delegateEndDate: moment(value['End Date']).format(dateFormat),
    };
    handleOk(payload);
  };
  const disabledPastDates = (current: any) => {
    // Can not select days after today
    return current && current < moment().add(1, 'days');
  };

  const onCancel = (e) => {
    handleCancel(e);
  };


  return (
    <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item
            name="User"
            label={formatMessage({ id: 'User' })}
            rules={[{ required: true, message: formatMessage({ id: 'PleaseSelectAUser' }) }]}
          >
            <Select value={selectedUser} onChange={(value) => setSelectedUser(value)}>
              {users &&
                users.map((user) => {
                  return (
                    <Option key={user.id} value={user.id}>
                      {user.name && user.role && user.type
                        ? `${user.name} (${user.role} at ${user.type})`
                        : `${user.name} (${user.type})`}
                    </Option>
                  );
                })}
            </Select>
          </Form.Item>
        </Col>
      </Row>
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item
            name="Module"
            label={formatMessage({ id: 'Module' })}
            rules={[{ required: true, message: formatMessage({ id: 'PleaseSelectAModule' }) }]}
          >
            <Select value={selectedModule} onChange={(value) => setSelectedModule(value)}>

              {redCrescentProfile && redCrescentProfile.length > 0 &&
                redCrescentProfile.map((module) => {
                  return module && module.name.includes("redcrescent") && module.classificationAccesses?.map((classification) => {
                    if (!classification.isDelegate) {
                      return (
                        <Option key={classification.id} value={classification.id}>
                          {`${classification.category}`}
                        </Option>
                      );
                    }

                  })

                })}
            </Select>
          </Form.Item>
        </Col>
      </Row>
      <Row gutter={[24, 24]}>
        <Col span={12}>
          <Form.Item
            label={formatMessage({ id: 'EndDate' })}
            name='EndDate'
            initialValue={moment(new Date(), dateFormat)}
            rules={[{ required: true, message: 'MissingEnddate' }]}
          >
            <DatePicker
              defaultValue={moment(new Date(), dateFormat)}
              disabledDate={disabledPastDates}
              format={dateFormat}
              style={{ width: '100%' }}
            />
          </Form.Item>
        </Col>
      </Row>
      <Row gutter={[24, 24]}>
        <Col span={24}>
          {' '}
          <TextArea
            name="note"
            placeholder="Note"
            value={formNote}
            onChange={(event) => setFormNote(event.target.value)}
          />
        </Col>
      </Row>
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item>
            <Button type="primary" htmlType="submit" block>
              {formatMessage({ id: 'Apply' })}
            </Button>
          </Form.Item>
        </Col>
        <Col flex={1}>
          <Form.Item>
            <Button onClick={(e) => onCancel(e)} block>
              {formatMessage({ id: 'Cancel' })}
            </Button>
          </Form.Item>
        </Col>
      </Row>
    </Form>
  );
};

class DelegateModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      users: [],
    };
  }

  async componentDidMount() {
    const users = await redCrescentService.getUsersForDelegate();

    const userList = users.filter((user) => user.email !== this.props.currentUser.email)
    this.setState({
      userList,
    });
  }

  handleOk = async (data) => {
    this.setState({
      loading: true,
    });
    await redCrescentService.delegateRequest([data]);
    this.setState({
      loading: false,
    });
    this.props.handleOk();
    window.location.reload();

  };

  render() {
    const { loading, userList } = this.state;
    const { status, isVisible } = this.props;
    return (
      <>
        <Modal
          title={formatMessage({ id: 'RequestDelegate' })}
          visible={isVisible}
          destroyOnClose
          closable={false}
          footer={false}
        >
          <BasicDelegateForm
            labType={this.props.labType}
            users={userList}
            handleOk={(e, data: any) => this.handleOk(e, data)}
            handleCancel={(e) => this.props.handleCancel(e)}
            redCrescentProfile={this.props.redCrescentProfile}
          />
        </Modal>
      </>
    );
  }
}

export default DelegateModal;

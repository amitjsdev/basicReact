import React from 'react';
import { Modal, Button, Tooltip } from 'antd';
import { CheckOutlined } from '@ant-design/icons';
import { DeleteOutlined } from '@ant-design/icons';
import redCrescentService from '../../../services/redcrescent.service';
import { FormattedMessage, formatMessage } from 'umi';
class ApproveRejectModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: props.isVisible,
      loading: false,
    };
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleOk = async (e) => {

    const { data } = this.props;
    const { status, filter } = this.props;
    this.setState({
      loading: true,
    });
    let obj = {}

    if (status !== 'revoked') {
      if (status === 'rejected') {
        obj = {
          id: data.id,
          hasExpired: true,
          delegateAccepted: false
        }
      }
      else {
        obj = {
          id: data.id,
          delegateAccepted: true,
          hasExpired: false,
        }
      }
    } else {

      obj = {
        id: data.id,
        hasExpired: true,
        delegateUserId: null,
        delegateAccessId: null,
        delegateReason: null,
        delegateEndDate: null
      }
    }
    const response = await redCrescentService.delegateUpdateRequest(obj);
    this.setState({
      visible: false,
      loading: false,
    });
    if (response) {
      this.props.getTransfer()

    }
    if (filter === "incoming") {
      window.location.reload();
    }

    //     const profileData = await redCrescentService.getUserProfileData();
    //     const { currentUser }: App.InitialStateType = this.props;
    //     const filtered = profileData.modules.filter((i) => i.role === currentUser.role && i.name === labType);
    //     this.setState({ redCrescentProfile: filtered});
    // //window.location.reload();  
  };

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  };

  render() {
    const { visible, loading } = this.state;
    const { status } = this.props;
    return (
      <>
        <Tooltip
          title={
            status === 'rejected' ? (
              <FormattedMessage id="Reject" />
            ) : status === 'completed' ? (
              <FormattedMessage id="Approve" />
            ) : <FormattedMessage id="Revoke" />
          }
        >
          <Button
            type="primary"
            style={this.props.style}
            shape="circle"
            icon={status === 'rejected' || status === 'revoked' ? <DeleteOutlined /> : <CheckOutlined />}
            onClick={this.showModal}
          />
        </Tooltip>
        <Modal
          title={formatMessage({ id: 'Delegate' })}
          visible={visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          maskClosable={false}
          footer={[
            <Button key="back" onClick={this.handleCancel} disabled={loading}>
              {<FormattedMessage id="Cancel" />}
            </Button>,
            <Button key="submit" type="primary" loading={loading} onClick={this.handleOk}>
              {<FormattedMessage id="Submit" />}
            </Button>,
          ]}
        >
          <span>
            {status === 'rejected' ? (
              <FormattedMessage id="DoYouRejectTheDelegateRequest" />
            ) : status === 'completed' ? (
              <FormattedMessage id="DoYouApproveTheDelegateRequest" />
            ) : <FormattedMessage id="DoYouRevokeTheTransferRequest" />}
          </span>
        </Modal>
      </>
    );
  }
}

export default ApproveRejectModal;

/* eslint-disable no-else-return */
import React, { useState, useEffect, Component, useRef, useCallback } from 'react';
import { Access, connect, useModel, useHistory, useAccess, useIntl, getLocale, formatMessage } from 'umi';
import { Col, Row, Tabs, Menu, Button, Tooltip, Spin } from 'antd';
import DelegateTable from './components/DelegateTable';
import { PageContainer } from '@ant-design/pro-layout';
import redCrescentService from '../services/redcrescent.service';
import { TransferType } from './Types';
import { StateType } from './model';
import { LabTypes } from '@/services/Constants';
import DelegateModal from './components/Modals/DelegateModal';
import styles from './index.less';

const { TabPane } = Tabs;

const DelegateContainer = (props) => {
  const {
    onChangeTab,
    currentTransferRequestLocationId,
    onUpdate,
    labType,
    access,
    pages,
    setPages,
    locationsKeys,
    setDelegateModal,
    allLocations,
    redCrescentProfile,
  } = props;
  const [filters, setFilters] = useState({ type: 'created' });
  const [activeTab, setActiveTab] = useState('incoming');
  const [data, setData] = useState([]);
  const Filters = (onChange: any) => {
    const filtersData = [
      { value: 'created', key: useIntl().formatMessage({ id: 'Created' }) },
      { value: 'completed', key: useIntl().formatMessage({ id: 'Completed' }) },
      { value: 'rejected', key: useIntl().formatMessage({ id: 'Rejected' }) },
    ];

    // const filtersData = ['created', 'completed', 'rejected'];
    return (
      <>
        {filtersData &&
          filtersData.map((item) => {
            return (
              <Button
                type={filters.type === item.value ? 'primary' : 'default'}
                onClick={(e) => onChange(e, item.value)}
              >
                {item.key.charAt(0).toUpperCase() + item.key.slice(1)}
              </Button>
            );
          })}
      </>
    );
  };
  const RequestDelegate = () => {
    return (
      <>
        <Button
          onClick={(e) => {
            setDelegateModal(e);
          }}
        >
          {formatMessage({ id: 'RequestDelegate' })}
        </Button>
      </>
    );
  };
  // const onFilterChange = useCallback(
  //   (e: any, value: string) => {
  //     setFilters({
  //       type: value,
  //     });
  //     const locationCode = locationsKeys[currentTransferRequestLocationId];
  //     onChangeTab(locationCode, activeTab !== 'incoming', value);
  //   },
  //   [currentTransferRequestLocationId, transfer, activeTab],
  // );

  const onChangeIncoming = (activeKey: string) => {
    const locationCode = locationsKeys[currentTransferRequestLocationId];
    setActiveTab(activeKey);
    onChangeTab(locationCode, activeKey !== 'incoming', filters.type);
  };

  const onChange = (activeKey?) => {
    setFilters({ type: 'created' });
    setActiveTab('incoming');
    onChangeTab(activeKey);
  };

  const refreshTransferRequest = () => {
    onChangeTab(
      locationsKeys[currentTransferRequestLocationId],
      activeTab !== 'incoming',
      filters.type,
    );
  };
  const getMoreTransferRequest = (data) => {
    onChangeTab(
      locationsKeys[currentTransferRequestLocationId],
      activeTab !== 'incoming',
      filters.type,
      data,
    );
  };
  useEffect(() => {
    let incomingArr = [];
    let outgoingArr = [];
    redCrescentProfile.map((module) => {
      return (
        module.classifications &&
        module.classifications.map((classification) => {
          if (classification.isDelegate) {
            incomingArr.push(classification);
          } else {
            if (classification.delegateUserId) {
              outgoingArr.push(classification);
            }
          }
        })
      );
    });
    if (activeTab === 'incoming') {
      let data = [];
      if (redCrescentProfile && redCrescentProfile.length > 0) {
        redCrescentProfile.forEach(module => {
          if (module.delegationAccesses) {
            const t = module.delegationAccesses.filter((item) => item.hasExpired === 0)
            data = [...data, ...t]
          }
        })
      }
      setData(
        data,
      );
    } else {
      let data = [];
      if (redCrescentProfile && redCrescentProfile.length > 0) {
        redCrescentProfile.forEach(module => {
          if (module.toDelegationAccesses) {
            const t = module.toDelegationAccesses.filter((item) => item.hasExpired === 0)
            data = [...data, ...t]
          }
        })
      }
      setData(
        data
      );
    }
  }, [activeTab, redCrescentProfile]);
  const redcrescentProfileLocation = [];
  if (redCrescentProfile && redCrescentProfile.length > 0) {
    let obj = redCrescentProfile[0];
    redcrescentProfileLocation.push(obj);
  }

  return (
    <>

      {Object.keys(locationsKeys).length > 0 ? (
        <div className={styles.main}>
          <div className={styles.container}>
            <Row gutter={[24, 24]}>
              <Col span={24}>
                <div>
                  <Tabs
                    activeKey={locationsKeys[currentTransferRequestLocationId]}
                    onChange={onChange}
                    tabBarExtraContent={RequestDelegate()}
                  >
                    {redcrescentProfileLocation.map((transferItem: TransferType) => {
                      const key = locationsKeys[transferItem.locationId];
                      return (
                        <TabPane
                          key={key}
                          tab={
                            <Tooltip
                              title={
                                getLocale().includes('en')
                                  ? transferItem.location.name
                                  : transferItem.location.arabicName
                              }
                            >
                              {transferItem.location.code}
                            </Tooltip>
                          }
                        >
                          <Tabs activeKey={activeTab} onChange={onChangeIncoming}>
                            <TabPane
                              key="incoming"
                              tab={
                                <Tooltip title={useIntl().formatMessage({ id: 'Incoming' })}>
                                  {useIntl().formatMessage({ id: 'Incoming' })}
                                </Tooltip>
                              }
                            >
                              {' '}
                              <PageContainer content="">
                                <DelegateTable
                                  data={data}
                                  activeTab={activeTab}
                                  status={filters.type}
                                  locationId={transferItem.id}
                                  onUpdate={onUpdate}
                                  labType={labType}
                                  onChange={refreshTransferRequest}
                                  getMoreTransferRequest={getMoreTransferRequest}
                                  pages={pages}
                                  setPages={setPages}
                                />
                              </PageContainer>
                            </TabPane>
                            <TabPane
                              key="outgoing"
                              tab={
                                <Tooltip title={useIntl().formatMessage({ id: 'Outgoing' })}>
                                  {useIntl().formatMessage({ id: 'Outgoing' })}
                                </Tooltip>
                              }
                            >
                              <PageContainer content="">
                                <DelegateTable
                                  activeTab={activeTab}
                                  data={data}
                                  status={filters.type}
                                  locationId={transferItem.id}
                                  onUpdate={onUpdate}
                                  labType={labType}
                                  onChange={refreshTransferRequest}
                                  getMoreTransferRequest={getMoreTransferRequest}
                                  pages={pages}
                                  setPages={setPages}
                                />
                              </PageContainer>
                            </TabPane>
                          </Tabs>
                        </TabPane>
                      );
                    })}
                  </Tabs>
                </div>
              </Col>
            </Row>
          </div>
        </div>
      ) : (
        <></>
      )}
    </>
  );
};

interface PropsType {
  currentUser: App.CurrentUser;
  labType: App.LabType;
  access: any;
  dispatch: any;
}

class RedCrescentDelegate extends Component<PropsType, any> {
  redCrescentProfile: App.Module | undefined;

  constructor(props) {
    super(props);
    const { currentUser }: App.InitialStateType = props;

    this.redCrescentProfile = currentUser?.modules;
    const userLocationId = this.redCrescentProfile[0]?.locationId;

    this.state = {
      userLocationId,
      userAccess: this.props.access,
      userLocation: '',
      currentTransferRequestLocationId: userLocationId,
      status: '',
      pages: [0, 2],
      locationsKeys: {},
      labType: window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC,
      requestDelegateModal: false,
      allLocations: '',
      incomingData: [],
      outGoingData: [],
      currentUser: currentUser,
      redCrescentProfile: this.redCrescentProfile,
    };

    this.onChangeTab = this.onChangeTab.bind(this);
  }
  setPages = (pages) => {
    this.setState({
      pages,
    });
  };
  setDelegateModal = (e) => {
    e.preventDefault();
    this.setState({
      requestDelegateModal: !this.state.requestDelegateModal,
    });
  };
  async componentWillMount() {
    const allLocationDetails = (await redCrescentService.getLocations('medicalredcrescent')) || [];
    this.setState({ allLocations: allLocationDetails });
  }
  async componentDidMount() {
    const { dispatch } = this.props;
    const locationsKeysData = {};
    const allLocationDetails = (await redCrescentService.getLocations('medicalredcrescent')) || [];
    allLocationDetails.forEach((location: any) => {
      locationsKeysData[location.id] = location.code;
    });

    this.setState(
      {
        locationsKeys: locationsKeysData,
      },
      () => {
        this.setState((prevState) => ({
          userLocation: this.state.locationsKeys[this.state.userLocationId],
          currentTransferRequestLocationId: this.state.userLocationId,
          labtype: window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC,
          locationsKeys: locationsKeysData,
          incomingData:
            this.redCrescentProfile[0] && this.redCrescentProfile[0]?.delegationAccesses
              ? this.redCrescentProfile[0]?.delegationAccesses.filter(
                (item) => item.hasExpired === 0,
              )
              : '',
          outGoingData:
            this.redCrescentProfile[0] && this.redCrescentProfile[0]?.toDelegationAccesses
              ? this.redCrescentProfile[0]?.toDelegationAccesses.filter(
                (item) => item.hasExpired === 0,
              )
              : '',
        }));

      
      },
    );
  }
  async onChangeTab(locationKey, isOutGoing = false, filter = 'created', data) {
    const { locationsKeys, labType } = this.state;
    const { dispatch } = this.props;
    const profileData = await redCrescentService.getUserProfileData();
    const { currentUser }: App.InitialStateType = this.props;
    const filtered = profileData.modules.filter((i) => i.role === currentUser.role);
    this.redCrescentProfile = filtered;

    const selectedLocation = Object.keys(locationsKeys).find(
      (location) => locationsKeys[location] === locationKey,
    );
    this.setState({
      currentTransferRequestLocationId: parseInt(selectedLocation),
      userLocationId: parseInt(selectedLocation),
    });
  }

  render() {
    const { pages, locationsKeys, currentTransferRequestLocationId } = this.state;

  
    return (
      <div key={JSON.stringify(locationsKeys)}>
        <Row className={styles.main}>
          <Col span={24}>
            <DelegateContainer
              setDelegateModal={this.setDelegateModal}
              userLocation={this.state.userLocation}
              userLocationId={this.state.userLocationId}
              onChangeTab={this.onChangeTab}
              pages={pages}
              setPages={this.setPages}
              currentTransferRequestLocationId={currentTransferRequestLocationId}
              locationsKeys={locationsKeys}
              labType={this.state.labType}
              access={this.props.access}
              redCrescentProfile={this.state.redCrescentProfile}
              allLocations={this.state.allLocations}
            />

            <Access
              accessible={this.state.userAccess.canAccessRedCrescentDelegateAccess(
                this.state.userLocationId,
              )}
            >
              <DelegateModal
                isVisible={this.state.requestDelegateModal}
                handleCancel={(e) => this.setDelegateModal(e)}
                handleOk={() => {
                  this.setState({ requestDelegateModal: !this.state.requestDelegateModal });

                }}
                redCrescentProfile={this.state.redCrescentProfile}
                labType={this.state.labType}
                currentUser={this.state.currentUser}
              />
            </Access>
          </Col>
        </Row>
      </div>
    );
  }
}

const RedCrescentDelegateWrapper: React.FC<any> = (props) => {
  const { initialState, loading } = useModel('@@initialState');
  const access = useAccess();
  const history = useHistory();

  return loading ? (
    <Spin />
  ) : (
    <RedCrescentDelegate {...props} currentUser={initialState?.currentUser} access={access} />
  );
};

export default RedCrescentDelegateWrapper;

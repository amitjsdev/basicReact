import { message } from 'antd';

import httpService from '@/services/http.service';
import errorHandler from '@/services/errorHandler';
import apiService from '@/shared/services/api.service';
import { LabTypes, ApiUrlFragments } from '@/services/Constants';
import { saveAs } from 'file-saver';
import { formatMessage, getLocale } from 'umi';
import Apis from '@/api/apis';
import moment from 'moment';
export default {
  getInventory: (payload: { locationId: number; page: number; labtype: string }) => {
    const { locationId, page, labtype } = payload;
    const limit = page > 1 ? 100 : 200;
    return httpService
      .get<API.InventoryResponse>(`${ApiUrlFragments.INVENTORY}/inventories/${locationId}`, {
        params: { page: page > 1 ? page + 1 : page, limit, labType: labtype },
      })
      .then((res) => res.results)
      .catch((err) => errorHandler(err));
  },

  getUpdatedInventory: (payload: {
    locationId: number;
    page: number;
    labtype: string;
    filter: {
      status: string;
      classification: string;
      expiry: string;
      category: string;
      active: number;
    };
  }) => {
    const { locationId, page, labtype, filter } = payload;
    const limit = page > 1 ? 100 : 200;
    let params = {
      page: page,
      limit,
      labType: labtype,
    };
    if (filter.status !== 'clear') params[filter.status] = true;
    if (filter.active !== 'clear') params['active'] = filter.active;
    if (filter.classification !== 'All Categories') params.classification = filter.classification;
    if (filter.category !== 'All Categories') params.category = filter.category;
    if (filter.expiry !== 'clear') params.updateFrequency = filter.expiry;
    return httpService
      .get<API.InventoryResponse>(`${ApiUrlFragments.INVENTORY}/inventories/${locationId}`, {
        params,
      })
      .then((res) => res.results)
      .catch((err) => errorHandler(err));
  },

  getFilteredInventory: (payload: {
    locationId: number;
    page: number;
    labtype: string;
    filter: {
      status: string;
      classification: string;
      expiry: string;
      category: string;
      active: number;
    };
  }) => {
    const { locationId, page, filter, labtype } = payload;
    const limit = page > 1 ? 100 : 200;
    const params = {
      page: page > 1 ? page + 1 : page,
      limit,
      labType: labtype,
    };
    if (filter.status !== 'clear') params[filter.status] = true;
    if (filter.active !== 'clear') params['active'] = filter.active;
    if (filter.classification !== 'All Categories') params.classification = filter.classification;
    if (filter.category !== 'All Categories') params.category = filter.category;
    if (filter.expiry !== 'clear') params.updateFrequency = filter.expiry;

    return httpService
      .get<API.InventoryResponse>(`${ApiUrlFragments.INVENTORY}/inventories/${locationId}`, {
        params,
      })
      .then((res) => res.results)
      .catch((err) => errorHandler(err));
  },
  getTransferRequest: ({ locationId, status, outGoing, params, labType }) => {
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/inventories/transactions`, {
        params: { locationId, status, outGoing, labType, ...params },
      })
      .catch((err) => errorHandler(err));
  },
  getIssueRequest: ({ locationId, status, labType }) => {
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/inventories/transactions`, {
        params: { locationId, outGoing: true, labType, forExport: true, status },
      })
      .catch((err) => errorHandler(err));
  },
  getFilteredTransfer: (payload: {
    locationId: number;
    filter: { status: string };
    labType: LabTypes;
  }) => {
    const { locationId, filter, labType } = payload;
    const params = { labType };

    if (filter.status !== 'clear') params[filter.status] = status;

    return httpService
      .get<API.InventoryResponse>(
        `${ApiUrlFragments.INVENTORY}/inventories/transactions/${locationId}`,
        {
          params,
        },
      )
      .then((res) => res.results)
      .catch((err) => errorHandler(err));
  },
  updateTransferRequestStatus: (transferId: number, status: string) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/inventories/transactions/${transferId}`, {
        status,
      })
      .then(() => message.success(formatMessage({ id: 'TransferStatusUpdatedSuccessfully' })));
  },
  getLocations: (labType: LabTypes) => {
    return apiService.getLocationsByLabType(labType);
  },
  changeActiveStatus: (value, record) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/inventories/activate/${record.id}`, { active: value })
      .then(() => message.success(formatMessage({ id: 'InventoryStatusUpdatedSuccessfully' })));
  },
  getPopulatedClassifications: (labType: LabTypes) => {
    return apiService.getProductsByLabType(labType);
  },

  getOrders: (labType, locationId: number, status: App.PurchaseOrderStatus, isApproved = null) => {
    return apiService
      .getOrders(labType, locationId, status, isApproved)
      .then((res: any) => res?.data);
  },
  getRecieving: (labType, locationId: number, status: string) => {
    return apiService.getRecieving(labType, locationId, status).then((res: any) => res?.data);
  },
  createTransferRequest: (data: any, type) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/inventories/transactions`, data)
      .then(() => {
        message.success(formatMessage({ id: 'TranferRequestGeneratedSuccessfully' }));
      });
  },
  createIssue: (data: any, type) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/inventories/export-transactions`, data)
      .then(() => {
        message.success(formatMessage({ id: 'IssueRequestGeneratedSuccessfully' }));
      });
  },

  updateIssueRequestStatus: (transferId: number, status: string) => {
    return httpService
      .put(`${ApiUrlFragments.INVENTORY}/inventories/export-transactions/${transferId}`, status)
      .then(() => message.success(formatMessage({ id: 'TransferStatusUpdatedSuccessfully' })));
  },

  createTransferApproval: (data: any, id) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/inventories/transactions/${id}`, data)
      .then(() => message.success(formatMessage({ id: 'ApprovedSuccessfully' })));
  },
  createIntraWareHouseTransferRequest: (data: any) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/inventories/intra-transactions/batch`, data)
      .then(() => message.success(formatMessage({ id: 'TranferRequestGeneratedSuccessfully' })));
  },
  getTickets: ({ locationId }) => {
    return apiService.getImsTickets(null, locationId);
  },

  getBatches: (skuId: number) => {
    return apiService.getBatches(skuId);
  },
  getWareHouses: (labtype: any, locationId: number) => {
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/locations/warehouses/${labtype}?locationId=${locationId}`)
      .then((data: any) => data.data)
      .catch((err) => errorHandler(err));
  },

  updateBatches: (update: API.UpdateBatchRequest) => {
    return apiService
      .updateBatches(update)
      .then(() => message.success(formatMessage({ id: 'BatchesUpdatedSuccessfully' })));
  },

  updateDailyConsumption: (update: API.UpdateDailyConsumptionRequest) => {
    return apiService
      .updateDailyConsumption(update)
      .then(() => message.success(formatMessage({ id: 'DailyConsumptionUpdatedSuccessfully' })));
  },

  deleteBatch: (batchId: number) => {
    return apiService
      .deleteBatch(batchId)
      .then(() => message.success(formatMessage({ id: 'BatchDeleted' })));
  },

  updateOrder: (orderId: number, data: any) => {
    return apiService
      .updateOrder(orderId, data)
      .then(() => message.success(formatMessage({ id: 'OrderUpdated' })));
  },

  approveOrder: (orderId: number) => {
    return apiService
      .approveOrder(orderId)
      .then(() => message.success(formatMessage({ id: 'OrderApproved' })));
  },

  deleteOrder: (orderId: number) => {
    return apiService
      .deleteOrder(orderId)
      .then(() => message.success(formatMessage({ id: 'OrderDeleted' })));
  },

  closeTicket: (ticketId: number) => {
    return apiService
      .closeImsTicket(ticketId)
      .then(() =>
        message.success(
          formatMessage({ id: 'TicketNo' }) +
            `${ticketId}` +
            formatMessage({ id: 'WasClosedSuccessfully' }),
        ),
      );
  },

  getSurveyFormStatus: (locationId: number) => {
    return apiService
      .getSurveyFormStatus(locationId)
      .then((data: any) => data.message)
      .catch((err) => errorHandler(err));
  },
  submitSurvey: (surveyData: any) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/surveys/bgi-create`, surveyData)
      .then(() => message.success(formatMessage({ id: 'SurveySubmittedSuccessfully' })))
      .catch((err) => errorHandler(err));
  },
  downloadInventory: (locationId: number, locationName: string, labtype: string) => {
    const params = {
      locationId,
    };
    if (getLocale() === 'ar-EG') {
      params.lang = 'arabic';
    }
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/inventories/report/${labtype}`, {
        params,
        responseType: 'arraybuffer',
      })
      .then((res: any) => {
        const blob = new Blob([res], { type: 'text/csv;charset=utf-8' });
        saveAs(blob, `inventory_${locationName}_${moment().format('YYYY-MM-DD')}.xlsx`);
      })
      .catch((err) => errorHandler(err));
  },

  getAutocompleteResults: (searchTerm: string, searchLocation: string, labtype: any) => {
    const params = {
      locationId: searchLocation,
      labType: labtype,
    };
    let searchText = searchTerm.split(' ').join('');

    return httpService
      .get(
        `${ApiUrlFragments.INVENTORY}/auto-complete/purchase-orders/${searchText
          .split('/')
          .join('')}`,
        { params },
      )
      .then((data: any) => data.data)
      .catch((err) => errorHandler(err));
  },

  getAutocompleteResultsTransferHistory: (
    searchTerm: string,
    searchLocation: string,
    labtype: any,
  ) => {
    const params = {
      labType: labtype,
      locationId: searchLocation,
    };
    let searchText = searchTerm.split(' ').join('');

    return httpService
      .get(
        `${ApiUrlFragments.INVENTORY}/auto-complete/transfer-history/${searchText
          .split('/')
          .join('')}`,
        { params },
      )
      .then((data: any) => data.data)
      .catch((err) => errorHandler(err));
  },

  searchItem: (
    regionId: string | undefined,
    searchTerm: string,
    category: string,
    labType: any,
    currentLocation: any,
  ) => {
    if (category === 'GRN') {
      const params = { [category]: searchTerm, locationId: currentLocation, labType: labType };

      return httpService
        .get(`${ApiUrlFragments.INVENTORY}/purchase-order/grn`, { params })
        .then((data: any) => data.data)
        .catch((err) => errorHandler(err));
    } else if (category === 'productCode' || category === 'description') {
      const params = { [category]: searchTerm, locationId: currentLocation, labType: labType };

      return httpService
        .get(`${ApiUrlFragments.INVENTORY}/purchase-order/products`, { params })
        .then((data: any) => data.data)
        .catch((err) => errorHandler(err));
    } else {
      const params = { [category]: searchTerm, location: currentLocation, labType: labType };

      return httpService
        .get(`${ApiUrlFragments.INVENTORY}/purchase-order`, { params })
        .then((data: any) => data.data)
        .catch((err) => errorHandler(err));
    }
  },

  searchItemTransferHistory: (
    searchTerm: string,
    category: string,
    labType: any,
    currentLocation: any,
  ) => {
    const params = { [category]: searchTerm, locationId: currentLocation, labType: labType };

    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/inventories/transfer-history`, { params })
      .then((data: any) => data.data)
      .catch((err) => errorHandler(err));
  },

  downloadPO: (poId: any, locationId: number, labtype: string) => {
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/purchase-order/report/${poId}`, {
        responseType: 'arraybuffer',
      })
      .then((res: any) => {
        const blob = new Blob([res], { type: 'text/csv;charset=utf-8' });
        saveAs(blob, `PurchaseOrder_${poId}_${moment().format('YYYY-MM-DD')}.xlsx`);
      })
      .catch((err) => errorHandler(err));
  },
  getUsersForDelegate: () => {
    return httpService
      .get(`${ApiUrlFragments.USER}/users/store-keeper`)
      .then((data: any) => data)
      .catch((err) => errorHandler(err));
  },

  delegateRequest: (data: any) => {
    return httpService
      .post(`${ApiUrlFragments.USER}/delegation`, data)
      .then(() => message.success(formatMessage({ id: 'CreatedSuccesfully' })))
      .catch((err) => errorHandler(err));
  },
  delegateUpdateRequest: (data: any) => {
    return httpService
      .put(`${ApiUrlFragments.USER}/delegation/${data.id}`, data)
      .then(() => message.success(formatMessage({ id: 'UpdatedSuccesfully' })))
      .catch((err) => errorHandler(err));
  },
  // delegateUpdateRequest: (data: any) => {
  //   return httpService
  //     .put(`${ApiUrlFragments.USER}/classifications`, data)
  //     .then(() => message.success(formatMessage({ id: 'UpdatedSuccesfully' })))
  //     .catch((err) => errorHandler(err));
  // },
  updateBatch: (orderId: any, data: any) => {
    return httpService
      .put(`${ApiUrlFragments.INVENTORY}/purchase-order/grn/${orderId}`, data)
      .then(() => message.success(formatMessage({ id: 'UpdatedSuccesfully' })))
      .catch((err) => errorHandler(err));
  },
  updateMultitpleBatch: (orderId: any, data: any) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/purchase-order/grn/split/${orderId}`, data)
      .then(() => message.success(formatMessage({ id: 'UpdatedSuccesfully' })))
      .catch((err) => errorHandler(err));
  },
  updateBinNumber: (orderId: any, data: any) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/purchase-order/grn/complete/${orderId}`, data)
      .then(() => message.success(formatMessage({ id: 'UpdatedSuccesfully' })))
      .catch((err) => errorHandler(err));
  },

  downloadQrCode: (qrcode: any, fileName?: string, filePdfName?: string) => {
    return httpService
      .get(`${ApiUrlFragments.DOWNLOAD}/${qrcode}`, {
        responseType: 'arraybuffer',
      })
      .then((res: any) => {
        const blob = new Blob([res], { type: 'text/pdf;charset=utf-8' });

        let fileKeyName;
        if (filePdfName == 'pdf') {
          fileKeyName = `${qrcode}.pdf`;
        } else if (fileName) {
          fileKeyName = fileName;
        } else {
          fileKeyName = `${qrcode}.xls`;
        }
        saveAs(blob, fileKeyName);
      })
      .catch((err) => errorHandler(err));
  },
  downloadPDF: (qrcode: any, fileName?: string, onLoad?: string) => {
    return httpService
      .get(`${ApiUrlFragments.DOWNLOAD}/${qrcode}`, {
        responseType: 'arraybuffer',
      })
      .then((res: any) => {
        const blob = new Blob([res], { type: 'text/pdf;charset=utf-8' });
        if (onLoad === 'onLoad') {
          // const blob = new Blob([res], { type: 'text/pdf;charset=utf-8' });
          res;
        } else {
          let fileKeyName;
          if (fileName) {
            fileKeyName = fileName;
          } else {
            fileKeyName = `${qrcode}.pdf`;
          }
          saveAs(blob, fileKeyName);
        }
      })
      .catch((err) => errorHandler(err));
  },

  getSerachData: (searchText: any, labType: any) => {
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/auto-complete/products/${searchText}?labType=${labType}`)
      .then((data: any) => data)
      .catch((err) => errorHandler(err));
  },

  getSelectData: (params: any, currentLocation: any) => {
    return httpService
      .get(
        `${ApiUrlFragments.INVENTORY}/inventories/${currentLocation}?${params.category}=${params.value}`,
      )
      .then((data: any) => data)
      .catch((err) => errorHandler(err));
  },
  getTransferBatche: (fromLocationid: number, productId: number, labType: ANY) => {
    return httpService
      .get<API.BatchesResponse>(
        `${ApiUrlFragments.INVENTORY}/inventories/${fromLocationid}?productId=${productId}&labType=${labType}`,
      )
      .then((response) => response.results.data)
      .catch((err) => errorHandler(err));
  },

  downloadFile: (grnId: any, fileKey: string, fileFormat: any, fileName: any) => {
    if (!fileKey) {
      fileKey = fileName;
    }
    return httpService
      .get(`${ApiUrlFragments.DOWNLOAD}/${fileKey}`, {
        responseType: 'arraybuffer',
      })
      .then((res: any) => {
        const blob = new Blob([res], { type: 'text/pdf;charset=utf-8' });
        if (fileFormat === 'pdf') {
          saveAs(blob, `${grnId}_${moment().format('YYYY-MM-DD')}.pdf`);
        } else if (fileFormat === 'xlsx') {
          saveAs(blob, `${grnId}_${moment().format('YYYY-MM-DD')}.xlsx`);
        } else if (fileName) {
          saveAs(blob, fileName);
        } else {
          saveAs(blob, `${grnId}_${moment().format('YYYY-MM-DD')}.xlsx`);
        }
      })
      .catch((err) => errorHandler(err));
  },

  getUserProfileData: () => {
    return Apis.getProfile();
  },

  addItemRequest: (data: any) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/inventories`, data)
      .then(() => message.success(formatMessage({ id: 'AddedSuccesfully' })))
      .catch((err) => {
        if (err.status === 400) {
          message.error(formatMessage({ id: 'ProductCodeAlreadyExists' }));
        } else {
          message.error(err.data.message);

          // errorHandler(err);
        }
      });
  },

  downloadTranscation: (labtype: string, currentLocation: any, category: any, searchTerm: any) => {
    if (category[category.length - 1] == 's') {
      category = category.substring(0, category.length - 1);
    }
    const params = {
      exportExcel: true,
      labtype,
      [category]: searchTerm,
    };
    // if (getLocale() === 'ar-EG') {
    //   params.lang = 'arabic';
    // }
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/inventories/transfer-history`, {
        params,
        responseType: 'arraybuffer',
      })
      .then((res: any) => {
        const blob = new Blob([res], { type: 'text/csv;charset=utf-8' });
        saveAs(
          blob,
          `transcation_history_${currentLocation}_${moment().format('YYYY-MM-DD')}.xlsx`,
        );
      })
      .catch((err) => errorHandler(err));
  },
  createInspectionApproval: (data: any, id) => {
    return httpService
      .put(`${ApiUrlFragments.INVENTORY}/purchase-order/grn/${id}`, data)
      .then(() => message.success(formatMessage({ id: 'ApprovedSuccessfully' })))
      .catch((err) => errorHandler(err));
  },

  updateLocators: (update: any) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/batches/update-locators`, update)
      .then(() => message.success(formatMessage({ id: 'AddedSuccesfully' })))
      .catch((err) => errorHandler(err));
  },
};

import React from 'react';
import { useAccess, FormattedMessage, getLocale } from 'umi';
import {
  ExclamationCircleTwoTone,
  CheckOutlined,
  InfoOutlined,
  DownloadOutlined,
} from '@ant-design/icons';
import { Table, Button, Typography, Space, Tooltip } from 'antd';
import moment from 'moment';

import DisputeModalV2 from '../Modals/DisputeModalV2';
import ApproveModal from '../Modals/ApproveModal';
import DeleteModal from '../Modals/DeleteModal';
import redcrescentService from '../../services/redcrescent.service';

import './index.css';
import styles from './styles';
import Modal from 'antd/lib/modal/Modal';
import DrilldownDetailTable from '../Modals/Drilldown';
import DisputeModal from '../Modals/DisputeModal';

const { Title, Text } = Typography;

const tableChoice = {
  created: 'columns',
  approved: 'columns1',
  pending: 'columns3',
  quarantined: 'columns1',
  completed: 'columns2',
};

const DATE_FORMAT = 'YYYY-MM-DD';

class PurchaseTable extends React.Component {
  state = {
    inputList: [{ product: '', quantity: '', note: '' }],
    showDisputeModal: false,
    showInspectionModal: false,
    showTransactionModal: false,
    disputeModalData: null,
    transactionModalData: null,
    status: 'created',
    columns: [
      {
        title: <FormattedMessage id="SRCAPONumber" />,
        dataIndex: 'srca',
        key: 'id',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="CreatedBy" />,
        dataIndex: 'createdBy',
        key: 'createdBy',
      },
      {
        title: <FormattedMessage id="CreatedOn" />,
        key: 'createdOn',
        dataIndex: 'createdOn',
        render: (text, record) => {
          return getLocale().includes('en')
            ? moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
            : moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD');
        },
      },
      {
        title: <FormattedMessage id="ExpectedDelivery" />,
        dataIndex: 'expectedOn',
        key: 'expectedOn',
        render: (text, record, index) =>
          this.dateDiff(record.expectedOn) > 0 ? (
            <div>
              <ExclamationCircleTwoTone twoToneColor="#ff0000" />
              <Text>
                {getLocale().includes('en')
                  ? moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')
                  : moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')}
              </Text>
            </div>
          ) : (
            <Text>
              {getLocale().includes('en')
                ? moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')
                : moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')}
            </Text>
          ),
      },
      {
        title: <FormattedMessage id="Actions" />,
        key: 'action',
        render: (text, record, index) => (
          <div style={styles.actions}>
            {/* <Button style={styles.actionButton}>
              <EditTwoTone />
            </Button> */}
            <Space size={12}>
              <DeleteModal
                style={styles.deleteModal}
                inputList={this.state.inputList}
                getOrder={this.props.getOrder}
                index={index}
                record={record}
              />
              <ApproveModal
                style={styles.disputeModal}
                inputList={this.state.inputList}
                index={index}
                record={record}
                getOrder={this.props.getOrder}
                locationId={this.props.locationId}
              />
            </Space>
          </div>
        ),
      },
    ],
    columns1: [
      {
        title: <FormattedMessage id="SRCAPONumber" />,
        dataIndex: 'srca',
        key: 'id',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="CreatedBy" />,
        dataIndex: 'createdBy',
        key: 'createdBy',
      },
      {
        title: <FormattedMessage id="CreatedOn" />,
        key: 'createdOn',
        dataIndex: 'createdOn',
        render: (text, record) => {
          return getLocale().includes('en')
            ? moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
            : moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD');
        },
      },
      {
        title: <FormattedMessage id="ExpectedDelivery" />,
        dataIndex: 'expectedOn',
        key: 'expectedOn',
        render: (text, record, index) =>
          this.dateDiff(record.expectedOn) > 0 ? (
            <div>
              <ExclamationCircleTwoTone twoToneColor="#ff0000" />
              <Text>
                {getLocale().includes('en')
                  ? moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')
                  : moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')}
              </Text>
            </div>
          ) : (
            <Text>
              {getLocale().includes('en')
                ? moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')
                : moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')}
            </Text>
          ),
      },
      {
        title: <FormattedMessage id="Actions" />,
        width: '100px',
        key: 'action',
        render: (text, record, index) => {
          return (
            <Space size={12}>
              <Tooltip title={<FormattedMessage id="CompletePORaiseDispute" />}>
                <Button
                  type="primary"
                  // style={this.props.style}
                  shape="circle"
                  icon={<CheckOutlined />}
                  onClick={(e) => this.disputeModal(record)}
                />
              </Tooltip>
              <Tooltip title={<FormattedMessage id="Info" />}>
                <Button
                  type="primary"
                  shape="circle"
                  icon={<InfoOutlined />}
                  onClick={() => this.transactionModal(record)}
                />
              </Tooltip>
            </Space>
          );
        },
      },
    ],
    columns2: [
      {
        title: <FormattedMessage id="SRCAPONumber" />,
        dataIndex: 'srca',
        key: 'id',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="CreatedBy" />,
        dataIndex: 'createdBy',
        key: 'createdBy',
      },
      {
        title: <FormattedMessage id="CreatedOn" />,
        key: 'createdOn',
        dataIndex: 'createdOn',
        render: (text, record) => {
          return getLocale().includes('en')
            ? moment(text).locale(getLocale()).format('YYYY-MM-DD')
            : moment(text).locale(getLocale()).format('YYYY-MM-DD');
        },
      },
      {
        title: <FormattedMessage id="DeliveredDate" />,
        dataIndex: 'deliveredOn',
        key: 'deliveredOn',
        render: (text, record) => {
          return getLocale().includes('en')
            ? moment(text).locale(getLocale()).format('YYYY-MM-DD')
            : moment(text).locale(getLocale()).format('YYYY-MM-DD');
        },
      },
      {
        title: <FormattedMessage id="Actions" />,
        width: '100px',
        key: 'action',
        render: (text, record, index) => {
          return (
            <Space size={12}>
              <Tooltip title={<FormattedMessage id="Info" />}>
                <Button
                  type="primary"
                  // style={this.props.style}
                  shape="circle"
                  icon={<InfoOutlined />}
                  onClick={(e) => this.transactionModal(record)}
                />
              </Tooltip>
              <Tooltip title={<FormattedMessage id="Download" />}>
                <Button
                  type="primary"
                  shape="circle"
                  icon={<DownloadOutlined />}
                  onClick={(e) => this.download(record)}
                />
              </Tooltip>
            </Space>
          );
        },
      },
    ],
    columns3: [
      {
        title: <FormattedMessage id="SRCAPONumber" />,
        dataIndex: 'srca',
        key: 'id',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="CreatedBy" />,
        dataIndex: 'createdBy',
        key: 'createdBy',
      },
      {
        title: <FormattedMessage id="CreatedOn" />,
        key: 'createdOn',
        dataIndex: 'createdOn',
        render: (text, record) => {
          return getLocale().includes('en')
            ? moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
            : moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD');
        },
      },
      {
        title: <FormattedMessage id="ExpectedDelivery" />,
        dataIndex: 'expectedOn',
        key: 'expectedOn',
        render: (text, record, index) =>
          this.dateDiff(record.expectedOn) > 0 ? (
            <div>
              <ExclamationCircleTwoTone twoToneColor="#ff0000" />
              <Text>
                {getLocale().includes('en')
                  ? moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')
                  : moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')}
              </Text>
            </div>
          ) : (
            <Text>
              {getLocale().includes('en')
                ? moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')
                : moment(record.expectedOn).locale(getLocale()).format('YYYY-MM-DD')}
            </Text>
          ),
      },
      {
        title: <FormattedMessage id="Actions" />,
        width: '100px',
        key: 'action',
        render: (text, record, index) => {
          return (
            <Space size={12}>
              <Tooltip title={<FormattedMessage id="CompletePORaiseDispute" />}>
                <Button
                  type="primary"
                  // style={this.props.style}
                  shape="circle"
                  icon={<CheckOutlined />}
                  onClick={(e) => this.disputeModal(record)}
                />
              </Tooltip>
              <Tooltip title={<FormattedMessage id="Info" />}>
                <Button
                  type="primary"
                  shape="circle"
                  icon={<InfoOutlined />}
                  onClick={() => this.transactionModal(record)}
                />
              </Tooltip>
              {/* <Tooltip title={<FormattedMessage id="Download" />}>
                <Button
                  type="primary"
                  shape="circle"
                  icon={<DownloadOutlined />}
                  onClick={() => this.download(record)}
                />
              </Tooltip> */}
            </Space>
          );
        },
      },
    ],
    data: [
      // {
      //   name: "Stock Order 5",
      //   quantity: 32,
      //   createdBy: "Jon Doe",
      //   createdOn: "30 Aug 2020"
      // }
    ],
    nestedColumns: [
      {
        title: <FormattedMessage id="Code" />,
        width: '200px',
        dataIndex: 'productCode',
        key: 'productCode',
      },
      {
        title: <FormattedMessage id="Description" />,
        width: '200px',
        dataIndex: getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : 'description',
        key: 'description',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        width: '150px',
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="Supplier" />,
        width: '200px',
        dataIndex: 'supplierName',
        key: 'supplierName',
      },
      {
        title: <FormattedMessage id="UpdatedAt" />,
        width: '150px',
        dataIndex: 'updatedAt',
        key: 'updatedAt',
        render: (text, record) =>
          getLocale().includes('en')
            ? moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
      {
        title: <FormattedMessage id="CreatedAt" />,
        width: '150px',
        dataIndex: 'createdAt',
        key: 'createdAt', // moment(batch.manufactureDate).format(dateFormat)
        render: (text, record) =>
          getLocale().includes('en')
            ? moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
    ],

    nestedPendingColumns: [
      {
        title: <FormattedMessage id="Code" />,
        width: '200px',
        dataIndex: 'productCode',
        key: 'productCode',
      },
      {
        title: <FormattedMessage id="Description" />,
        width: '200px',
        dataIndex: getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : 'description',
        key: 'description',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        width: '150px',
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="Supplier" />,
        width: '200px',
        dataIndex: 'supplierName',
        key: 'supplierName',
      },
      {
        title: <FormattedMessage id="PendingQuantity" />,
        width: '150px',
        dataIndex: 'pendingQuantity',
        key: 'pendingQuantity',
      },
      {
        title: <FormattedMessage id="UpdatedAt" />,
        width: '150px',
        dataIndex: 'updatedAt',
        key: 'updatedAt',
        render: (text, record) =>
          getLocale().includes('en')
            ? moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
      {
        title: <FormattedMessage id="CreatedAt" />,
        width: '150px',
        dataIndex: 'createdAt',
        key: 'createdAt', // moment(batch.manufactureDate).format(dateFormat)
        render: (text, record) =>
          getLocale().includes('en')
            ? moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
    ],

    nestedInspectedColumns: [
      {
        title: <FormattedMessage id="Code" />,
        width: '200px',
        dataIndex: 'productCode',
        key: 'productCode',
      },
      {
        title: <FormattedMessage id="Description" />,
        width: '200px',
        dataIndex: getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : 'description',
        key: 'description',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        width: '150px',
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="Supplier" />,
        width: '200px',
        dataIndex: 'supplierName',
        key: 'supplierName',
      },
      {
        title: <FormattedMessage id="PendingQuantity" />,
        width: '150px',
        dataIndex: 'quarantineQuantity',
        key: 'quarantineQuantity',
      },
      {
        title: <FormattedMessage id="UpdatedAt" />,
        width: '150px',
        dataIndex: 'updatedAt',
        key: 'updatedAt',
        render: (text, record) =>
          getLocale().includes('en')
            ? moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
      {
        title: <FormattedMessage id="CreatedAt" />,
        width: '150px',
        dataIndex: 'createdAt',
        key: 'createdAt', // moment(batch.manufactureDate).format(dateFormat)
        render: (text, record) =>
          getLocale().includes('en')
            ? moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
    ],

    expandRowData: [],
    expandedRowKeys: [],
  };

  disputeModal = (values) => {
    if (this.props.status == 'quarantined') {
      this.setState({
        showInspectionModal: true,
        disputeModalData: values,
      });
    } else {
      this.setState({
        showDisputeModal: true,
        disputeModalData: values,
      });
    }
  };

  transactionModal = (values) => {
    this.setState({
      showTransactionModal: true,
      transactionModalData: values.orderItems,
    });
  };

  download = async (values: any) => {
    let filePdfName = 'pdf';
    const content = JSON.parse(values.content);
    await redcrescentService.downloadQrCode(content.fileKey, null, filePdfName);
  };

  componentDidMount() {
    const { data } = this.props;
    this.setState({ inputList: data });
  }

  componentDidUpdate(prevProps) {
    const { data, status, locationId } = this.props;

    if (prevProps.data !== data) {
      const result = data.find((record) => record.id === this.state.expandedRowKeys[0]);
      if (result) {
        this.setState({
          expandableRowData: result,
        });
        this.getExpandableData(this.state.expandedRowKeys[0], result.orderItems);
      }
      this.setState({ inputList: data, locationId });
    }

    if (prevProps.status !== status) {
      if (status === 'created') this.setState({ status });
      // this.changeToCreatedColumns();
      else if (status === 'completed') this.setState({ status }); // this.changeToCompletedColumns();
    }
  }

  changeToCreatedColumns = () => {
    const { columns } = this.state;

    const index = columns.findIndex((x) => x.key === 'deliveredOn');
    columns[index] = {
      title: <FormattedMessage id="ExpectedDeliveryDate" />,
      dataIndex: 'expectedOn',
      key: 'expectedOn',
    };

    this.setState({ columns });
  };

  changeToCompletedColumns = () => {
    const { columns } = this.state;
    const index = columns.findIndex((x) => x.key === 'expectedOn');
    columns[index] = {
      title: <FormattedMessage id="DeliveredDate" />,
      dataIndex: 'deliveredOn',
      key: 'deliveredOn',
    };

    this.setState({ columns });
  };

  async updateStatus(id) {
    const { data, getOrder } = this.props;
    const _data = JSON.parse(JSON.stringify(data));

    const payload = { status: 'completed' };
    await redcrescentService.updateOrder(_data[id].id, payload);
  }

  sideOptions(index) {
    const { status } = this.props;
    const { inputList } = this.state;

    if (status === 'created') {
      return (
        <span>
          <Button style={styles.actionButton}>
            <FormattedMessage id="Edit" />
          </Button>
          <Button style={styles.actionButton}>
            <FormattedMessage id="Delete" />
          </Button>
          <DisputeModalV2
            style={styles.disputeModal}
            inputList={inputList}
            index={index}
            locationId={this.props.locationId}
            status={this.props.status}
          />
        </span>
      );
    }
    return null;
  }

  dateDiff = (_date) => {
    const today = new Date();
    const yday = new Date(_date);
    const _diff = (today.getTime() - yday.getTime()) / (1000 * 3600 * 24);
    return _diff;
  };

  getTable = () => {
    //  this.props.access.canApproveBgiPurchaseOrder() ? this.state.columns.push()

    const { status } = this.props;
    let _column;

    if (status === 'created') {
      _column = this.props.access.canApproveRedCrescentPurchaseOrder()
        ? this.state[tableChoice[status]]
        : this.state[tableChoice[status]].filter((option: any) => {
            return !['action'].includes(option.key);
          });
    } else if (status === 'approved' || status === 'pending' || status === 'quarantined') {
      _column = this.props.access.canInspectRedCrescentPurchaseOrder(this.props.locationId)
        ? this.state[tableChoice[status]]
        : this.state[tableChoice[status]].filter((option: any) => {
            return !['action'].includes(option.key);
          });
    } else {
      _column = this.state[tableChoice[status]];
    }
    //  this.state[tableChoice[status]];
    return _column;
  };

  keys: any[] = [];

  getExpandableData = (recordId, dataItems) => {
    this.keys[0] === recordId ? (this.keys = []) : (this.keys[0] = recordId);
    this.setState({
      expandRowData: [],
      expandedRowKeys: this.keys,
    });
    const data = dataItems;
    this.setState({
      expandRowData: data,
    });
  };

  expandedRowRender = () =>
    this.props.status === 'pending' ? (
      <Table
        columns={this.state.nestedPendingColumns}
        dataSource={this.state.expandRowData}
        pagination={false}
      />
    ) : this.props.status == 'quarantined' ? (
      <Table
        columns={this.state.nestedInspectedColumns}
        dataSource={this.state.expandRowData}
        pagination={false}
      />
    ) : (
      <Table
        columns={this.state.nestedColumns}
        dataSource={this.state.expandRowData}
        pagination={false}
      />
    );

  handleCancel = () => {
    this.setState({
      showDisputeModal: false,
      showInspectionModal: false,
      showTransactionModal: false,
    });
  };

  render() {
    const { columns, columns2 } = this.state;
    const { data, status } = this.props;

    const tableColumn = this.getTable();

    return (
      <div className={styles.container}>
        <div>
          <Table
            columns={tableColumn}
            dataSource={data}
            size="small"
            pagination={{ defaultPageSize: 10 }}
            rowKey={(record) => record.id}
            // rowClassName={(record, index) => (this.dateDiff(record.createdOn) > 7 ? "red" : "black")}

            onExpand={(expanded, record) => this.getExpandableData(record.id, record.orderItems)}
            expandedRowRender={(record) => this.expandedRowRender()}
            expandIconColumnIndex={0}
            expandedRowKeys={this.state.expandedRowKeys}
            expandIconAsCell={false}
          />
          <DisputeModalV2
            style={styles.disputeModal}
            isVisible={this.state.showDisputeModal}
            inputList={this.state.inputList}
            getOrder={this.props.getOrder}
            locationId={this.props.locationId}
            handleCancel={this.handleCancel}
            disputeModalData={this.state.disputeModalData}
            status={status}
          />

          <DisputeModal
            style={styles.disputeModal}
            isVisible={this.state.showInspectionModal}
            inputList={this.state.inputList}
            getOrder={this.props.getOrder}
            locationId={this.props.locationId}
            handleCancel={this.handleCancel}
            disputeModalData={this.state.disputeModalData}
            status={status}
          />
          <Modal
            title={<FormattedMessage id="TransactionHistory" />}
            centered
            visible={this.state.showTransactionModal}
            width={720}
            onOk={this.handleCancel}
            onCancel={this.handleCancel}
            destroyOnClose
            footer={false}
          >
            <DrilldownDetailTable resultSet={this.state.transactionModalData} />
          </Modal>
        </div>
      </div>
    );
  }
}

const PurchaseTableWrapper = (props: any) => <PurchaseTable {...props} access={useAccess()} />;
export default PurchaseTableWrapper;

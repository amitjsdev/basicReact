import React from 'react';
import { Modal, Button, Typography, Tooltip } from 'antd';
import { DeleteOutlined } from '@ant-design/icons';
import redcrescentService from '../../services/redcrescent.service';
import {FormattedMessage} from "umi"

const { Text } = Typography;

class DeleteModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      switchComplete: false,
      orderName: 'DefaultOrder',
      orderNotes: '',
      inputList: [{ product: '', quantity: '', note: '', id: '' }],
      outputList: [{ product: '', quantity: '', note: '', id: '' }],
      orderOptions: [],
    };
  }

  componentDidMount() {
    const { inputList } = this.props;
    this.setState({ inputList });
  }

  componentDidUpdate(prevProps) {
    const { inputList, index } = this.props;

    if (inputList !== prevProps?.inputList) {
      const _data = [];

      inputList[index].orderItems?.forEach((el) => {
        _data.push({ product: el.productCode, quantity: el.quantity, id: el.id });
      });

      this.setState({ inputList: _data });
    }
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleOk = async (e) => {
    const { inputList, index, record } = this.props;

    this.setState({
      visible: false,
    });

    const _data = JSON.parse(JSON.stringify(inputList));
    await redcrescentService.deleteOrder(record.id);
    this.props.getOrder();
  };

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  };

  render() {
    const { visible, orderName, orderOptions } = this.state;
    const { inputList, outputList, switchComplete } = this.state;

    return (
      <>
        <Tooltip title={<FormattedMessage id="Delete"/>}>
          <Button
            type="primary"
            shape="circle"
            icon={<DeleteOutlined />}
            onClick={this.showModal}
          />
        </Tooltip>

        {/* <Button style={this.props.style} onClick={this.showModal}><DeleteTwoTone /></Button> */}
        <Modal
          title={<FormattedMessage id="DeleteOrder"/>}
          visible={visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
          <Text>{<FormattedMessage id="DoYouConfirm"/>}</Text>
          <br />
        </Modal>
      </>
    );
  }
}

export default DeleteModal;

import React from 'react';
import { Table, Button, Space, Tooltip } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import moment from 'moment';
import redcrescentService from '../../services/redcrescent.service';
import { FormattedMessage, getLocale } from 'umi';

const DrilldownDetailTable = ({ resultSet }) => {
  const download = async (values: any) => {
    const content = JSON.parse(values?.content);
    if (content.notarized || content.fileName) {
      await redcrescentService.downloadFile(
        values.id,
        content?.noticeOfTemporaryReceipt,
        null,
        content.fileName,
      );
    }
  };

  const getTablecolumns = [
    {
      title: <FormattedMessage id="Code" />,
      width: '20px',
      dataIndex: 'productCode',
      key: 'productCode',
    },
    {
      title: <FormattedMessage id="Description" />,
      width: '200px',
      dataIndex: getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : 'description',
      key: 'description',
    },
  ];

  const getNestedColumns = [
    {
      title: <FormattedMessage id="GRN" />,
      width: '100px',
      dataIndex: 'id',
      key: 'id',
    },
    {
      title: <FormattedMessage id="ReceivedQuantity" />,
      width: '200px',
      dataIndex: 'receivedQuantity',
      key: 'receivedQuantity',
    },
    {
      title: <FormattedMessage id="UpdatedAt" />,
      width: '100px',
      dataIndex: 'updatedAt',
      key: 'updatedAt',
      render: (text, record) =>
        !getLocale() || getLocale().includes('en')
          ? moment(text).locale(getLocale()).format('YYYY-MM-DD, HH:mm')
          : moment(text).locale(getLocale()).format('YYYY-MM-DD, HH:mm'),
    },
    {
      title: <FormattedMessage id="Actions" />,
      width: '100px',
      key: 'action',
      render: (text, record, index) => {
        return (
          <Space size={12}>
            <Tooltip title={<FormattedMessage id="Download" />}>
              <Button
                type="primary"
                shape="circle"
                icon={<DownloadOutlined />}
                onClick={() => download(record)}
                disabled={record.content == null || record.content == '{}'}
              />
            </Tooltip>
          </Space>
        );
      },
    },
  ];

  const expandedRowRender = (nestedData) => (
    <Table columns={getNestedColumns} dataSource={nestedData} pagination={false} />
  );

  return (
    <Table
      pagination={false}
      columns={getTablecolumns}
      dataSource={resultSet}
      rowKey={(record) => record.id}
      expandedRowRender={(record) => expandedRowRender(record.receivedOrders)}
    />
  );
};

export default DrilldownDetailTable;

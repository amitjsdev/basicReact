import React from 'react';
import { FormattedMessage } from 'umi';
import { Modal, Button, Tooltip } from 'antd';
import { CheckOutlined } from '@ant-design/icons';

import redcrescentService from '../../services/redcrescent.service';

class ApproveModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRecord: props.record,
      visible: false,
      loading: false,
      switchComplete: false,
      orderName: 'DefaultOrder',
      orderNotes: '',
      inputList: [{ product: '', quantity: '', note: '', id: '' }],
      outputList: [{ product: '', quantity: '', note: '', id: '' }],
      orderOptions: [],
    };
  }

  componentDidMount() {
    const { inputList } = this.props;
    this.setState({ inputList });
  }

  componentDidUpdate(prevProps) {
    const { inputList, index, record } = this.props;

    if (inputList !== prevProps.inputList) {
      const _data = [];
      inputList[index].orderItems?.forEach((el) => {
        _data.push({ product: el.productCode, quantity: el.quantity, id: el.id });
      });

      this.setState({ inputList: _data });
    }
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleOk = async (e) => {
    const { inputList, index, record } = this.props;

    this.setState({
      // visible: false,
      loading: true,
    });

    const _data = JSON.parse(JSON.stringify(inputList));
    await redcrescentService.approveOrder(record.id);
    this.setState({
      visible: false,
      loading: false,
    });
    this.props.getOrder();
  };

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  };

  render() {
    const { visible, orderName, orderOptions, loading } = this.state;
    const { inputList, outputList, switchComplete } = this.state;

    return (
      <>
        <Tooltip title={<FormattedMessage id="Approve" />}>
          <Button
            // disabled={this.checkPermission()}
            type="primary"
            style={this.props.style}
            shape="circle"
            icon={<CheckOutlined />}
            onClick={this.showModal}
          />
        </Tooltip>

        {/* <Button disabled={this.checkPermission()} style={this.props.style} onClick={this.showModal}><ProfileTwoTone /></Button> */}
        <Modal
          title={<FormattedMessage id="Order" />}
          visible={visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          maskClosable={false}
          footer={[
            <Button key="back" onClick={this.handleCancel} disabled={loading}>
              <FormattedMessage id="Cancel" />
            </Button>,
            <Button key="submit" type="primary" loading={loading} onClick={this.handleOk}>
              <FormattedMessage id="Submit" />
            </Button>,
          ]}
        >
          {/* <br /> */}
          <span>
            <FormattedMessage id="DoYouApproveTheOrderRequest" />
          </span>

          {/* <Input style={styles.orderNotes} placeholder="Note" onChange={(event) => this.setState({ orderNotes: event.target.value}) } />
           */}
        </Modal>
      </>
    );
  }
}

export default ApproveModal;

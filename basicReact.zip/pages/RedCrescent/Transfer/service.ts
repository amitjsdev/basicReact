import Apis from '@/api/apis';

interface IInventoryParams {
  locationId: number;
  page: number;
}



export async function getLocations() {
  return Apis.getLocations();
}

export async function getBatches(skuId) {
  return Apis.getBatches(skuId);
}

export async function updateBatches(payload, id) {
  return Apis.updateCBBBatches(payload, id);
}

// export async function updateDailyConsumption(data) {
//   return Apis.updateDailyConsumption(data);
// }

export async function getFilteredInventory(payload) {
  const { machine, ...filters } = payload.filter;
  return Apis.filterInventory(payload.locationId, payload.page, {
    ...filters,
    category: machine,
  });
}

export async function getAllMachines() {
  return Apis.getProducts().then((res) => res.results.data);
}

export async function getAllRegions() {
  return Apis.getRegionsByLabType();
}

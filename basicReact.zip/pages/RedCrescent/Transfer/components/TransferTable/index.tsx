import React from 'react';
import { Access, useAccess, FormattedMessage } from 'umi';
import { Table, Space, Tooltip, Button } from 'antd';
import styles from './index.less';
import {
  nestedColumns,
  IncomingColumns,
  OutcomingColumns,
  nestedColumnsCompleted,
} from './columns';
import Modal from '../Modals/Modal';
import { DownloadOutlined, EditOutlined, QrcodeOutlined } from '@ant-design/icons';
import redCrescentService from '../../../services/redcrescent.service';
import EditModal from '../Modals/EditModal';
import ApproveWareHouseModal from '../Modals/ApproveWareHouseModal';
import QrModal from '../Modals/QrModal';

class TransferTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userAccess: this.props.access,
      expandRowData: [],
      expandedRowKeys: [],
      pages: [0, 2],
      editModal: false,
      editData: {},
      inventoryData: [],
      approveModal: false,
      approveData: {},
      approveInventoryData: [],
      approveLocation: '',
      labType: this.props.labType,
      downloadQrData: {},
      showQrModal: false,
      nestedRow: false,
      isLoadingBtn: false,
      currentLoadingId : '',
    };

  }

  approveAction = {
    title: <FormattedMessage id="Actions" />,
    key: 'action',
    render: (text, record, index) => (
      <div className={styles.actionDiv}>
        <Button
          className={styles.editbtn}
          type="primary"
          shape="circle"
          icon={<EditOutlined />}
          onClick={(e) => this.approveWarehouseModal(record)}
        />

        {/* <Button
        type="primary"
        shape="circle"
        icon={<QrcodeOutlined />}
        onClick={(e) => this.openQr(record)}
        // disabled={
        //   this.props.labtype === LabTypes.MRC
        //     ? !(record.batchNumber && record.expiryDate)
        //     : false
        // }
      /> */}
      </div>
    ),
  };
  completeAction = {
    title: <FormattedMessage id="Actions" />,
    key: 'action',
    render: (text, record, index) => (
      <div className={styles.actionDiv}>
        <Button
          type="primary"
          shape="circle"
          icon={<QrcodeOutlined />}
          onClick={(e) => this.openQr(record)}
        // disabled={
        //   this.props.labtype === LabTypes.MRC
        //     ? !(record.batchNumber && record.expiryDate)
        //     : false
        // }
        />
      </div>
    ),
  };

  incomingActionColumn = {
    key: 'action',
    render: (text, record, index) => (
      <>

        <Access
          accessible={this.props.access.canAccessRedCrescentTransferModule(this.props.locationId)}
        >
          <div>
            {/* {record.status === 'approved' && ( */}
            <Space size={12}>
              <Tooltip title={<FormattedMessage id="Download" />}>
                <Button
                  type="primary"
                  shape="circle"
                  icon={<DownloadOutlined />}
                  onClick={(e) => this.downloadfile(record)}
                // disabled={record.content === null || isAllItemEdited}
                />
              </Tooltip>

              <Modal
                disabled={(this.props.redCrescentProfile?.role === 'generalManager' || record.regionManagerApproved == 1)}
                data={record}
                approveManager={'regionManagerApproved'}
                getTransfer={this.props.onChange}
                status={record.regionManagerApproved === 1 ? 'AlreadyApproved' : 'regionManagerApproved'}
              />
              <Modal
                disabled={
                  (this.props.redCrescentProfile?.role === 'generalManager' &&
                    record.regionManagerApproved == 1 && record.generalManagerApproved == 0) ||
                    (this.props.redCrescentProfile?.role === 'superUser' &&
                      record.regionManagerApproved == 1 && record.generalManagerApproved == 0)
                    ? false
                    : true
                }
                data={record}
                approveManager={'generalManagerApproved'}
                getTransfer={this.props.onChange}
                status={record.generalManagerApproved === 1 ? 'AlreadyApproved' : 'generalManagerApproved'}
              />
              <Modal data={record} getTransfer={this.props.onChange} status={'rejected'} />
            </Space>
          </div>
        </Access>
      </>
    ),
  };

  outgoingActionColumn = {
    title: <FormattedMessage id="Actions" />,
    key: 'action',
    render: (text, record, index) => {
      let isAllItemEdited = false;
      (record.items || []).forEach((item) => {
        if (!item.locators || item.locators.length === 0) {
          isAllItemEdited = true;
        }
      });
      return (
        <Access
          accessible={this.props.access.canAccessRedCrescentTransferModule(this.props.locationId)}
        >
          <div>
            <Space size={12}>
              <Tooltip title={<FormattedMessage id="Download" />}>
                <Button
                  type="primary"
                  shape="circle"
                  icon={<DownloadOutlined />}
                  onClick={(e) => this.downloadfile(record)}
                  disabled={record.content === null || isAllItemEdited}
                />
              </Tooltip>
              <Space size={12}>
                <Modal
                  data={record}
                  currentLocation={this.props.locationDetails}
                  productId={record.productId}
                  labType={this.state.labType}
                  getTransfer={this.props.onChange}
                  status={'rejected'}
                />
                <Modal
                  data={record}
                  disabled={isAllItemEdited}
                  onClick={this.checkBatches(
                    this.props.locationDetails,
                    record,
                    this.state.labType,
                  )}
                  currentLocation={this.props.locationDetails}
                  labType={this.state.labType}
                  getTransfer={this.props.onChange}
                  status={'approved'}
                />
              </Space>
            </Space>
          </div>
        </Access>
      );
    },
  };

  nestedOutgoingActions = {
    title: <FormattedMessage id="Actions" />,
    key: 'action',

    render: (text, record, index) => (
      <Access
        accessible={this.props.access.canAccessRedCrescentTransferModule(this.props.locationId)}
      >
        <div>
          <Space size={12}>
            <Tooltip title={<FormattedMessage id="Edit" />}>
              <Button
              loading={this.state.isLoadingBtn && this.state.currentLoadingId == record.productId}
                type="primary"
                shape="circle"
                icon={<EditOutlined />}
                onClick={(e) => this.editButton(record, text, index)}
              />
            </Tooltip>
          </Space>
        </div>
      </Access>
    ),
  };

  nestedOutgoingQrActions = {
    title: <FormattedMessage id="Actions" />,
    key: 'action',

    render: (text, record, index) => (
      <>

        <div className={styles.actionDiv}>
          <Button
            type="primary"
            shape="circle"
            icon={<QrcodeOutlined />}
            onClick={(e) => this.openQrNested(record)}
          // disabled={
          //   this.props.labtype === LabTypes.MRC
          //     ? !(record.batchNumber && record.expiryDate)
          //     : false
          // }
          />
        </div>
      </>
    ),
  };

  keys: any[] = [];

  componentDidUpdate() {
    this.getMoreTransferRequest(0, 1, 1);
  }

  checkBatches = async () => { };

  editButton = async (record, text, index) => {
    this.setState({   editModal: !this.state.editModal,
      isLoadingBtn: true,
      currentLoadingId : record.productId
    })
    const data = await redCrescentService.getTransferBatche(
      record.locationId,
      record.productId,
      this.state.labType,
    );
    let arr = [];
    arr.push(data);
    this.setState({
      // editModal: !this.state.editModal,
      inventoryData: data,
      editData: record,
    });
  };

  approveWarehouseModal = async (record, text, index) => {
    // const data = await redCrescentService.getTransferBatche(this.state.approveLocation,record.productId,this.state.labType);
    // let arr=[]
    // arr.push(data)
    this.setState({
      approveModal: !this.state.approveModal,
      // inventoryData:data,
      approveData: record,
    });
  };

  openQr = (data) => {
    this.setState({
      downloadQrData: data,
      showQrModal: !this.state.showQrModal,
      nestedRow: false,
    });
  };

  openQrNested = (data) => {
    this.setState({
      downloadQrData: data,
      showQrModal: !this.state.showQrModal,
      nestedRow: true,
    });
  };

  getExpandableData = (recordId, dataItems, record) => {

    this.keys[0] === recordId ? (this.keys = []) : (this.keys[0] = recordId);
    this.setState({
      expandRowData: [],
      expandedRowKeys: this.keys,
    });
    const data = record;
    this.setState({
      expandRowData: data,
      approveLocation: data.toLocationId,
    });
  };

  download = async (values: any) => {
    let filePdfName= 'pdf';
    const content = JSON.parse(values.content);
    if (content.requestMaterialsFileKey) {
      await redCrescentService.downloadQrCode(content.requestMaterialsFileKey,null,filePdfName);
    }
  };

  downloadfile = async (values: any) => {

    const content = JSON.parse(values.content);
    if (content.requestMaterialsFileKey) {
      await redCrescentService.downloadFile(values.id, content.requestMaterialsFileKey,null,content.fileName);
    }
  };

  expandedRowRender = () => {
    let columns =
      this.props.activeTab === 'outgoing' && this.props.status === 'created'
        ? [...nestedColumns, this.nestedOutgoingActions]
        : nestedColumns;
    if (this.props.activeTab === 'incoming' && this.props.status === 'completed') {
      columns = [...nestedColumnsCompleted, this.nestedOutgoingQrActions];
    }
    if (this.props.activeTab === 'outgoing' && this.props.status === 'completed') {
      columns = [...nestedColumnsCompleted];
    }
    return (
      <Table columns={columns} dataSource={this.state.expandRowData.items} pagination={false} />
    );
  };

  getMoreTransferRequest = (skip: any, pageNum: any, size: any) => {
    const { pages, data, getMoreTransferRequest } = this.props;
    if (!pages.includes(pageNum)) {
      const addPage = [...pages, pageNum];
      skip = data.length;
      getMoreTransferRequest({
        offset: skip,
        limit: 10,
      });
      this.props.setPages(addPage);
    }
  };

  handleApproval = async (transferDataVal: any, isEditMode: any) => {
    const { selectedOrder } = this.state;
    const { locationDetails } = this.props;

    const items = isEditMode ? transferDataVal.items : transferDataVal.transferData;

    items.map(function (v) {

      delete v.index;
    });
    let data = { status: isEditMode ? 'created' : 'completed', items: items };

    await redCrescentService.createTransferApproval(data, transferDataVal.id).then((response) => {
      this.keys = [];
      this.setState({ expandedRowKeys: [], expandRowData: [] });
      this.props.onChange();
      this.setState({ approveModal: false });
    });

    // history.push(url);
    this.setState({
      editModal: false,
      editData: [],
    });
  };

  render() {
    const { data, status, activeTab } = this.props;
    const columns =
      status === 'completed' && activeTab === 'incoming'
        ? [...IncomingColumns, this.completeAction]
        : status === 'approved' && activeTab === 'incoming'
          ? [...IncomingColumns, this.approveAction]
          : status === 'created' && activeTab === 'incoming'
            ? [...IncomingColumns, this.incomingActionColumn]
            : activeTab === 'incoming'
              ? IncomingColumns
              : status === 'created' && activeTab === 'outgoing'
                ? [...OutcomingColumns, this.outgoingActionColumn]
                : OutcomingColumns;
    return (
      <div>
        <div>
          <Table
            id={`table-element_transfer_${this.props.status}_${this.props.labType}_${this.props.locationDetails.id}`}
            columns={columns}
            dataSource={data}
            size="small"
            rowKey={(record) => record.id}
            pagination={{ pageSize: 10, showSizeChanger: false }}
            onExpand={(expanded, record) => this.getExpandableData(record.id, record.items, record)}
            expandedRowRender={(record) => this.expandedRowRender()}
            expandIconColumnIndex={0}
            expandedRowKeys={this.state.expandedRowKeys}
            expandIconAsCell={false}
            onChange={(e) => {
              this.getMoreTransferRequest(0, +e.current + 1, e.pageSize);
            }}
          />
          <EditModal
            isLoadingBtnCancel={() => {
              this.setState({ isLoadingBtn: false })
            }}
            labType={this.props.labType}
            locationDetails={this.props.locationDetails}
            isVisible={this.state.editModal}
            currentStatus={this.props.status}
            handleOk={(transferData: any) => this.handleApproval(transferData, true)}
            handleCancel={() => {
              this.setState({
                editModal: false,
                editData: [],

              });
            }}
            selectedOrder={this.state.inventoryData}
            editData={this.state.editData}
          />
          <ApproveWareHouseModal
            labType={this.props.labType}
            locationDetails={this.props.locationDetails}
            isVisible={this.state.approveModal}
            currentStatus={this.props.status}
            handleOk={(transferData: any, id: number) => this.handleApproval(transferData, false)}
            handleCancel={() => {
              this.setState({
                approveModal: false,
                approveData: [],
              });
            }}
            selectedOrder={this.state.approveData}
            editData={this.state.approveData}
          />
          <QrModal
            nestedRow={this.state.nestedRoW}
            isVisible={this.state.showQrModal}
            downloadQrData={this.state.downloadQrData}
            handleCancel={() => {
              this.setState({
                showQrModal: false,
              });
            }}
            labtype={this.props.labtype}
          // changeStatus={this.props.changeStatus}
          />
        </div>
      </div>
    );
  }
}

const TransferTableWrapper = (props: any) => <TransferTable {...props} access={useAccess()} />;
export default TransferTableWrapper;

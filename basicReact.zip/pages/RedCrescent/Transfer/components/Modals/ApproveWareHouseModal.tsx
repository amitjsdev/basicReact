import React, { useEffect, useState } from 'react';
import { PlusOutlined, MinusCircleOutlined } from '@ant-design/icons';
import {
  Form,
  Button,
  Row,
  Col,
  Modal,
  Select,
  Input,
  InputNumber,
  Typography,
  message,
  Spin,
  Tabs,
} from 'antd';
import redCrescentService from '../../../services/redcrescent.service';
import styles from './index.less';
import { useIntl, getLocale, formatMessage } from 'umi';
import { text } from 'express';
import { LabTypes } from '@/services/Constants';
import { batch } from 'react-redux';
const { Option } = Select;
const { TabPane } = Tabs;
const BasicApproveForm = (props: any) => {
  const {
    selectedLocation,
    locations,
    labType,
    selectedOrder,
    batchData,
    setdataArr,
    dataArr,
    dataTo,
    setDataTo,
    warehouse,
    toSubWarehouses,
    setTosubWarehouses,
  } = props;
  const [isLoading, setIsLoading] = useState(false);
  const [formSubmit, setFormSubmit] = useState(false);
  const { Text } = Typography;
  const [form] = Form.useForm();

  const onFinish = (values: any) => {
    const toArr = [];
    const valData = [];
    let quantityCheck = false,
      productBatch = '',
      maxQuantity = 0;

    if (dataTo && dataTo.length > 0) {
      let dataCheck = false;
      batchData.map((dataItem, i) => {
        return dataItem.map((item, val) => {
          if (!!item?.batch) {
            valData.push(item?.batch.id);
            let dataToObj = dataTo.filter((data) => data.productId == item?.batch.productId);
            let prdctData = selectedOrder.items.filter(
              (itemVal) => itemVal.productId == item?.batch.productId,
            );

            let quantityProduct = 0;
            dataToObj &&
              dataToObj.length > 0 &&
              dataToObj.map((element) => {
                if (element.batchId == item.batchId) {
                  return (quantityProduct = quantityProduct + element.quantity);
                }
              });

            if (labType === 'nonmedicalredcrescent') {
              let productData = selectedOrder.items.filter(
                (itemVal) => itemVal.productId == item?.productId,
              );
              if (quantityProduct != item?.approvedQuantity) {
                quantityCheck = true;
                productBatch =
                  getLocale() === 'ar-EG'
                    ? productData[0].product.arabicDescription
                    : productData[0].product.description;
                maxQuantity = item?.approvedQuantity;
                return;
              }
            } else {
              if (quantityProduct != item?.approvedQuantity) {
                quantityCheck = true;
                productBatch = item?.batch?.batchNumber;
                maxQuantity = item?.approvedQuantity;
                return;
              }
            }
          } else {
            if (labType === 'nonmedicalredcrescent') {
              valData.push(item?.productId);
              let dataToObj = dataTo.filter((data) => data.productId == item?.productId);

              let quantityProduct = 0;
              dataToObj &&
                dataToObj.length > 0 &&
                dataToObj.map((element) => {
                  if (element.batchId == item.batchId) {
                    return (quantityProduct = quantityProduct + element.quantity);
                  }
                });
              let productData = selectedOrder.items.filter(
                (itemVal) => itemVal.productId == item?.productId,
              );
              if (quantityProduct != item?.approvedQuantity) {
                quantityCheck = true;
                productBatch =
                  getLocale() === 'ar-EG'
                    ? productData[0].product.arabicDescription
                    : productData[0].product.description;
                maxQuantity = item?.approvedQuantity;
                return;
              }
            }
          }
        });
      });
      if (labType === 'medicalredcrescent') {
        dataTo.map((item) => {
          if (!item?.mainWarehouseId) {
            return (dataCheck = true);
          }

          if (!valData.includes(item.batchId)) {
            return (dataCheck = true);
          }
        });
      }

      if (dataCheck) {
        message.error(formatMessage({ id: 'LocatorMustBeRequiredForAllBatches' }));
      } else {
        if (quantityCheck) {
          message.error(
            maxQuantity + ' ' + formatMessage({ id: 'QuantityRequiredIn' }) + ' ' + productBatch,
          );

          // }
        } else {
          var location = (locations || []).find((loc) => loc.id === selectedLocation);
          let dataCheck = false;
          if (dataCheck) {
            message.error(formatMessage({ id: 'QuantityIsMoreThanBatchQuantity' }));
          } else {
            let payload = { transferData: dataTo, id: selectedOrder.id };

            props.handleOk(payload);
            setFormSubmit(true);
            setDataTo([]);
          }
        }
      }
    } else {
      message.error(formatMessage({ id: 'LocatorMustBeRequiredForAllBatches' }));
    }
  };

  const onCancel = () => {
    props.handleCancel();
    form.resetFields();
    setdataArr([]);
    setDataTo([]);
  };

  const handleChange = (value, index, type, bactchData) => {
    let arr = [];
    let finalType = type;
    if (type.includes('to')) {
      finalType = finalType.replace('to', '');
    }
    arr = [...dataTo];
    let indexData = arr.findIndex((x) => x.index == index);

    let obj = {};
    if (indexData > -1) {
      obj = { ...arr[indexData] };
    } else {
      obj.index = index;
    }

    if (type === 'quantity' && labType === 'nonmedicalredcrescent') {
      let batchVal = bactchData.split('-');
      obj = {
        ...obj,
        batchId: parseInt(batchVal[0]),
        productId: parseInt(batchVal[1]),
      };
    }
    if (type === 'quantity' && labType === 'medicalredcrescent') {
      let batchVal = bactchData.split('-');
      obj = {
        ...obj,
        batchId: parseInt(batchVal[0]),
        productId: parseInt(batchVal[1]),
      };
      obj[finalType] = value;
      //   arr.push(obj);

      // setDataTo(arr);
    } else {
      obj[finalType] = value;
    }

    if (indexData > -1) {
      arr[indexData] = obj;
    } else {
      arr.push(obj);
    }
    if (type === 'tomainWarehouseId') {
      if (arr[indexData] && arr[indexData].subWarehouseId) {
        delete arr[indexData].subWarehouseId;
      }
      let indexSub = toSubWarehouses.findIndex((subhouse) => subhouse.index == index);
      let sub = warehouse && warehouse.length > 0 && warehouse.find((item) => item.id == value);
      if (sub.subWarehouses && sub.subWarehouses.length > 0) {
        if (indexSub == -1) {
          setTosubWarehouses([...toSubWarehouses, { index, value: sub.subWarehouses }]);
        } else {
          toSubWarehouses[indexSub] = { index, value: sub.subWarehouses };
        }
      } else {
        if (indexSub !== -1) {
          toSubWarehouses.splice(indexSub, 1);
        }
      }
    }
    // if (type.includes('to')) {
    //   setDataTo(arr);
    // }
    setDataTo(arr);
  };

  return (
    <>
      <Spin className={styles.loader} spinning={isLoading} size="large" />
      <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
        <div style={{ marginTop: '5px' }}>
          <Tabs type="card">
            {selectedOrder.items.map((dataVal, index) => {
              const obj =
                dataArr &&
                dataArr.length > 0 &&
                dataArr.find((item) => item.id.productId == dataVal.productId);

              return (
                <>

                  <TabPane
                    tab={
                      getLocale() === 'ar-EG'
                        ? dataVal.product.arabicDescription
                        : dataVal.product.description
                    }
                    key={index}
                  >
                    <div>
                      {obj && obj.id &&
                        <Text className={styles.textMark} >
                          {useIntl().formatMessage({ id: `ApprovedQuantity` })} {obj.id.approvedQuantity}
                        </Text>}
                      <Row gutter={[12, 12]} align="middle">
                        <Col span={12}>
                          <Form.Item
                            label={formatMessage({
                              id: 'Product',
                            })}
                          >
                            <Input
                              name="product"
                              value={
                                getLocale() === 'ar-EG'
                                  ? dataVal.product.arabicDescription
                                  : dataVal.product.description
                              }
                            />
                          </Form.Item>
                        </Col>
                        <Col span={12}>
                          <Form.Item
                            label={formatMessage({
                              id: 'Code',
                            })}
                          >
                            <Input
                              name="code"
                              value={
                                getLocale() === 'ar-EG'
                                  ? dataVal.product.code
                                  : dataVal.product.code
                              }
                            />
                          </Form.Item>
                        </Col>
                      </Row>
                      {labType === 'medicalredcrescent' &&
                        dataVal &&
                        dataVal.locators &&
                        dataVal.locators.length > 0 &&
                        dataVal.locators.map((locData, locatorIndex) => {
                          if (locData.batch) {
                            return (
                              <>
                                <Row gutter={[12, 12]} align="middle">
                                  <Col span={12}>
                                    <Form.Item
                                      label={formatMessage({
                                        id: 'BatchNumber',
                                      })}
                                    >
                                      <Input
                                        name="batchNumber"
                                        value={locData.batch?.batchNumber}
                                      />
                                    </Form.Item>
                                  </Col>
                                </Row>
                                <div>
                                  {obj &&
                                    obj.id &&
                                    obj.id.locators.length > 0 &&
                                    obj.dataLength.map((itemData, indexObj) => {
                                      if (itemData.currentBatch === locData?.batch?.batchNumber) {
                                        return (
                                          <>
                                            <Row gutter={[24, 24]} align="middle">
                                              <Col span={20}>
                                                <Form.Item
                                                  label="To WareHouse"
                                                  name={`ToWareHouse${index}${indexObj}`}
                                                  rules={[
                                                    {
                                                      required: true,
                                                      message: 'Missing WareHouse',
                                                    },
                                                  ]}
                                                >
                                                  <Select
                                                    onChange={(value) => {
                                                      handleChange(
                                                        value,
                                                        `${index}${indexObj}${locatorIndex}`,
                                                        'tomainWarehouseId',
                                                      );
                                                    }}
                                                  >
                                                    {warehouse &&
                                                      warehouse.length > 0 &&
                                                      warehouse.map((house) => {
                                                        return (
                                                          <Option value={house.id}>
                                                            {house.name}
                                                          </Option>
                                                        );
                                                      })}
                                                  </Select>
                                                </Form.Item>
                                              </Col>
                                              {dataTo.length > 0 &&
                                                toSubWarehouses.length > 0 &&
                                                dataTo.find(
                                                  (x) => x.index == `${index}` && x.mainWarehouseId,
                                                ) &&
                                                toSubWarehouses.find(
                                                  (item) => item.index == `${index}`,
                                                ) && (
                                                  <Col span={20}>
                                                    <Form.Item
                                                      label="To SubWareHouse"
                                                      name={`ToSubWareHouse${index}${indexObj}`}
                                                      rules={[
                                                        {
                                                          required: true,
                                                          message: 'Missing SubWareHouse',
                                                        },
                                                      ]}
                                                    >
                                                      <Select
                                                        onChange={(value) => {
                                                          handleChange(
                                                            value,
                                                            `${index}${indexObj}${locatorIndex}`,
                                                            'tosubWarehouseId',
                                                          );
                                                        }}
                                                      >
                                                        {toSubWarehouses &&
                                                          toSubWarehouses.length > 0 &&
                                                          toSubWarehouses.map((house) => {
                                                            if (house.index == `${index}`) {
                                                              return house.value.map((item) => {
                                                                return (
                                                                  <Option value={item.id}>
                                                                    {item.name}
                                                                  </Option>
                                                                );
                                                              });
                                                            }
                                                          })}
                                                      </Select>
                                                    </Form.Item>
                                                  </Col>
                                                )}
                                            </Row>
                                            <Row gutter={[12, 12]} align="middle">
                                              <Col span={10}>
                                                <Form.Item
                                                  label="To LocatorID"
                                                  name={`locatorId${index}${indexObj}`}
                                                  rules={[
                                                    {
                                                      required: true,
                                                      message: 'Missing To LocatorID',
                                                    },
                                                  ]}
                                                >
                                                  <Input
                                                    style={{ width: '100%' }}
                                                    onChange={(value) => {
                                                      handleChange(
                                                        value.target.value,
                                                        `${index}${indexObj}${locatorIndex}`,
                                                        'tolocatorId',
                                                      );
                                                    }}
                                                  />
                                                </Form.Item>
                                              </Col>

                                              <Col span={10}>
                                                <Form.Item
                                                  // {...restField}
                                                  label="Quantity"
                                                  name={`quantity${index}${indexObj}`}
                                                  rules={[
                                                    {
                                                      required: true,
                                                      message: formatMessage({
                                                        id: 'MissingQuantity',
                                                      }),
                                                    },
                                                    {
                                                      type: 'number',
                                                      min: 1,
                                                    },
                                                  ]}
                                                >
                                                  <InputNumber
                                                    placeholder={formatMessage({
                                                      id: 'Quantity',
                                                    })}
                                                    precision={0}
                                                    style={{ width: '100%' }}
                                                    onChange={(value) => {
                                                      handleChange(
                                                        value,
                                                        `${index}${indexObj}${locatorIndex}`,
                                                        'quantity',
                                                        locData.batch.id +
                                                        '-' +
                                                        locData.batch.productId,
                                                      );
                                                    }}
                                                  />
                                                </Form.Item>
                                              </Col>
                                            </Row>
                                          </>
                                        );
                                      }
                                    })}
                                  <Form.Item name={index}>
                                    <Row>
                                      <Col span={24}>
                                        <Button
                                          type="dashed"
                                          onClick={() => {
                                            // add(locData.batch.id)
                                            let batchVal = locData?.batch.batchNumber;
                                            const indexData = dataArr.findIndex((item) =>
                                              item.id?.locators.find(
                                                (locator) =>
                                                  locator?.batch?.batchNumber == batchVal,
                                              ),
                                            );
                                            let arr = [...dataArr];
                                            let objData = { ...obj };
                                            objData.dataLength.push({ currentBatch: batchVal });
                                            arr[indexData] = objData;
                                            setdataArr(arr);
                                          }}
                                          block
                                          icon={<PlusOutlined />}
                                        >
                                          Add Locator
                                        </Button>
                                      </Col>
                                    </Row>
                                  </Form.Item>
                                </div>
                              </>
                            );
                          }
                        })}
                    </div>
                    {labType === 'nonmedicalredcrescent' && (
                      <div>
                        {obj &&
                          obj.id &&
                          obj.id.productId == dataVal.productId &&
                          obj.dataLength.map((itemData, indexObj) => {
                            // if (itemData.currentBatch === locData?.batch?.batchNumber) {
                            return (
                              <>
                                <Row gutter={[24, 24]} align="middle">
                                  <Col span={20}>
                                    <Form.Item
                                      label="To WareHouse"
                                      name={`ToWareHouse${index}${indexObj}`}
                                      rules={[
                                        {
                                          required: true,
                                          message: 'Missing WareHouse',
                                        },
                                      ]}
                                    >
                                      <Select
                                        onChange={(value) => {
                                          handleChange(
                                            value,
                                            `${index}${indexObj}`,
                                            'tomainWarehouseId',
                                          );
                                        }}
                                      >
                                        {warehouse &&
                                          warehouse.length > 0 &&
                                          warehouse.map((house) => {
                                            return <Option value={house.id}>{house.name}</Option>;
                                          })}
                                      </Select>
                                    </Form.Item>
                                  </Col>
                                  {dataTo.length > 0 &&
                                    toSubWarehouses.length > 0 &&
                                    dataTo.find(
                                      (x) => x.index == `${index}` && x.mainWarehouseId,
                                    ) &&
                                    toSubWarehouses.find((item) => item.index == `${index}`) && (
                                      <Col span={20}>
                                        <Form.Item
                                          label="To SubWareHouse"
                                          name={`ToSubWareHouse${index}${indexObj}`}
                                          rules={[
                                            {
                                              required: true,
                                              message: 'Missing SubWareHouse',
                                            },
                                          ]}
                                        >
                                          <Select
                                            onChange={(value) => {
                                              handleChange(
                                                value,
                                                `${index}${indexObj}`,
                                                'tosubWarehouseId',
                                              );
                                            }}
                                          >
                                            {toSubWarehouses &&
                                              toSubWarehouses.length > 0 &&
                                              toSubWarehouses.map((house) => {
                                                if (house.index == `${index}`) {
                                                  return house.value.map((item) => {
                                                    return (
                                                      <Option value={item.id}>{item.name}</Option>
                                                    );
                                                  });
                                                }
                                              })}
                                          </Select>
                                        </Form.Item>
                                      </Col>
                                    )}
                                </Row>
                                <Row gutter={[12, 12]} align="middle">
                                  <Col span={10}>
                                    <Form.Item
                                      label="To LocatorID"
                                      name={`locatorId${index}${indexObj}`}
                                      rules={[
                                        {
                                          required: true,
                                          message: 'Missing To LocatorID',
                                        },
                                      ]}
                                    >
                                      <Input
                                        style={{ width: '100%' }}
                                        onChange={(value) => {
                                          handleChange(
                                            value.target.value,
                                            `${index}${indexObj}`,
                                            'tolocatorId',
                                          );
                                        }}
                                      />
                                    </Form.Item>
                                  </Col>

                                  <Col span={10}>
                                    <Form.Item
                                      // {...restField}
                                      label="Quantity"
                                      name={`quantity${index}${indexObj}`}
                                      rules={[
                                        {
                                          required: true,
                                          message: formatMessage({
                                            id: 'MissingQuantity',
                                          }),
                                        },
                                        {
                                          type: 'number',
                                          min: 1,
                                        },
                                      ]}
                                    >
                                      <InputNumber
                                        placeholder={formatMessage({
                                          id: 'Quantity',
                                        })}
                                        precision={0}
                                        style={{ width: '100%' }}
                                        onChange={(value) => {
                                          handleChange(
                                            value,
                                            `${index}${indexObj}`,
                                            'quantity',
                                            obj.id.locators[0].batchId + '-' + dataVal.productId,
                                          );
                                        }}
                                      />
                                    </Form.Item>
                                  </Col>
                                </Row>
                              </>
                            );
                            // }
                          })}
                        <Form.Item name={index}>
                          <Row>
                            <Col span={24}>
                              <Button
                                type="dashed"
                                onClick={() => {
                                  // add(locData.batch.id)
                                  let dataValArr = [];
                                  let batchVal = dataVal?.productId;
                                  const indexData = dataArr.findIndex((item) => {
                                    dataValArr.push(item.id);
                                    dataValArr.find((locator) => locator?.productId == batchVal);
                                  });
                                  let arr = [...dataArr];
                                  let objData = { ...obj };
                                  objData.dataLength.push({ currentBatch: batchVal });
                                  arr[indexData] = objData;
                                  setdataArr(arr);
                                }}
                                block
                                icon={<PlusOutlined />}
                              >
                                Add Locator
                              </Button>
                            </Col>
                          </Row>
                        </Form.Item>
                      </div>
                    )}
                  </TabPane>
                </>
              );
            })}
          </Tabs>
        </div>

        <Row gutter={[24, 24]}>
          <Col flex={1} span={12}>
            <Form.Item>
              <Button disabled={formSubmit} type="primary" htmlType="submit" block>
                {useIntl().formatMessage({ id: 'Apply' })}
              </Button>
            </Form.Item>
          </Col>
          <Col flex={1} span={12}>
            <Form.Item>
              <Button onClick={onCancel} block>
                {useIntl().formatMessage({ id: 'Cancel' })}
              </Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </>
  );
};

const ApproveWareHouseModal = (props: any) => {
  const {
    currentStatus,
    handleOk,
    handleCancel,
    isVisible,
    locationDetails,
    labType,
    selectedOrder,
  } = props;

  const [selectedLocation, setSelectedLocation] = useState('');
  const [locations, setLocations] = useState([]);
  const [dataArr, setdataArr] = useState([]);
  const [dataFrom, setDataFrom] = useState([]);
  const [dataTo, setDataTo] = useState([]);
  const locDropdown: [] = [];
  const [warehouse, setWarehouse] = useState([]);
  const [batchData, setBatchData] = useState([]);
  const [toSubWarehouses, setTosubWarehouses] = useState([]);
  const [fromSubWarehouses, setFromsubWarehouses] = useState([]);

  useEffect(() => {
    if (isVisible) {
      redCrescentService.getLocations('medicalredcrescent').then((locations: any) => {
        locations.map((lab: any) => {
          locDropdown.push(lab);
        });
        setLocations(locDropdown);
      });
    }
    async function fetchMyAPI(selectedOrder) {
      let arr = [];
      let batchArr = [];
      if (selectedOrder && selectedOrder.items && selectedOrder?.items?.length > 0) {
        const arrayData = [];
        for (let i = 0; i < selectedOrder?.items?.length; i++) {
          let obj = { id: selectedOrder.items[i], dataLength: [[]] };
          arr.push(obj);
          batchArr.push(selectedOrder.items[i].locators);
        }
        setdataArr(arr);
        setBatchData(batchArr);
      }
    }
    fetchMyAPI(selectedOrder);
    // var labtype = window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC;
    if (isVisible) {
      redCrescentService.getWareHouses('medicalredcrescent', locationDetails.id).then((data) => {
        let d = data.filter((item) => item.locationId == props.locationDetails.id);
        setWarehouse(d);
      });
    }
  }, [selectedOrder, isVisible]);
  return (
    <>
      <Modal
        width="50%"
        title={useIntl().formatMessage({ id: 'ApproveToWareHouse' })}
        visible={isVisible}
        afterClose={() => handleCancel()}
        destroyOnClose
        closable={false}
        footer={false}
      >
        <BasicApproveForm
          batchData={batchData}
          toSubWarehouses={toSubWarehouses}
          fromSubWarehouses={fromSubWarehouses}
          setFromsubWarehouses={setFromsubWarehouses}
          setTosubWarehouses={setTosubWarehouses}
          setdataArr={setdataArr}
          dataArr={dataArr}
          setDataFrom={setDataFrom}
          dataFrom={dataFrom}
          dataTo={dataTo}
          setDataTo={setDataTo}
          warehouse={warehouse}
          setWarehouse={setWarehouse}
          currentStatus={currentStatus}
          labType={labType}
          selectedLocation={selectedLocation}
          setSelectedLocation={setSelectedLocation}
          locations={locations}
          locationDetails={locationDetails}
          handleOk={(updatedBatches: any) => handleOk(updatedBatches)}
          handleCancel={() => {
            handleCancel();
            setSelectedLocation('');
            setdataArr([]);
            setDataTo([]);
            setDataFrom([]);
            setTosubWarehouses([]);
            setFromsubWarehouses([]);
          }}
          selectedOrder={selectedOrder}
        />
      </Modal>
    </>
  );
};

export default ApproveWareHouseModal;

import React from 'react';
import { Modal, Form, Row, Col, Button } from 'antd';
import { useIntl } from 'umi';
import QRCode from 'qrcode.react';
import redcrescentService from '../../../services/redcrescent.service';
import { LabTypes, RecivingStatues } from '@/services/Constants';

const QrModal: React.FC<any> = (props) => {
  const { downloadQrData, isVisible, labtype, nestedRoW } = props;
  const handleCancel = () => {
    props.handleCancel();
  };



  // const downloadQR = () => {
  //   const canvas = document.getElementById('123456');
  //   const pngUrl = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
  //   let downloadLink = document.createElement('a');
  //   downloadLink.href = pngUrl;
  //   downloadLink.download = '123456.png';
  //   document.body.appendChild(downloadLink);
  //   downloadLink.click();
  //   document.body.removeChild(downloadLink);
  // };

  const downloadQR = async () => {
    const array = [];
    if (downloadQrData.items && downloadQrData.items.length > 0) {
      downloadQrData.items.forEach(item => {
        if (item.locators && item.locators.length > 0) {
          item.locators.forEach(locator => {
            array.push(JSON.parse(locator.content))
          })
        }
      })
    } else {
      if (downloadQrData.locators && downloadQrData.locators.length > 0) {
        downloadQrData.locators.forEach(locator => {
          array.push(JSON.parse(locator.content))
        })
      }
    }

    const allPromises = [];
    let filePdfName= 'pdf';
    const getPromise = (content) => redcrescentService.downloadQrCode(
      content.fileKey,null,filePdfName
    );

    array.forEach((item) => {
      allPromises.push(getPromise(item))
    })

    await Promise.all(array)

    // if(nestedRoW){
    //   const content=JSON.parse(downloadQrData.content)
    //   await redcrescentService.downloadQrCode(
    //     content.fileKey
    //   );
    // }else{
    //   const content=JSON.parse(downloadQrData.content)
    //   await redcrescentService.downloadQrCode(
    //     content.requestMaterialsFileKey
    //   );

    // }

  }
  // let obj = {};
  // if (Object.keys(downloadQrData).length > 0) {
  //   obj = { p: downloadQrData.product.code,l:downloadQrData.locationId };
  //   if (labtype === LabTypes.MRC) {
  //     obj.b = downloadQrData.batchNumber;
  //   }
  // }
  const moveToInspection = async () => {
    await redcrescentService.updateBatch(downloadQrData.id, { status: 'quarantined' });
    //  props.changeStatus({ status: RecivingStatues.INSPECTION, isApproved: true })
    //  props.handleCancel();
  };
  return (
    <Modal
      title={useIntl().formatMessage({ id: 'DownloadQR' })}
      visible={isVisible}
      footer={null}
      afterClose={handleCancel}
      closable={false}
      destroyOnClose
    >
      <Form>
        <Row gutter={[24, 24]} align="middle">
          <Col span={24}>
            <QRCode
              id="123456"
              value={`${downloadQrData.qrcode}`}
              size={290}
              level={'H'}
              includeMargin={true}
            />{' '}
          </Col>
        </Row>
        <Row gutter={[24, 24]}>
          <Col flex={1}>
            <Form.Item>
              <Button type="primary" onClick={downloadQR}>
                {useIntl().formatMessage({ id: 'Download' })}
              </Button>
            </Form.Item>
          </Col>
          {/* <Col flex={1}>
            <Form.Item>
              <Button type="primary" onClick={moveToInspection}>
                {useIntl().formatMessage({ id: 'MoveToCompleted' })}
              </Button>
            </Form.Item>
          </Col> */}
          <Col flex={1}>
            <Form.Item>
              <Button onClick={handleCancel}>{useIntl().formatMessage({ id: 'Cancel' })}</Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </Modal>
  );
};

export default QrModal;

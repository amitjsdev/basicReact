import React, { useEffect, useState } from 'react';
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import {
  Form,
  Button,
  Row,
  Col,
  Modal,
  Select,
  Input,
  InputNumber,
  Tooltip,
  message,
  Spin,
  Radio,
  Divider,
  Space,
} from 'antd';
import redCrescentService from '../../../services/redcrescent.service';
import styles from './index.less';
import { useIntl, getLocale, formatMessage } from 'umi';
import { text } from 'express';
import { LabTypes } from '@/services/Constants';
const { Option } = Select;

const BasicEditForm = (props: any) => {
  const {
    selectedLocation,
    setSelectedLocation,
    locations,
    locationDetails,
    locationName,
    quantity,
    labType,
    selectedOrder,
    batchData,
    setdataArr,
    dataArr,
    dataValues,
    setDataValues,
    setData,
    warehouse,
    subWarehouses,
    setsubWarehouses,
    type,
    editData,
  } = props;
  const [isLoading, setIsLoading] = useState(false);
  const [batchId, setBatchId] = useState(null);
  const [formSubmit, setFormSubmit] = useState(false);
  const [finalData, setFinalData] = useState([]);
  const [batchQty, setBatchQty] = useState(null);
  const [fieldsOpen, setFieldsOpen] = useState<boolean>(false);
  const [inputFieldValues, setInputFieldValues] = useState({});
  const [maxValue, setMaxValue] = useState(editData.quantity);
  const [enable, setEnable] = useState(false);
  const [selectedBatchNumber, setSelectedBatchNumber] = useState([]);
  const [batchLocators, setLocators] = useState([]);

  let tableData = [];

  const [form] = Form.useForm();

  const onFinish = (values: any) => {
    let dataArray = [];
    const obj = finalData.map((ele) => {
      return {
        transactionItemId: editData.id,
        locationId: editData.locationId,
        labType: editData.labType,
        locationName: editData.locationName,
        locationCode: editData.locationCode,
        quantity: editData.quantity,
        approvedQuantity: ele.approvedQuantity,
        inventoryId: editData.inventoryId,
        productId: editData.productId,
        batchId: ele.batchId,
        mainWarehouseId: ele.mainWarehouseId,
        subWarehouseId: ele.subWarehouseId,
        locatorId: ele.locatorId,
      };
    });

    setFinalData(obj);
    dataArray = obj;

    if (dataArray && dataArray.length > 0) {
      const dataObj = [...dataArray];

      let dataCheck = false;
      let total = 0;
      let isSameWareshouse = false;

      const valueArr = dataObj.map(function (item) {
        return `${item.batchId}${item.mainWarehouseId}${item.subWarehouseId}${item.locatorId}`;
      });
      const isDuplicate = valueArr.some(function (item, idx) {
        return valueArr.indexOf(item) != idx;
      });
      if (isDuplicate) {
        message.error('Can not select same batch and locators multiple times.');
        return;
      }
      let isMoreThanBatchQuantity = false;
      let quantityCheck = false;
      if (labType === 'nonmedicalredcrescent') {
        let total = 0;
        finalData.map((data) => {
          // const index = batchLocators.findIndex((loc) => (loc.mainWarehouseId == parseInt(data.mainWarehouseId) &&
          //   loc.locatorId == parseInt(data.locatorId)));
          //
          // if (batchLocators[index].quantity < data.approvedQuantity) {
          //

          //   message.error(
          //     batchLocators[index].quantity + ' ' + formatMessage({ id: 'QuantityAvailableIn' }) + ' ' + batchLocators[index].mainWarehouseName
          //     + ' ' + (batchLocators[index].subWarehouseId != null ? batchLocators[index].subWarehouseName : '') + ' ' + batchLocators[index].locatorId  ,
          //   );
          //   quantityCheck = true;
          //   return;
          // }
          total += data.approvedQuantity;
        });
        if (total > editData.quantity) {
          message.error(editData.quantity + formatMessage({ id: 'QuantityAvailable' }));
          return;
        }
      }
      batchData &&
        batchData.length > 0 &&
        batchData.map((batch) => {
          let dataFind = dataArray.filter((dataItem) => dataItem.batchId == batch.id);
          const particularLocators = batch && batch.locators;

          if (dataFind && dataFind.length > 0) {
            for (var i = 0; i < dataFind.length; i++) {
              const index =
                particularLocators &&
                particularLocators.findIndex(
                  (loc) =>
                    loc.mainWarehouseId == dataFind[i].mainWarehouseId &&
                    loc.locatorId == dataFind[i].locatorId,
                );
              if (dataFind[i].approvedQuantity > particularLocators[index].quantity) {
                isMoreThanBatchQuantity = true;
                message.error(
                  particularLocators[index].quantity +
                    ' ' +
                    formatMessage({ id: 'QuantityAvailableIn' }) +
                    ' ' +
                    particularLocators[index].mainWarehouseName +
                    ' ' +
                    (particularLocators[index].subWarehouseId != null
                      ? particularLocators[index].subWarehouseName
                      : '') +
                    ' ' +
                    particularLocators[index].locatorId,
                );
              }

              total += dataFind[i].approvedQuantity;
              return;
            }
            if (total > batch.quantity) {
              isMoreThanBatchQuantity = true;
            }

            if (total > editData.quantity) {
              return (dataCheck = true);
            }
          }
        });
      if (isMoreThanBatchQuantity) {
        // message.error(formatMessage({ id: 'QuantityIsMoreThanBatchQuantity' }));
        return;
      }
      if (dataCheck) {
        message.error(formatMessage({ id: 'QuantityIsMoreThanRequestedQuantity' }));
        return;
      } else {
        const quantityCheck = dataArray.find(
          (item) => isNaN(item.approvedQuantity) || item.approvedQuantity <= 0,
        );
        if (quantityCheck) {
          message.error(formatMessage({ id: 'QuantityShouldBeNumericAndGreaterThan0' }));
        } else {
          if (dataArray.find((item) => item.approvedQuantity <= editData.quantity)) {
            const payload = {
              status: 'created',
              items: dataObj,
              id: editData.transactionId,
            };
            if (type === 'Transfer') {
              var location = (locations || []).find((loc) => loc.id === selectedLocation);
              payload.location = location;
              payload.labType = labType;
            }

            props.handleOk(payload);

            setIsLoading(true);
            setFormSubmit(true);
            setSelectedBatchNumber([]);
            setLocators([]);
            setData([]);
            setFinalData([]);
          } else {
            message.error(formatMessage({ id: 'CannotBeMoreThan' + ' ' + editData.quantity }));
          }
        }
      }
      // }
    } else {
      let wareHouseCheck = false;
      for (let i = 0; i < dataArray.length; i++) {
        if (dataArray[i]?.mainWarehouseId) {
        } else {
          wareHouseCheck = true;
        }
      }
      if (wareHouseCheck) {
        message.error(formatMessage({ id: 'MissingWareHouse' }));
        // } else if (approvedQuantity == 0) {
        //   message.error(formatMessage({ id: 'PleaseEnterQuantity' }));
        // } else {
        //   message.error(formatMessage({ id: 'PleaseSelectLocation' }));
        // }
      }
    }
  };

  let rowSchema = {
    transactionItemId: null,
    locationId: null,
    labType: null,
    locationName: null,
    locationCode: null,
    quantity: null,
    approvedQuantity: null,
    inventoryId: null,
    productId: null,
    batchId: null,
    mainWarehouseId: null,
    subWarehouseId: null,
    locatorId: null,
  };

  const onCancel = () => {
    props.handleCancel();
    setSelectedBatchNumber([]);
    setLocators([]);
    setData([]);
    setFinalData([]);
  };

  const handleChange = (value, index, type) => {
    if (
      type == 'approvedQuantity' &&
      !batchQty &&
      batchData &&
      labType == 'nonmedicalredcrescent'
    ) {
      const loc = batchData && batchData[0] && batchData[0].locators;
      let batchValue = {};
      loc &&
        loc.forEach((l) => {
          batchValue[l.locatorId] = l.quantity;
        });
      setBatchQty(batchValue);
    }
    let arr = [...dataValues];
    let indexData = dataValues.findIndex((x) => x.index == index);
    let obj = {};
    if (indexData > -1) {
      obj = { ...dataValues[indexData] };
      dataValues.splice(indexData, 1);
    } else {
      obj.index = index;
    }
    let curentLocatorId;
    if (type === 'mainWarehouseId') {
      const tmpArr = value.split('__');
      const mainWarehouseId = tmpArr[0].split('main_')[1];
      const subWarehouseId = tmpArr[1].split('sub_')[1];
      const locatorId = tmpArr[2].split('loc_')[1];
      curentLocatorId = locatorId;
      if (mainWarehouseId !== 'undefined') {
        obj[type] = mainWarehouseId;
      } else {
        obj[type] = null;
      }
      if (subWarehouseId && subWarehouseId !== 'undefined' && subWarehouseId !== 'null') {
        obj['subWarehouseId'] = subWarehouseId;
      } else {
        // obj['subWarehouseId'] = null;
      }

      if (locatorId && locatorId !== 'null' && locatorId !== 'undefined') {
        obj['locatorId'] = locatorId;
        setMaxValue(batchQty[locatorId]);
      } else {
        // obj['locatorId'] = null;
      }
    } else if (type === 'batchId') {
      const batch =
        batchData && batchData.length > 0 && batchData.find((item) => item.batchNumber == value);
      let locators = [];
      let batchValueQty = {};
      for (let i = 0; i < batchData.length; i++) {
        if (batchData[i].batchNumber == value && batchData[i].locators) {
          locators.push(...batchData[i].locators);
          batchData[i].locators?.forEach((locator) => {
            batchValueQty[locator.locatorId] = locator.quantity;
          });
        }
      }

      //setLocators(locators);

      selectedBatchNumber[index] = batch.batchNumber;
      setSelectedBatchNumber([...selectedBatchNumber]);
      batchLocators[index] = locators;
      setLocators([...batchLocators]);

      if (locators && locators.length > 0) {
        if (locators[0]?.mainWarehouseId) obj['mainWarehouseId'] = locators[0]?.mainWarehouseId;
        if (locators[0]?.subWarehouseId) obj['subWarehouseId'] = locators[0]?.subWarehouseId;
        if (locators[0]?.locatorId) obj['locatorId'] = locators[0]?.locatorId;

        batchValueQty[locators[0]?.locatorId] = locators[0].quantity;

        setEnable(false);
        if (labType == 'medicalredcrescent') {
          setBatchQty(batchValueQty);
        }
        setMaxValue(locators[0].quantity);

        let checkItem = false;

        finalData.length > 0 &&
          finalData.map((data) => {
            if (typeof data.locatorId === 'undefined' && locators.length === 0) {
              checkItem = true;
              return;
            } else {
              checkItem = false;

              return;
            }
          });
        setEnable(checkItem);
      } else {
        message.error('Locators not found');
        setEnable(true);
        // setFormSubmit(true);
        //setBatchQty(null);
      }

      obj = {
        ...obj,
        quantity: editData.quantity,
        approvedQuantity: obj.approvedQuantity ? obj.approvedQuantity : editData.quantity,
        labType: batch.labType,
        inventoryId: batch.inventoryId,
        productId: batch.productId,
        batchId: batch.id,
        locationName: locationDetails.name,
        locationCode: locationDetails.code,
        locationId: locationDetails.id,
      };

      setBatchId(batch.id);
    } else if (labType === 'nonmedicalredcrescent') {
      obj[type] = value;
      let batchValueQty = {};

      if (batchData[0].locators && batchData[0].locators.length > 0) {
        batchLocators[index] = batchData[0].locators;
        setLocators([...batchLocators]);
      }

      if (batchData[0].locators && batchData[0].locators.length > 0) {
        if (batchData[0].locators[0]?.mainWarehouseId)
          obj['mainWarehouseId'] = batchData[0].locators[0]?.mainWarehouseId;
        if (
          batchData[0].locators[0]?.subWarehouseId != '' ||
          batchData[0].locators[0]?.subWarehouseId != null
        )
          obj['subWarehouseId'] = batchData[0].locators[0]?.subWarehouseId;
        if (batchData[0].locators[0]?.locatorId)
          obj['locatorId'] = batchData[0].locators[0]?.locatorId;
        batchValueQty[batchData[0].locators[0]?.locatorId] = batchData[0].locators[0].quantity;
        setEnable(false);
        if (!batchQty && batchData && labType == 'nonmedicalredcrescent') {
          const loc = batchData && batchData[0] && batchData[0].locators;
          let batchValue = {};
          loc &&
            loc.forEach((l) => {
              batchValue[l.locatorId] = l.quantity;
            });
          setBatchQty(batchValue);
        }
        // setBatchQty(batchValueQty);
        setMaxValue(batchData[0].locators[0].quantity);
        let checkItem = false;

        finalData.length > 0 &&
          finalData.map((data) => {
            if (typeof data.locatorId === 'undefined' && locators.length === 0) {
              checkItem = true;
              return;
            } else {
              checkItem = false;

              return;
            }
          });
        setEnable(checkItem);
      } else {
        message.error('Locators not found');
        setEnable(true);
        // setFormSubmit(true);
        //setBatchQty(null);
      }

      obj = {
        ...obj,
        labType: labType,
        quantity: editData.quantity,
        inventoryId: editData.inventoryId,
        productId: editData.productId,
        locationName: locationDetails.name,
        locationCode: locationDetails.code,
        locationId: locationDetails.id,
        batchId: batchData[0].id,
      };
    } else {
      obj[type] = value;
    }

    if (indexData > -1) {
      arr[indexData] = obj;
    } else {
      arr.push(obj);
    }

    setData(arr);
    setFinalData(arr);
  };

  const remove_field = (field, index, remove) => {
    remove(field.name, field.key);
    const array = finalData.slice();
    const arr = array.splice(field.key, 1);
    const loc = batchLocators.slice();
    const l = loc.splice(field.key, 1);
    const batch = selectedBatchNumber.slice();
    const b = batch.splice(field.key, 1);
    setSelectedBatchNumber(batch);
    setLocators(loc);
    setData(array);
    setFinalData(array);
    let checkItem = true;

    array.map((data) => {
      if (typeof data.locatorId !== 'undefined') {
        checkItem = false;
        return;
      } else {
        checkItem = true;
        return;
      }
    });
    setEnable(checkItem);
  };

  return (
    <>
      {editData && Object.keys(editData).length == 0 ? (
        <div>{/* <Spin className={styles.loader} spinning={true} size="large" /> */}</div>
      ) : (
        <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
          <div style={{ marginTop: '5px' }}>
            {editData && (
              <>
                <div>
                  <Form.List name="locators">
                    {(fields, { add, remove }) => {
                      if (!fieldsOpen) {
                        setFieldsOpen(true);
                        add();
                      } else {
                      }
                      return (
                        <>
                          {fields.map((field, index: number) => (
                            <>
                              <Row>
                                {fields.length > 1 && (
                                  <MinusCircleOutlined
                                    onClick={() => remove_field(field, index, remove)}
                                  />
                                )}
                                <Divider orientation="left">
                                  {`Locator ${field.name + 1}`} (
                                  {formatMessage({ id: 'RequestedQuantity' })} :{' '}
                                  {editData && editData.quantity})
                                </Divider>
                                <Col flex={1} span={11}>
                                  <Form.Item
                                    {...field}
                                    label={formatMessage({ id: 'Product' })}
                                    initialValue={
                                      getLocale() === 'ar-EG'
                                        ? editData.product?.arabicDescription
                                        : editData.product?.description
                                    }
                                    name={[field.name, 'product']}
                                    className={styles.formField}
                                    rules={[{ required: true, message: 'Required' }]}
                                  >
                                    <Input
                                      name="product"
                                      value={
                                        getLocale() === 'ar-EG'
                                          ? editData.product.arabicDescription
                                          : editData.product.description
                                      }
                                    />
                                  </Form.Item>
                                </Col>
                                <Col flex={1} span={11}>
                                  <Form.Item
                                    {...field}
                                    label={formatMessage({ id: 'Code' })}
                                    name={[field.name, 'code']}
                                    initialValue={editData.product.code}
                                    className={styles.formField}
                                    rules={[{ required: true, message: 'Required' }]}
                                  >
                                    <Input name="product" value={editData.product.code} />
                                  </Form.Item>
                                </Col>
                              </Row>
                              <Row gutter={[24, 24]} align="middle">
                                {labType === 'medicalredcrescent' && (
                                  <Col span={11} className={styles.colheight}>
                                    <Form.Item
                                      {...field}
                                      label={formatMessage({ id: 'FromBatchNumber' })}
                                      name={[field.name, `batch`]}
                                      rules={[
                                        {
                                          required: true,
                                          message: formatMessage({ id: 'MissingBatchNumber' }),
                                        },
                                      ]}
                                    >
                                      <Select
                                        onChange={(value) => {
                                          handleChange(value, `${index}`, 'batchId');
                                        }}
                                      >
                                        {batchData &&
                                          batchData.length > 0 &&
                                          batchData.map((batch: any) => {
                                            return (
                                              <Option
                                                // disabled={fields && fields.length > 1 && selectedBatchNumber && selectedBatchNumber.includes(batch.batchNumber) && selectedBatchNumber.length > 0 ? true : false }
                                                key={batch.batchNumber}
                                                value={batch.batchNumber}
                                              >
                                                {batch.batchNumber}
                                              </Option>
                                            );
                                          })}
                                      </Select>
                                    </Form.Item>
                                  </Col>
                                )}
                                <Col span={11} className={styles.colheight}>
                                  <Form.Item
                                    {...field}
                                    label={formatMessage({ id: 'Quantity' })}
                                    name={[field.name, `quantity`]}
                                    rules={[
                                      {
                                        required: true,
                                        message: 'MissingQuantity',
                                      },
                                      // {
                                      //   type: 'number',
                                      //   max: maxValue,
                                      //   message: `Should not be more than ${maxValue}`,
                                      // },
                                      {
                                        type: 'number',
                                        min: 1,
                                        message: 'Should be more than 0',
                                      },
                                    ]}
                                  >
                                    <InputNumber
                                      // max={maxValue}
                                      placeholder="quantity"
                                      precision={0}
                                      style={{ width: '100%' }}
                                      onChange={(value) => {
                                        handleChange(value, `${index}`, 'approvedQuantity');
                                      }}
                                    />
                                  </Form.Item>

                                  {finalData &&
                                    finalData.map((data) => {
                                      if (
                                        data.index == index &&
                                        batchQty &&
                                        batchQty[data.locatorId]
                                      ) {
                                        return (
                                          <span className={styles.alignright}>
                                            {formatMessage({ id: `MaximumQuantity` })} :
                                            {batchQty[data.locatorId]}
                                          </span>
                                        );
                                      }
                                    })}
                                </Col>
                              </Row>
                              {labType === 'nonmedicalredcrescent' &&
                                batchLocators &&
                                batchLocators[index] &&
                                batchLocators[index].length > 0 && (
                                  <Row gutter={[12, 12]} align="middle">
                                    <Form.Item
                                      {...field}
                                      // label="Warehouse"
                                      name={[field.name, `FromWareHouse`]}
                                      initialValue={`main_${batchLocators[index][0]?.mainWarehouseId}__sub_${batchLocators[index][0]?.subWarehouseId}__loc_${batchLocators[index][0]?.locatorId}`}
                                    >
                                      <Radio.Group
                                        defaultValue={`main_${batchLocators[index][0]?.mainWarehouseId}__sub_${batchLocators[index][0]?.subWarehouseId}__loc_${batchLocators[index][0]?.locatorId}`}
                                        // className={styles.warehousecheckmark}
                                        className={styles.radioFormat}
                                        onChange={(e) =>
                                          handleChange(
                                            e.target.value,
                                            `${index}`,
                                            'mainWarehouseId',
                                          )
                                        }
                                      >
                                        {batchLocators[index].map((locator) => {
                                          const id = `main_${locator.mainWarehouseId}__sub_${locator.subWarehouseId}__loc_${locator.locatorId}`;

                                          return (
                                            <Col className={styles.maxWidthRadio} span={11}>
                                              <Radio className={styles.spaceAdjust} value={id}>{`${
                                                !!locator.mainWarehouseName
                                                  ? `${locator.mainWarehouseName} `
                                                  : ''
                                              }${
                                                !!locator.subWarehouseName
                                                  ? `${locator.subWarehouseName} `
                                                  : ''
                                              }${
                                                !!locator.locatorId ? `${locator.locatorId} ` : ''
                                              }`}</Radio>
                                            </Col>
                                          );
                                        })}
                                      </Radio.Group>
                                    </Form.Item>
                                  </Row>
                                )}
                              {labType === 'medicalredcrescent' &&
                                batchLocators[index] &&
                                batchLocators[index].length > 0 &&
                                dataValues &&
                                dataValues.length > 0 &&
                                dataValues[index]?.batchId && (
                                  <Row gutter={[12, 12]} align="middle">
                                    <Form.Item
                                      {...field}
                                      label={formatMessage({ id: 'Warehouse' })}
                                      name={[field.name, `FromWareHouse`]}
                                      initialValue={
                                        batchLocators[index] && batchLocators[index].length > 0
                                          ? `main_${batchLocators[index][0]?.mainWarehouseId}__sub_${batchLocators[index][0]?.subWarehouseId}__loc_${batchLocators[index][0]?.locatorId}`
                                          : null
                                      }
                                    >
                                      <Radio.Group
                                        defaultValue={
                                          batchLocators[index] && batchLocators[index].length > 0
                                            ? `main_${batchLocators[index][0]?.mainWarehouseId}__sub_${batchLocators[index][0]?.subWarehouseId}__loc_${batchLocators[index][0]?.locatorId}`
                                            : null
                                        }
                                        className={styles.radioFormat}
                                        onChange={(e) =>
                                          handleChange(
                                            e.target.value,
                                            `${index}`,
                                            'mainWarehouseId',
                                          )
                                        }
                                      >
                                        {batchLocators[index].map((locator) => {
                                          const id = `main_${locator.mainWarehouseId}__sub_${locator.subWarehouseId}__loc_${locator.locatorId}`;

                                          return (
                                            <Col className={styles.maxWidthRadio} span={11}>
                                              <Radio className={styles.spanAdjust} value={id}>{`${
                                                !!locator.mainWarehouseName
                                                  ? `${locator.mainWarehouseName} `
                                                  : ''
                                              }${
                                                !!locator.subWarehouseName
                                                  ? `${locator.subWarehouseName} `
                                                  : ''
                                              }${
                                                !!locator.locatorId ? `${locator.locatorId} ` : ''
                                              }`}</Radio>
                                            </Col>
                                          );
                                        })}
                                      </Radio.Group>
                                    </Form.Item>
                                  </Row>
                                )}
                            </>
                          ))}
                          <Form.Item>
                            <Button
                              type="dashed"
                              onClick={() => {
                                add();
                              }}
                              block
                              icon={<PlusOutlined />}
                            >
                              {formatMessage({ id: 'AddField' })}
                            </Button>
                          </Form.Item>
                        </>
                      );
                    }}
                  </Form.List>
                </div>
              </>
            )}
          </div>

          <Row gutter={[24, 24]}>
            <Col flex={1}>
              <Form.Item>
                <Button
                  disabled={enable}
                  // onClick={onFinish1}
                  type="primary"
                  htmlType="submit"
                  block
                  loading={formSubmit}
                >
                  {useIntl().formatMessage({ id: 'Apply' })}
                </Button>
              </Form.Item>
            </Col>
            <Col flex={1}>
              <Form.Item>
                <Button onClick={onCancel} block>
                  {useIntl().formatMessage({ id: 'Cancel' })}
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>
      )}
    </>
  );
};

const EditModal = (props: any) => {
  const {
    currentStatus,
    handleOk,
    handleCancel,
    isVisible,
    locationDetails,
    labType,
    selectedOrder,
    type,
    editData,
  } = props;

  const [selectedLocation, setSelectedLocation] = useState('');
  const [locations, setLocations] = useState([]);
  const [dataArr, setdataArr] = useState([]);
  const [dataValues, setDataValues] = useState([]);
  const locDropdown: [] = [];
  const [warehouse, setWarehouse] = useState([]);
  const [batchData, setBatchData] = useState([]);
  const [subWarehouses, setsubWarehouses] = useState([]);

  async function fetchMyAPI(selectedOrder) {
    if (selectedOrder && selectedOrder.length > 0) {
      const arrayData = [];
      let arr = [];
      for (let i = 0; i < selectedOrder.length; i++) {
        let obj = { id: selectedOrder[i].inventoryId, dataLength: [[]] };
        if (!arr.find((item) => item.id == obj.id)) {
          arr.push(obj);
        }
        setdataArr(arr);
        if (!!selectedOrder[i]?.batches) {
          arrayData.push(...selectedOrder[i]?.batches);
        }
      }
      setBatchData(arrayData);
    }
  }
  useEffect(() => {
    if (isVisible) {
      redCrescentService.getLocations('medicalredcrescent').then((locations: any) => {
        locations.map((lab: any) => {
          locDropdown.push(lab);
        });
        setLocations(locDropdown);
      });
    }

    if (selectedOrder && selectedOrder.length > 0) {
      props.isLoadingBtnCancel();
    }

    fetchMyAPI(selectedOrder);

    // var labtype = window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC;
    if (isVisible) {
      redCrescentService.getWareHouses('medicalredcrescent', locationDetails.id).then((data) => {
        setWarehouse(data);
      });
    }
  }, [selectedOrder, isVisible]);

  const handleSetData = (d) => {
    setDataValues([...d]);
  };

  return (
    <>
      <Modal
        title={useIntl().formatMessage({ id: 'Approve' })}
        visible={isVisible}
        afterClose={() => handleCancel()}
        destroyOnClose
        closable={false}
        footer={false}
        width="50%"
      >
        {editData && Object.keys(editData).length == 0 ? (
          <div>
            <Spin className={styles.loader} spinning={true} size="large" />
          </div>
        ) : (
          <BasicEditForm
            batchData={batchData}
            setsubWarehouses={setsubWarehouses}
            subWarehouses={subWarehouses}
            type={type}
            setdataArr={setdataArr}
            dataArr={dataArr}
            setData={handleSetData}
            setDataValues={setDataValues}
            dataValues={dataValues}
            warehouse={warehouse}
            setWarehouse={setWarehouse}
            currentStatus={currentStatus}
            labType={labType}
            selectedLocation={selectedLocation}
            setSelectedLocation={setSelectedLocation}
            locations={locations}
            locationDetails={locationDetails}
            handleOk={(updatedBatches: any) => handleOk(updatedBatches)}
            handleCancel={() => {
              handleCancel();
              setSelectedLocation('');
              setdataArr([]);
              setDataValues([]);
              setsubWarehouses([]);
            }}
            selectedOrder={selectedOrder}
            editData={editData}
          />
        )}
      </Modal>
    </>
  );
};

export default EditModal;

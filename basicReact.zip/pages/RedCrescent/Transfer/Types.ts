interface ColumnType {
  title: string;
  width?: string;
  dataIndex: string;
  key: string;
  fixed?: string;
  render?: any;
}

type ProductClassificationType =
  | 'PHENOTYPING'
  | 'Serology'
  | 'NAT'
  | 'Donation'
  | 'Bacterial Detection';

interface ProductType {
  category: string;
  classification: ProductClassificationType;
  code: string;
  createdAt: string;
  description: string;
  id: number;
  unitOfMeasures: string;
  updatedAt: string;
}

interface ItemType {
  id: number;
  instrumentId: number;
  transactionId: number;
  locationId: number;
  labType: string;
  regionId: number;
  updatedAt: string;
}

interface TransferType {
  items:ItemType
  toLabType: string;
  id: number;
  toLocationId: number;
  toRegionId: number;
  createdAt: string;
  updatedAt: string;
}

interface LocationType {
  code: string;
  createdAt: string;
  email: string;
  id: number;
  labCapacity: number;
  labType: string;
  locationType: string;
  name: string;
  numberOfAttendees: number;
  primaryContact: string;
  primaryMobile: string;
  samplesPerDay: number;
  updatedAt: string;
  region: string;
}

interface TransferType {
  locationDetails: LocationType;
  transfer: TransferType[];
}

export { ColumnType, ProductType, ItemType, TransferType,  LocationType };

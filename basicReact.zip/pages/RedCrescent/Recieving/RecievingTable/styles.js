import { FileExcelFilled } from "@ant-design/icons";

const styles = {
    actions: {
      // display: 'inline-block',
      // marginLeft: '-50px',
    },
  
    actionButton: {
      border: 'none',
      // color: 'blue',
      // background: 'transparent',
    },
  
    actionDiv: {
      display: flex,
    },

    editbtn: {
      marginReft: '10px',
    },
  
    disputeModal2: {
      float: 'left',
      // marginTop: '-32px',
      // marginLeft: '10px',
      left: '40%',
      border: 'none',
      // color: 'blue',
      // background: 'transparent',
    },
  
    deleteModal: {
      // float: 'left',
      // marginTop: '-32px',
      // marginLeft: '10px',
      // left: '40px',
      // border: 'none',
      // color: 'blue',
      // background: 'transparent',
    },
  
    topMargin: { marginTop: '-40px' },
  };
  
  export default styles;
  
import React from 'react';
import { Access, useAccess, FormattedMessage, getLocale } from 'umi';
import {
  ForwardOutlined,
  CheckOutlined,
  InfoOutlined,
  QrcodeOutlined,
  EditOutlined,
  DownloadOutlined,
} from '@ant-design/icons';
import { Table, Button, Typography, Space, Tooltip } from 'antd';
import moment from 'moment';
import redcrescentService from '../../services/redcrescent.service';
import UpdateModal from '../Modals/UpdateModal';
import StatusModal from '../Modals/StatusModal';
import styles from './index.less';
import Modal from 'antd/lib/modal/Modal';
import QrModal from '../Modals/QrModal';
import InfoModal from '../Modals/InfoModal';
import UpdateBinNumber from '../Modals/UpdateBinNumber';
import { LabTypes, RecivingStatues } from '@/services/Constants';
import ApproveModal from '../Modals/ApproveModal';
import { lastIndexOf } from 'lodash';

const { Title, Text } = Typography;

const tableChoice = {
  all: 'columns',
  approved: 'columns1',
  cancelled: 'columns2',
  hold: 'columns3',
};

const DATE_FORMAT = 'YYYY-MM-DD';

class RecievingTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      inputList: [{ product: '', quantity: '', note: '' }],
      showUpdateModal: false,
      userAccess: this.props.access,
      showStatusModal: false,
      showInspectionModal: false,
      showBinNumberModal: false,
      downloadQrData: {},
      showQrModal: false,
      showTransactionModal: false,
      infoModalData: [],
      showInfoModal: false,
      updateModalData: null,
      binNumberModalData: null,
      transactionModalData: null,
      status: 'all',
      columns: [
        {
          title: <FormattedMessage id="Code" />,
          dataIndex: ['product', 'code'],
          key: 'productCode',
        },
        {
          title: <FormattedMessage id="Description" />,
          dataIndex:
            getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : ['product', 'description'],
          key: 'description',
        },
        {
          title: <FormattedMessage id="PurchaseOrderNumber" />,
          dataIndex: 'purchaseOrderId',
          key: 'id',
        },
        {
          title: <FormattedMessage id="TotalQuantity" />,
          key: 'quantity',
          dataIndex: ['orderItem', 'quantity'],
        },
        {
          title: <FormattedMessage id="ReceivingQuantity" />,
          dataIndex: 'receivedQuantity',
          key: 'receivedQuantity',
        },
      ],
      finalColumns: [
        {
          title: <FormattedMessage id="Code" />,
          dataIndex: ['product', 'code'],
          key: 'productCode',
        },
        {
          title: <FormattedMessage id="Description" />,
          dataIndex:
            getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : ['product', 'description'],
          key: 'description',
        },
        {
          title: <FormattedMessage id="PurchaseOrderNumber" />,
          dataIndex: 'purchaseOrderId',
          key: 'id',
        },
        {
          title: <FormattedMessage id="TotalQuantity" />,
          key: 'quantity',
          dataIndex: ['orderItem', 'quantity'],
        },
        {
          title: <FormattedMessage id="ReceivingQuantity" />,
          dataIndex: 'acceptedQuantity',
          key: 'acceptedQuantity',
        },
      ],
      medicalColumns: [
        {
          title: <FormattedMessage id="BatchNumber" />,
          dataIndex: 'batchNumber',
          key: 'batchNumber',
        },
        {
          title: <FormattedMessage id="ExpiryDate" />,
          key: 'expiryDate',
          dataIndex: 'expiryDate',
          render: (text, record) => {
            return text
              ? getLocale().includes('en')
                ? moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
                : moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
              : '';
          },
        },
      ],
      initialAction: {
        title: <FormattedMessage id="Actions" />,
        key: 'action',
        render: (text, record, index) => (
          <div className={styles.actionDiv}>
            {this.props.labtype === LabTypes.MRC && (
              <Button
                className={styles.editbtn}
                type="primary"
                shape="circle"
                icon={<EditOutlined />}
                onClick={(e) => this.updateModal(record)}
              />
            )}
            <Button
              type="primary"
              shape="circle"
              icon={<QrcodeOutlined />}
              onClick={(e) => this.openQr(record)}
              disabled={
                this.props.labtype === LabTypes.MRC
                  ? !(record.batchNumber && record.expiryDate)
                  : false
              }
            />
          </div>
        ),
      },
      finalAction: {
        title: <FormattedMessage id="Actions" />,
        width: '100px',
        key: 'action',
        render: (text, record, index) => {
          return (
            <Space size={12}>
              <Tooltip title={<FormattedMessage id="Approved" />}>
                <Button
                  type="primary"
                  disabled={record && record.binNumber ? true : false}
                  // style={this.props.style}
                  shape="circle"
                  icon={<CheckOutlined />}
                  onClick={(e) => this.binNumberModal(record)}
                />
              </Tooltip>
              <Tooltip title={<FormattedMessage id="Download" />}>
                <Button
                  type="primary"
                  disabled={record && record.binNumber ? true : false || record.content === null}
                  shape="circle"
                  icon={<DownloadOutlined />}
                  onClick={() => this.handleDownload(record)}
                />
              </Tooltip>
            </Space>
          );
        },
      },
      inspectionAction: {
        title: <FormattedMessage id="Actions" />,
        width: '100px',
        key: 'action',
        render: (text, record, index) => {
          return (
            <div className={styles.actionDiv}>
              <Tooltip title={<FormattedMessage id="Info" />}>
                <Button
                  type="primary"
                  className={styles.editbtn}
                  shape="circle"
                  icon={<InfoOutlined />}
                  onClick={(e) => this.infoDataModal(record)}
                />
              </Tooltip>
              <Tooltip title={<FormattedMessage id="Download" />}>
                <Button
                  disabled={
                    record.acceptedQuantity + record.rejectedQuantity != record.receivedQuantity
                    // record?.inspectionHistory[record?.inspectionHistory.length - 1]?.content ===
                    // null
                  }
                  type="primary"
                  className={styles.editbtn}
                  shape="circle"
                  icon={<DownloadOutlined />}
                  onClick={(e) => this.download(record)}
                />
              </Tooltip>

              <Access
                accessible={
                  this.state.userAccess.canAccessRedCrescentRecievingModule(
                    this.props.locationId,
                  ) ||
                  this.state.userAccess.canAccessRedCrescentInspectionAccess(this.props.locationId)
                }
              >
                {record.acceptedQuantity + record.rejectedQuantity != record.receivedQuantity && (
                  <Button
                    type="primary"
                    // style={this.props.style}
                    shape="circle"
                    icon={<ForwardOutlined />}
                    onClick={(e) => this.statusModal(record)}
                  />
                )}
              </Access>
              {record.acceptedQuantity + record.rejectedQuantity == record.receivedQuantity &&
                record.committeeAdministrativeMemberApproved == 0 &&
                (this.props.redCrescentProfile?.role === 'committeeAdministrativeMember' ||
                  this.props.redCrescentProfile?.role === 'superUser') && (
                  <ApproveModal
                    data={record}
                    getOrder={this.props.getOrder}
                    approveManager={'committeeAdministrativeMemberApproved'}
                    getTransfer={this.props.onChange}
                    status={
                      record.committeeAdministrativeMemberApproved === 1
                        ? 'AlreadyApproved'
                        : 'committeeAdministrativeMemberApproved'
                    }
                  />
                )}

              {record.acceptedQuantity + record.rejectedQuantity == record.receivedQuantity &&
                record.committeeAdministrativeMemberApproved == 1 &&
                (this.props.redCrescentProfile?.role === 'committeeHeadManager' ||
                  this.props.redCrescentProfile?.role === 'superUser') && (
                  <ApproveModal
                    data={record}
                    getOrder={this.props.getOrder}
                    approveManager={'committeeHeadManagerApproved'}
                    getTransfer={this.props.onChange}
                    status={
                      record.committeeHeadManagerApproved === 1
                        ? 'AlreadyApproved'
                        : 'committeeHeadManagerApproved'
                    }
                  />
                )}
            </div>
          );
        },
      },
      nestedColumns: [
        {
          title: <FormattedMessage id="LocatorID" />,
          dataIndex: ['batches', 'binNumber'],
          render: (text, record) => {
            return record.binNumber;
          },
          key: 'binNumber',
        },
        {
          title: <FormattedMessage id="BatchNumber" />,
          dataIndex: ['batches', 'batchNumber'],
          render: (text, record) => {
            return record.batchNumber;
          },
          key: 'binNumber',
        },
        {
          title: <FormattedMessage id="Quantity" />,
          dataIndex: ['batches', 'quantity'],
          render: (text, record) => {
            return record.quantity;
          },
          key: 'quantity',
        },
        {
          title: <FormattedMessage id="ExpiryDate" />,
          dataIndex: ['batches', 'expiryDate'],
          render: (text, record) => {
            return record.expiryDate
              ? getLocale().includes('en')
                ? moment(record.expiryDate, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
                : moment(record.expiryDate, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
              : '';
          },
          key: 'expiryDate',
        },
      ],

      expandRowData: [],
      expandedRowKeys: [],
    };
  }

  updateModal = (values) => {
    this.setState({
      showUpdateModal: true,
      updateModalData: values,
    });
  };
  statusModal = (values) => {
    this.setState({
      showStatusModal: true,
      statusModalData: values,
    });
  };
  moveToFinal = (values) => {
    const data = {
      status: 'approve',
    };
    if (this.props.labtype === 'nonmedicalredcrescent') {
      data.orderItemId = values.orderItemId;
      data.batched = true;
    }
    redcrescentService.updateBatch(values.id, data).then(() => {
      this.props.changeStatus({ status: RecivingStatues.FINAL, isApproved: true });
    });
  };
  binNumberModal = (values) => {
    this.setState({
      showBinNumberModal: true,
      binNumberModalData: values,
    });
  };

  infoDataModal = (values) => {
    this.setState({
      showInfoModal: true,
      infoModalData: [values],
    });
  };

  download = async (values: any) => {
    const historyIndex = values.inspectionHistory.length - 1;
   const content = JSON.parse(values.inspectionHistory[historyIndex].content);
    if (!!content.rejectKey) {
      await redcrescentService.downloadPDF(content.rejectKey);
    }
    if (!!content.acceptKey) {
      await redcrescentService.downloadPDF(content.acceptKey);
    }
  };

  handleDownload = async (val) => {
    const content = JSON.parse(val.content);

    if (content?.notarized) {
      let fileFormat = 'xlsx';
      await redcrescentService.downloadFile(val?.id, content?.notarized, fileFormat);
    }
    if (content?.finalReceiving) {
      let fileFormat = 'pdf';
      await redcrescentService.downloadFile(val?.id, content?.finalReceiving, fileFormat);
    }
  };

  openQr = (data) => {
    this.setState({
      downloadQrData: data,
      showQrModal: !this.state.showQrModal,
    });
  };

  componentDidMount() {
    const { data } = this.props;
    this.setState({ inputList: data });
  }

  componentDidUpdate(prevProps) {
    const { data, status, locationId } = this.props;

    if (prevProps.data !== data) {
      const result =
        data &&
        data.length > 0 &&
        data.find((record) => record.id === this.state.expandedRowKeys[0]);
      if (result) {
        this.setState({
          expandableRowData: result,
        });
        this.getExpandableData(this.state.expandedRowKeys[0], result.batches);
      }
      this.setState({ inputList: data, locationId });
    }

    if (prevProps.status !== status) {
      if (status === 'all') this.setState({ status });
      else if (status === 'completed') this.setState({ status }); // this.changeToCompletedColumns();
    }
  }

  async updateStatus(id) {
    const { data, getOrder } = this.props;
    const _data = JSON.parse(JSON.stringify(data));

    const payload = { status: 'completed' };
    await redcrescentService.updateOrder(_data[id].id, payload);
  }

  dateDiff = (_date) => {
    const today = new Date();
    const yday = new Date(_date);
    const _diff = (today.getTime() - yday.getTime()) / (1000 * 3600 * 24);
    return _diff;
  };

  keys: any[] = [];

  getExpandableData = (recordId, dataItems) => {
    this.keys[0] === recordId ? (this.keys = []) : (this.keys[0] = recordId);
    this.setState({
      expandRowData: [],
      expandedRowKeys: this.keys,
    });
    const data = dataItems;
    this.setState({
      expandRowData: data,
    });
  };

  expandedRowRender = () =>
    this.props.status === 'pending' ? (
      <Table
        columns={this.state.nestedPendingColumns}
        dataSource={this.state.expandRowData}
        pagination={false}
      />
    ) : this.props.status == 'quarantined' ? (
      <Table
        columns={this.state.nestedInspectedColumns}
        dataSource={this.state.expandRowData}
        pagination={false}
      />
    ) : (
      <Table
        columns={this.state.nestedColumns}
        dataSource={this.state.expandRowData}
        pagination={false}
      />
    );

  handleCancel = () => {
    this.setState({
      showUpdateModal: false,
      showStatusModal: false,
      showBinNumberModal: false,
      showQrModal: false,
      showInfoModal: false,
    });
  };

  render() {
    const {
      columns,
      inspectionAction,
      finalAction,
      initialAction,
      medicalColumns,
      finalColumns,
    } = this.state;
    const { data, status } = this.props;
    let accessible = this.state.userAccess.canAccessRedCrescentReceivingModuleAction(
      this.props.locationId,
    );

    let columnData = window.location.href.includes('non-medical')
      ? [...columns]
      : [...columns, ...medicalColumns];
    const tableColumn =
      status === 'inspection'
        ? [...columnData, inspectionAction]
        : status === 'approve'
        ? accessible
          ? [...finalColumns, finalAction]
          : [...columnData]
        : accessible
        ? [...columnData, initialAction]
        : [...columnData];

    return (
      <div className="container">
        <div>
          <Table
            columns={tableColumn}
            dataSource={data}
            size="small"
            pagination={{ defaultPageSize: 10, showSizeChanger: false }}
            rowKey={(record) => record.id}
            onExpand={(expanded, record) => this.getExpandableData(record.id, record.batches)}
            expandedRowRender={(record) => this.expandedRowRender()}
            expandIconColumnIndex={0}
            expandedRowKeys={this.state.expandedRowKeys}
            expandIconAsCell={false}
            expandable={{
              expandedRowRender: (record) => this.expandedRowRender(record),
              rowExpandable: (record) => {
                return false;
                // if (record.batches.length > 0) {
                //   return true;
                // } else {
                //   return false;
                // }
              },
            }}
          />
          <UpdateModal
            isVisible={this.state.showUpdateModal}
            inputList={this.state.inputList}
            getOrder={this.props.getOrder}
            locationId={this.props.locationId}
            handleCancel={this.handleCancel}
            updateModalData={this.state.updateModalData}
            changeStatus={this.props.changeStatus}
            status={status}
          />
          <StatusModal
            isVisible={this.state.showStatusModal}
            inputList={this.state.inputList}
            getOrder={this.props.getOrder}
            locationId={this.props.locationId}
            handleCancel={this.handleCancel}
            statusModalData={this.state.statusModalData}
            status={status}
            changeStatus={this.props.changeStatus}
            labType={this.props.labtype}
          />
          <Modal
            title={<FormattedMessage id="Inspection" />}
            centered
            visible={this.state.showInfoModal}
            width={720}
            onOk={this.handleCancel}
            onCancel={this.handleCancel}
            destroyOnClose
            footer={false}
          >
            <InfoModal resultSet={this.state.infoModalData} />
          </Modal>
          <UpdateBinNumber
            isVisible={this.state.showBinNumberModal}
            inputList={this.state.inputList}
            getOrder={this.props.getOrder}
            locationId={this.props.locationId}
            handleCancel={this.handleCancel}
            binNumberModalData={this.state.binNumberModalData}
            status={status}
            labType={this.props.labtype}
            changeStatus={this.props.changeStatus}
          />

          <QrModal
            isVisible={this.state.showQrModal}
            downloadQrData={this.state.downloadQrData}
            handleCancel={this.handleCancel}
            labType={this.props.labtype}
            changeStatus={this.props.changeStatus}
          />
        </div>
      </div>
    );
  }
}

const RecievingTableWrapper = (props: any) => <RecievingTable {...props} access={useAccess()} />;
export default RecievingTableWrapper;

import React from 'react';
import { Table, Spin, Button } from 'antd';
import { FormattedMessage, getLocale } from 'umi';
import moment from 'moment';
import redcrescentService from '../../services/redcrescent.service'
import { DownloadOutlined } from '@ant-design/icons';


const InfoModal: React.FC<any> = (props) => {
  const { resultSet } = props;
  
  const getTablecolumns = [
  {
    title: <FormattedMessage id="Code" />,
    width: '20px',
    dataIndex: ['product', 'code'],
    key: 'productCode',
  },
  {
    title: <FormattedMessage id="Description" />,
    width: '200px',
    dataIndex:
      getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : ['product', 'description'],
    key: 'description',
  },
  {
    title: <FormattedMessage id="UpdatedAt" />,
    width: '200',
    dataIndex: 'updatedAt',
    key: 'updatedAt',
    render: (text, record) =>
      !getLocale() || getLocale().includes( 'en')
        ? moment(text).locale(getLocale()).format('YYYY-MM-DD, HH:mm')
        : moment(text).locale(getLocale()).format('YYYY-MM-DD, HH:mm'),
  },
];

const getNestedColumns = [
  {
    title: <FormattedMessage id="GRN" />,
    width: '100px',
    dataIndex: 'id',
    key: 'id',
  },
  {
    title: <FormattedMessage id="ReceivedQuantity" />,
    width: '200px',
    dataIndex: 'receivedQuantity',
    key: 'receivedQuantity',
  },
  {
    title: <FormattedMessage id="AcceptedQuantity" />,
    width: '20px',
    dataIndex: 'acceptedQuantity',
    key: 'acceptedQuantity',
  },
  {
    title: <FormattedMessage id="HoldQuantity" />,
    width: '20px',
    dataIndex: 'holdedQuantity',
    key: 'holdedQuantity',
  },
  {
    title: <FormattedMessage id="RejectedQuantity" />,
    width: '20px',
    dataIndex: 'rejectedQuantity',
    key: 'rejectedQuantity',
  },
  /*{
    title: <FormattedMessage id="Action" />,
    width: '40px',
    key: 'action',
    render: (record) => {
      return <Button type='primary'
        shape="circle"
        icon={<DownloadOutlined />}
        onClick={() => handleDownload(record.inspectionHistory)}
        disabled={record?.inspectionHistory[record.inspectionHistory.length-1]?.content===null}
      />
    }
  }*/
  
];
  
  const expandedRowRender = (nestedData) => (
    <Table columns={getNestedColumns} dataSource={nestedData} pagination={false} />
  );

  const handleDownload = async (val) => {
    const recent = val[val.length-1]
    const content=JSON.parse(recent?.content)
    if (content?.acceptKey) {
      await redcrescentService.downloadFile(recent?.grnId,content?.acceptKey,fileFormat)
    }
    if (content?.rejectKey) {
      await redcrescentService.downloadFile(recent?.grnId,content?.rejectKey,fileFormat)
    }
  }

  return (
    <Table
      pagination={false}
      columns={getTablecolumns}
      dataSource={resultSet}
      rowKey={(record) => record.id}
      expandedRowRender={(record) => expandedRowRender(resultSet)}
    />
  );
};

export default InfoModal;

import React, { useState } from 'react';
import { Modal, Form, Button, Radio, Input, InputNumber, Space, DatePicker } from 'antd';
import moment from 'moment';
import { PlusOutlined } from '@ant-design/icons';
import { Row, Col, Select, Divider, message } from 'antd/es';
import { useIntl, FormattedMessage, formatMessage, getLocale } from 'umi';
import redcrescentService from '../../services/redcrescent.service';
import styles from './styles';

const UpdateModal: React.FC<any> = (props) => {
  const { updateModalData, status } = props;
  const [form] = Form.useForm();
  const [formSubmit, setFormSubmit] = useState(false);
  const [loading, setLoading] = useState(false);
  const [dataArr, setdataArr] = useState([0]);
  const [inputList, setInputList] = useState([]);
  //  const [inputList, setInputList] = useState([]);
  const dateFormat = 'YYYY-MM-DD';
  const onCancel = () => {
    setdataArr([0]);
    props.handleCancel();
  };
  const onFinish = (values) => {
    let data = [];
    let inValidQty = false;
    let dataVal = [];
    for (var i = 0; i < inputList.length; i++) {
      if (inputList[i].receivedQuantity < 1) {
        inValidQty = true;
      }
      data.push({
        batchNumber: inputList[i].batchNumber,
        expiryDate: moment(inputList[i].expiryDate).format(dateFormat),
        receivedQuantity: inputList[i].receivedQuantity,
      });

      dataVal.push(inputList[i].receivedQuantity);
    }

    var sum = dataVal.reduce(function (a, b) {
      return a + b;
    }, 0);

    if (inValidQty) {
      message.error(useIntl().formatMessage({ id: 'ShouldBeMoreThan0' }));
    } else {
      if (sum == updateModalData.receivedQuantity) {
        if (data) {
          redcrescentService.updateMultitpleBatch(updateModalData.id, data).then(() => {
            handleCancel();
            props.getOrder();
            setLoading(false);
            setFormSubmit(false);
          });
          setFormSubmit(true);
          form.resetFields();
        }
      } else {
        message.error(
          formatMessage({ id: 'MustBeEqualTo' }) + ' ' + updateModalData.receivedQuantity,
        );
      }
    }
  };
  const disabledPastDates = (current: any) => {
    // Can not select days after today
    return current && current < moment().add(1, 'days');
  };
  const handleCancel = () => {
    props.handleCancel();
    form.resetFields();
  };
  const handleInputChange = (e, index) => {
    const { name, value } = e.target;
    let arr = [...inputList];
    let indexData = inputList.findIndex((x) => x.index == index);

    let obj = {};
    if (indexData > -1) {
      obj = { ...inputList[indexData] };
    } else {
      obj.index = index;
    }

    obj[name] = value;
    if (indexData > -1) {
      arr[indexData] = obj;
    } else {
      arr.push(obj);
    }
    setInputList(arr);

    // let obj = {};
    // //obj.index = index;

    // obj[name] = value;
    // const list = inputList;

    // list[index][name] = value;
    // setInputList({list});
  };

  const today = new Date();
  const dd = String(today.getDate()).padStart(2, '0');
  const mm = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
  const yyyy = today.getFullYear();
  const _date = `${yyyy}-${mm}-${dd}`;
  const obj = [];
  return (
    <Modal
      title={
        updateModalData && updateModalData.product
          ? getLocale() === 'ar-EG'
            ? updateModalData.product.arabicDescription +
              ` (${useIntl().formatMessage({ id: `ReceivedQuantity` })} ${
                updateModalData.receivedQuantity
              }) `
            : updateModalData.product.description +
              ` (${useIntl().formatMessage({ id: `ReceivedQuantity` })} ${
                updateModalData.receivedQuantity
              }) `
          : null
      }
      visible={props.isVisible}
      footer={null}
      afterClose={() => handleCancel()}
      closable={false}
      destroyOnClose
    >
      <>
        {/* <Spin className={styles.loader} spinning={isLoading} size="large" /> */}
        <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
          {dataArr &&
            dataArr.map((v, i) => {
              return (
                <>
                  <div style={{ marginTop: '5px' }}>
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        padding: '0px 42px',
                      }}
                    ></div>
                    <Row gutter={[24, 24]} align="middle">
                      <Col span={24}>
                        <Form.Item
                          label={useIntl().formatMessage({ id: 'BatchNumber' })}
                          name={`batches_${i}`}
                          rules={[
                            {
                              required: true,
                              message: useIntl().formatMessage({ id: 'MissingBatchNumber' }),
                            },
                          ]}
                        >
                          <Input
                            name="batches"
                            style={{ width: '100%' }}
                            onChange={(value) =>
                              handleInputChange(
                                { target: { value: value.target.value, name: 'batchNumber' } },
                                i,
                              )
                            }
                          />
                        </Form.Item>
                      </Col>
                      <Col span={24}>
                        <Form.Item
                          label={useIntl().formatMessage({ id: 'ExpiryDate' })}
                          name={`expiryDate_${i}`}
                          rules={[
                            {
                              required: true,
                              message: useIntl().formatMessage({ id: 'ExpiryDate' }),
                            },
                          ]}
                          // initialValue={updateModalData && moment(updateModalData?.expiryDate, dateFormat)}
                        >
                          <DatePicker
                            format={dateFormat}
                            disabledDate={disabledPastDates}
                            onChange={(value) =>
                              handleInputChange({ target: { value, name: 'expiryDate' } }, i)
                            }
                            style={{ width: '100%' }}
                          />
                        </Form.Item>
                      </Col>
                      <Col span={24}>
                        <Form.Item
                          label={useIntl().formatMessage({ id: 'ReceivedQuantity' })}
                          name={`receivedQuantity_${i}`}
                          rules={[
                            {
                              required: true,
                              type: 'number',
                              min: 1,
                              message: useIntl().formatMessage({ id: 'ShouldBeMoreThan0' }),
                            },
                          ]}
                        >
                          <InputNumber
                            placeholder={useIntl().formatMessage({ id: 'quantity' })}
                            precision={0}
                            style={{ width: '100%' }}
                            onChange={(value) =>
                              handleInputChange({ target: { value, name: 'receivedQuantity' } }, i)
                            }
                          />
                        </Form.Item>
                      </Col>
                    </Row>
                  </div>
                </>
              );
            })}
          <Button
            className={styles.btnText}
            type="dashed"
            style={{ marginBottom: '20px' }}
            onClick={() => {
              let incObj = obj.length;
              obj.push(incObj);
              setdataArr([...dataArr, obj]);
            }}
            block
          >
            <PlusOutlined /> {useIntl().formatMessage({ id: 'Add' })}
          </Button>
          <Row gutter={[24, 24]}>
            <Col flex={1}>
              <Form.Item>
                <Button
                  disabled={formSubmit}
                  type="primary"
                  htmlType="submit"
                  block
                  loading={formSubmit}
                >
                  {useIntl().formatMessage({ id: 'Update' })}
                </Button>
              </Form.Item>
            </Col>
            <Col flex={1}>
              <Form.Item>
                <Button onClick={onCancel} block>
                  {useIntl().formatMessage({ id: 'Cancel' })}
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </>
    </Modal>
  );
};

export default UpdateModal;

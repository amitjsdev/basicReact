import React from 'react';
import { Modal, Button, Tooltip } from 'antd';
import { CheckOutlined } from '@ant-design/icons';
import { DeleteOutlined } from '@ant-design/icons';
import redCrescentService from '../../services/redcrescent.service';
import { FormattedMessage, formatMessage } from 'umi';
class ApproveRejectModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      loading: false,
    };
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleOk = async (e) => {
    const { data } = this.props;
    const { status } = this.props;
    this.setState({
      loading: true,
    });
    if (!!this.props.approveManager) {
      const statusVal =
        this.props.approveManager === 'committeeAdministrativeMemberApproved'
          ? { committeeAdministrativeMemberApproved: true }
          : { committeeHeadManagerApproved: true, status: 'approve' };
      await redCrescentService.createInspectionApproval(statusVal, data.id);
      this.setState({
        visible: false,
        loading: false,
      });
    }

    this.props.getOrder();
  };

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  };

  render() {
    const { visible, loading } = this.state;
    const { status } = this.props;
    return (
      <>
        <Tooltip
          title={
            status === 'rejected' ? (
              <FormattedMessage id="Reject" />
            ) : status === 'committeeAdministrativeMemberApproved' ? (
              <FormattedMessage id="CommitteeAdministratorMemberApproval" />
            ) : status === 'committeeHeadManagerApproved' ? (
              <FormattedMessage id="CommitteeHeadManagerApproval" />
            ) : status === 'AlreadyApproved' ? (
              <FormattedMessage id="AlreadyApproved" />
            ) : (
              <FormattedMessage id="Approve" />
            )
          }
        >
          <Button
            type="primary"
            style={this.props.style}
            shape="circle"
            icon={status === 'rejected' ? <DeleteOutlined /> : <CheckOutlined />}
            onClick={this.showModal}
            disabled={this.props.disabled === true}
          />
        </Tooltip>
        <Modal
          title={formatMessage({ id: 'Recieving' })}
          visible={visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          maskClosable={false}
          footer={[
            <Button key="back" onClick={this.handleCancel} disabled={loading}>
              {<FormattedMessage id="Cancel" />}
            </Button>,
            <Button key="submit" type="primary" loading={loading} onClick={this.handleOk}>
              {<FormattedMessage id="Submit" />}
            </Button>,
          ]}
        >
          <span>
            {status === 'rejected' ? (
              <FormattedMessage id="DoYouRejectTheTransferRequest" />
            ) : (
              <FormattedMessage id="DoYouWantToApproveTheRequest" />
            )}
          </span>
        </Modal>
      </>
    );
  }
}

export default ApproveRejectModal;

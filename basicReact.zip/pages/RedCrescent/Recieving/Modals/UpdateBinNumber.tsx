import React, { useState, useEffect } from 'react';
import { Modal, Form, Button, Input, InputNumber, Select, message, Cascader } from 'antd';
import { PlusOutlined } from '@ant-design/icons';

import { Row, Col } from 'antd/es';
import { useIntl, formatMessage, getLocale } from 'umi';
import redcrescentService from '../../services/redcrescent.service';
import { LabTypes,RecivingStatues } from '@/services/Constants';
import styles from './index.less';
const { Option } = Select;

const StatusModal: React.FC<any> = (props) => {
  const { binNumberModalData } = props;
  const [form] = Form.useForm();
  const [formSubmit, setFormSubmit] = useState(false);
  const [loading, setLoading] = useState(false);
  const [dataArr, setdataArr] = useState([[]]);
  const [warehouse, setWarehouse] = useState([]);
  const [data, setData] = useState([]);
  const [subWarehouses, setsubWarehouses] = useState([]);
  const [quantity, setQuantity] = useState([]);
  const { TextArea } = Input;
  useEffect(() => {
    redcrescentService.getWareHouses('medicalredcrescent',props.locationId).then((data) => {
      const d = data.filter((item) => item.locationId == props.locationId);
    setWarehouse(d);
    
    });
  
  }, [binNumberModalData]);

  const onFinish = async(values) => {
    const dataVal = [];
    const qtyVal = data.find((qty) => qty.quantity);
    for (let i = 0; i < data.length; i++) {
      dataVal.push(data[i].quantity);
    }
    var sum = dataVal.reduce(function (a, b) {
      return a + b;
    }, 0);
    let totalQty = binNumberModalData.acceptedQuantity;
    if (sum == totalQty) {
      setFormSubmit(true);
      let formVal = [...data];
      formVal.forEach(function (v) {
        delete v.index;
      });
      let itemData ;
      if(binNumberModalData.labType === "nonmedicalredcrescent"){
        itemData ={
          orderItemId: binNumberModalData.orderItemId,
          batched:  true,
          locators: formVal,
        }

        }else{
          itemData =   {locators: formVal}
        }
  //let locators = {...formVal};
      redcrescentService.updateBinNumber(binNumberModalData.id, itemData).then(() => {
        handleCancel();
        setLoading(false);
        setFormSubmit(false);
      });
      if(sum===totalQty){
        await redcrescentService.updateBatch(binNumberModalData.id, { status: 'completed' })
      }
      props.changeStatus({ status: RecivingStatues.FINAL, isApproved: true });
    } else {
      message.error(formatMessage({ id: 'MustBeEqualTo' }) + ' ' + binNumberModalData.acceptedQuantity);
    }
  };

  const handleCancel = () => {
    props.handleCancel();
    form.resetFields();
    setdataArr([[]]);
    setData([]);
  };
  const handleChange = (value, index, type) => {
    
    let arr = [...data];
    let indexData = data.findIndex((x) => x.index == index);
    let obj = {};
    if (indexData > -1) {
      obj = { ...data[indexData]};
    } else {
      obj.index = index;
    }
    
    obj[type] = value;
if(type == "quantity"){
  obj[type] = value;
}else{
  obj["quantity"] = binNumberModalData && binNumberModalData.acceptedQuantity;
}
    if (indexData > -1) {
      arr[indexData] = obj;
    } else {
      arr.push(obj);
    }
    setData(arr);
    if (type === 'mainWarehouseId') {
      let sub = warehouse && warehouse.length > 0 && warehouse.find((item) => item.id == value);
      if (sub.subWarehouses && sub.subWarehouses.length > 0) {
        setsubWarehouses([...subWarehouses, { index, value: sub.subWarehouses }]);
      }
    }
  };
  return (
    <Modal
      title={
        binNumberModalData && binNumberModalData.product
          ? getLocale() === 'ar-EG'
            ? binNumberModalData.product.arabicDescription
            : binNumberModalData.product.description
          : null
      }
      visible={props.isVisible}
      footer={null}
      afterClose={() => handleCancel()}
      closable={false}
      destroyOnClose
    >
      <>
        <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
          {dataArr.map((item, index) => {
            return (
              <div style={{ marginTop: '5px' }} key={index}>
                <p>{useIntl().formatMessage({ id: `ReceivedQuantity` })} {binNumberModalData && binNumberModalData.receivedQuantity}</p>
                <Row gutter={[24, 24]} align="middle">
                  <Col span={24}>
                    <Form.Item
                      label={useIntl().formatMessage({ id: `WareHouse` })}
                      name={`WareHouse${index}`}
                      rules={[
                        {
                          required: true,
                          message: useIntl().formatMessage({ id: 'MissingWareHouse' }),
                        },
                      ]}
                    >
                      <Select
                        onChange={(value) => {
                          handleChange(value, index, 'mainWarehouseId');
                        }}
                      >
                        {warehouse &&
                          warehouse.length > 0 &&
                          warehouse.map((house) => {
                            return <Option value={house.id}>{house.name}</Option>; 
                          })}
                      </Select>
                    </Form.Item>
                  </Col>

                  {data.length > 0 &&
                    subWarehouses.length > 0 &&
                    data.find((x) => x.index == index && x.mainWarehouseId) &&
                    subWarehouses.find((item) => item.index == index) && (
                      <Col span={24}>
                        <Form.Item
                          label={useIntl().formatMessage({ id: `SubWareHouse` })}
                          name={`SubWareHouse${index}`}
                          rules={[
                            {
                              required: true,
                              message: useIntl().formatMessage({ id: 'MissingSubWareHouse' }),
                            },
                          ]}
                        >
                          <Select
                            onChange={(value) => {
                              handleChange(value, index, 'subWarehouseId');
                            }}
                          >
                            {subWarehouses && 
                              subWarehouses.length > 0 &&
                              subWarehouses.map((house) => {
                                if (house.index == index) {
                                  return house.value.map((item) => {
                                    return <Option value={item.id}>{item.name}</Option>;
                                  });
                                }
                              })}
                          </Select>
                        </Form.Item>
                      </Col>
                    )}

                  {data.length > 0 &&
                    data.find((x) => x.index == index && x.mainWarehouseId) &&<Col span={24}>
                    <Form.Item
                      label={useIntl().formatMessage({ id: 'LocatorID' })}
                      name={`binNumber${index}`}
                      rules={[
                        {
                          required: true,
                          message: useIntl().formatMessage({ id: 'PleaseEnterLocatorID' }),
                        },
                      ]}
                    >
                      <Input
                        style={{ width: '100%' }}
                        onChange={(value) => {
                          handleChange(value.target.value, index, 'locatorId');
                        }}
                      />
                    </Form.Item>
                  </Col>}
                </Row>
                <Col span={24}>
                  <Form.Item
                    label={useIntl().formatMessage({ id: 'Quantity' })}
                    name={`quantity${index}`}
                    initialValue={binNumberModalData && binNumberModalData.acceptedQuantity}
                    rules={[
                      {
                         required: true,
                        message: useIntl().formatMessage({ id: 'MissingQuantity' }),
                      },
                      {
                        type: 'number',
                        min: 1,
                        message: useIntl().formatMessage({id:'ShouldBeMoreThan0'}),
                      },
                    ]}
                  >
                    <InputNumber
                      value={binNumberModalData && binNumberModalData.receivedQuantity ? binNumberModalData.acceptedQuantity : dataArr[index]?.quantity}
                      placeholder={useIntl().formatMessage({ id: 'Quantity' })}
                      defaultValue={binNumberModalData && binNumberModalData.acceptedQuantity}
                      style={{ width: '100%' }}
                      onChange={(value) => {
                        handleChange(value, index, 'quantity');
                      }}
                    />
                  </Form.Item>
                </Col>
              </div>
            );
          })}
          <Button
            className={styles.btnText}
            type="dashed"
            onClick={() => {
              let arr = [...dataArr];
              arr.push([]);
              setdataArr(arr);
            }}
            block
          >
            <PlusOutlined /> {useIntl().formatMessage({ id: 'Add' })}
          </Button>
          <Row gutter={[24, 24]}>
            <Col flex={1}>
              <Form.Item>
                <Button disabled={formSubmit} type="primary" htmlType="submit" block loading={formSubmit}>
                  {useIntl().formatMessage({ id: 'Update' })}
                </Button>
              </Form.Item>
            </Col>
            <Col flex={1}>
              <Form.Item>
                <Button onClick={handleCancel} block>
                  {useIntl().formatMessage({ id: 'Cancel' })}
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </>
    </Modal>
  );
};

export default StatusModal;

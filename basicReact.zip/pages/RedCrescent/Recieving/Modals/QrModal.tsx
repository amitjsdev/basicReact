import React, { useEffect, useState } from 'react';
import { Modal, Form, Row, Col, Button } from 'antd';
import { useIntl } from 'umi';
import QRCode from 'qrcode.react';
import redcrescentService from '../../services/redcrescent.service';
import { LabTypes, RecivingStatues } from '@/services/Constants';
const QrModal: React.FC<any> = (props) => {
  const { downloadQrData, isVisible, labType } = props;
  const [resData, setResData] = useState('');

  
  const handleCancel = () => {
    props.handleCancel();
  };

  // useEffect(() => {
  //   async function fetchMyAPI(downloadQrData) {
  //     let filePdfName= 'pdf';
  //     if (Object.entries(downloadQrData).length > 0) {
        
  //       const content = JSON.parse(downloadQrData.content);
        
  //       const data = await redcrescentService.downloadQrCode(
  //         content.fileKey,
  //         content.fileName,
  //         filePdfName,
  //       );
        
  //       setResData(data);
  //     }
  //   }
  //   fetchMyAPI(downloadQrData);
  // }, [downloadQrData]);
  // const downloadQR = () => {
  //   const canvas = document.getElementById('123456');
  //   const pngUrl = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
  //   let downloadLink = document.createElement('a');
  //   downloadLink.href = pngUrl;
  //   downloadLink.download = '123456.png';
  //   document.body.appendChild(downloadLink);
  //   downloadLink.click();
  //   document.body.removeChild(downloadLink);
  // };

  const downloadQR = async () => {
    let filePdfName= 'pdf';
    const content = JSON.parse(downloadQrData.content);
    
    await redcrescentService.downloadQrCode(content.fileKey, content.fileName, filePdfName);
  };
  const moveToInspection = async () => {
  const  data = {
    status: 'quarantined'
  }
  if(labType === "nonmedicalredcrescent"){
    data.orderItemId =  props.downloadQrData.orderItemId;
    data.batched =  true;
  }
    await redcrescentService.updateBatch(downloadQrData.id, data);
    props.changeStatus({ status: RecivingStatues.INSPECTION, isApproved: true });
    props.handleCancel();
  };
  return (
    <Modal
      title={useIntl().formatMessage({ id: 'DownloadQR' })}
      visible={isVisible}
      footer={null}
      afterClose={handleCancel}
      closable={false}
      destroyOnClose
    >
      <Form>
        <Row gutter={[24, 24]} align="middle">
          {/* <ReactPDF file={{resData}} /> */}
          <Col span={24}>
          {/* <ReactPDF file="https://staging.labprox.com/api/1.0/download/b15d0b5a-4b4c-49a3-ac9c-2596a8397c70"/> 
       
            <Document 
        file="https://staging.labprox.com/api/1.0/download/b15d0b5a-4b4c-49a3-ac9c-2596a8397c70" 
      />  */}
            <QRCode
              id="123456"
              value={`${downloadQrData.qrcode}`}
              size={290}
              level={'H'}
              includeMargin={true}
            />{' '}
          </Col>
        </Row>
        <Row gutter={[24, 24]}>
          <Col flex={1}>
            <Form.Item>
              <Button type="primary" onClick={downloadQR}>
                {useIntl().formatMessage({ id: 'Download' })}
              </Button>
            </Form.Item>
          </Col>
          <Col flex={1}>
            <Form.Item>
              <Button type="primary" onClick={moveToInspection}>
                {useIntl().formatMessage({ id: 'MoveToInspection' })}
              </Button>
            </Form.Item>
          </Col>
          <Col flex={1}>
            <Form.Item>
              <Button onClick={handleCancel}>{useIntl().formatMessage({ id: 'Cancel' })}</Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </Modal>
  );
};

export default QrModal;

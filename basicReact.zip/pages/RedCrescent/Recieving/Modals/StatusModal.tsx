import React, { useState, useEffect } from 'react';
import { Modal, Form, Button, Input, InputNumber, Select, message, Typography } from 'antd';
import { LabTypes, RecivingStatues } from '@/services/Constants';
import styles from './index.less';
import { Row, Col } from 'antd/es';
import { useIntl, formatMessage, getLocale, FormattedMessage } from 'umi';
import redcrescentService from '../../services/redcrescent.service';

const { Option } = Select;

const StatusModal: React.FC<any> = (props) => {
  const { statusModalData, isVisible, labType } = props;
  const [form] = Form.useForm();
  const [formSubmit, setFormSubmit] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formBtn, setFormBtn] = useState('Update');
  const [total, setTotal] = useState('');
  const [quantity, setQuantity] = useState([]);
  const { TextArea } = Input;
  const { Text } = Typography;
  useEffect(() => {
    if (statusModalData) {
      let arr = [];
      let obj1 = {
        quantityItem:
          statusModalData.acceptedQuantity == null || statusModalData.acceptedQuantity == 0
            ? 0
            : statusModalData.acceptedQuantity,
        type: 'accepted',
      };
      let obj2 = {
        quantityItem:
          statusModalData.rejectedQuantity == null || statusModalData.rejectedQuantity == 0
            ? 0
            : statusModalData.rejectedQuantity,

        type: 'rejected',
      };
      let obj3 = {
        quantityItem:
          statusModalData.holdedQuantity == null || statusModalData.holdedQuantity == 0
            ? 0
            : statusModalData.holdedQuantity,
        type: 'holded',
      };

      arr.push(obj1);
      arr.push(obj2);
      arr.push(obj3);
      setQuantity(arr);
    }
  }, [statusModalData, isVisible]);
  const onCancel = () => {
    props.handleCancel();
    setFormBtn('Update');
  };

  const onFinish = (values) => {
    if (quantity && quantity.length > 0) {

      if (total === statusModalData.receivedQuantity) {
        const formVal = {
          batchNumber: values.batches,
        };
        if (labType === "nonmedicalredcrescent") {
          formVal.orderItemId = statusModalData.orderItem.id;
          formVal.batched = true;
        }
        let holdQty = false;
        let approveQty = false;
        let rejectQty = false;

        quantity.map((item) => {

          if (item.type === 'holded') {
            formVal.holdedQuantity = item.quantityItem;
            formVal.holdReason = values['Hold reason'];
            if (item.quantityItem > statusModalData.holdedQuantity || item.quantityItem < 0 || item.quantityItem == null) {
              holdQty = true;
            }
          } else if (item.type === 'rejected') {
            if (item.quantityItem < statusModalData.rejectedQuantity) {
              rejectQty = true;

            }
            if (item.quantityItem == null) {
              formVal.rejectedQuantity = 0;
            }
            else {
              formVal.rejectedQuantity = item.quantityItem;
            }
            formVal.rejectReason = values['Reject reason'];

          } else {
            if (item.quantityItem < statusModalData.acceptedQuantity) {
              approveQty = true;
            }
            if (item.quantityItem == null) {
              formVal.acceptedQuantity = 0;
            }
            else {
              formVal.acceptedQuantity = item.quantityItem;
            }

            formVal.acceptReason = values['Approve reason'];
          }
        });

        if (holdQty) {
          message.error(
            formatMessage({ id: 'HoldQuantity' }) + formatMessage({ id: 'CannotBeNegativeOrMoreThan' }) +
            ' ' +
            (statusModalData.receivedQuantity == undefined ? 0 : statusModalData.holdedQuantity),
          );
        } else if (approveQty) {

          message.error(formatMessage({ id: 'ApproveQuanity' }) + formatMessage({ id: 'CannotBeLessThan' }) +
            ' ' +
            (statusModalData.acceptedQuantity));
        } else if (rejectQty) {
          message.error(formatMessage({ id: 'RejectQuantity' }) + formatMessage({ id: 'CannotBeLessThan' }) +
            ' ' +
            (statusModalData.rejectedQuantity));
        }
        else {
          setFormSubmit(true);
          props.changeStatus({ status: RecivingStatues.INSPECTION, isApproved: true });

          redcrescentService.updateBatch(statusModalData.id, formVal).then(() => {
            handleCancel();
            props.getOrder();
            setLoading(false);
            setFormSubmit(false);
            setQuantity([]);
          });
        }
      } else {
        message.error(
          formatMessage({ id: 'SumOfQuantitiesShouldBeEqualToRecievedQuanity' }) +
          ' ' +
          (statusModalData.receivedQuantity == undefined ? 0 : statusModalData.holdedQuantity),
        );
      }
    } else {
      message.error(formatMessage({ id: 'PleaseEnterQuantity' }));
    }
  };


  const handleQuantityChange = (value, dataType) => {
    let arr = [...quantity];
    let index = quantity.findIndex((item) => item.type == dataType);
    if (index === -1) {
      arr.push({ quantityItem: value, type: dataType });
    } else {
      let obj = { quantityItem: value, type: dataType };
      arr[index] = obj;
    }
    let totalVal = 0;
    let holdVal = 0;

    arr.map((data) => {
      if (data.type !== 'holded') {
        totalVal = totalVal + data.quantityItem;
      }

    });
    holdVal = statusModalData.receivedQuantity - totalVal
    totalVal += holdVal;
    const finalArr = arr.map(ele => {
      if (ele.type === 'holded') {

        return { quantityItem: holdVal, type: ele.type }
      } else {
        return ele
      }
    })


    let mainQty = statusModalData.receivedQuantity;
    // if (totalVal - holdVal === mainQty) {
    //   setFormBtn('UpdateAndMoveToFinal');
    // } else {
    //   setFormBtn('Update');
    // }
    setTotal(totalVal);
    setQuantity(finalArr);
  };
  const handleCancel = () => {
    props.handleCancel();
    form.resetFields();
    setQuantity([]);
  };

  const status = [
    { value: 'accepted', label: 'Approve' },
    { value: 'rejected', label: 'Reject' },
    { value: 'holded', label: 'Hold' },
  ];

  return (
    <Modal
      title={
        statusModalData && statusModalData.product
          ? getLocale() === 'ar-EG'
            ? statusModalData.product.arabicDescription
            : statusModalData.product.description
          : null
      }
      visible={props.isVisible}
      footer={null}
      afterClose={() => handleCancel()}
      closable={false}
      destroyOnClose
    >
      <>
        <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
          {!window.location.href.includes('non-medical') && (
            <Row gutter={[24, 24]} align="middle">
              <Col span={24}>
                <span>
                  <FormattedMessage id="BatchNumber" />
                </span>
                <Input
                  name="batches"
                  value={statusModalData && statusModalData.batchNumber}
                  defaultValue={
                    statusModalData && statusModalData.batchNumber
                      ? statusModalData.batchNumber
                      : null
                  }
                  style={{ width: '100%' }}
                />
              </Col>
            </Row>
          )}
          {<Text className={styles.textMark} >
            {useIntl().formatMessage({ id: `ReceivedQuantity` })}  : {statusModalData && statusModalData.receivedQuantity}
          </Text>}

          {status &&
            status.map((data: any, index) => {
              let disabled = false
              if (data.value === 'holded') {
                disabled = true
              }
              return (
                <>
                  <div style={{ marginTop: '5px' }}>
                    <Row gutter={[24, 24]} align="middle">
                      <Col span={24}>
                        <Form.Item
                          label={useIntl().formatMessage({ id: `${data.label}Quantity` })}
                          name={`${data.label} quantity`}
                          rules={[
                            {
                              type: 'number',
                              min: 0,
                              message: useIntl().formatMessage({
                                id: 'QuantityShouldBeNumericAndGreaterThan0',
                              }),
                            },
                          ]}
                        >
                          <InputNumber
                            precision={0}
                            disabled={disabled}
                            placeholder={useIntl().formatMessage({ id: `${data.value}Quantity` })}
                            value={
                              quantity && quantity.length > 0 && !isNaN(quantity[index]?.quantityItem)
                                ? parseInt(quantity[index]?.quantityItem)
                                : statusModalData && parseInt(statusModalData[`${data.value}Quantity`])
                            }
                            precision={0}
                            style={{ width: '100%' }}
                            onChange={(value) => handleQuantityChange(value, data.value)}

                          />
                          {quantity &&
                            quantity.length > 0 &&
                            quantity[index]?.type === 'holded' &&
                            (quantity[index]?.quantityItem >
                              statusModalData[`${data.value}Quantity`] ||
                              quantity[index]?.quantityItem < 0)
                            && (
                              <p style={{ color: 'red', height: '20px' }}>
                                {
                                  (statusModalData[`${data.value}Quantity`] === null
                                    ? useIntl().formatMessage({ id: 'CannotBeNegative' }) +
                                    ' ' + 0
                                    : useIntl().formatMessage({ id: 'CannotBeNegativeOrMoreThanQuantity' }) +
                                    ' ' + statusModalData[`${data.value}Quantity`])}
                              </p>
                            )}
                          {quantity &&
                            quantity.length > 0 &&
                            !(quantity[index]?.type === 'holded') &&
                            quantity[index]?.quantityItem <
                            statusModalData[`${data.value}Quantity`] && (
                              <p style={{ color: 'red', height: '20px' }}>
                                {useIntl().formatMessage({ id: 'CannotBeLessThanQuantity' }) +
                                  ' ' +
                                  statusModalData[`${data.value}Quantity`]}
                              </p>
                            )}
                        </Form.Item>
                      </Col>
                      <Col span={24}>
                        <Form.Item
                          label={useIntl().formatMessage({ id: `${data.label}Reason` })}
                          name={`${data.label} reason`}
                          rules={[
                            {
                              // required: quantity.findIndex((item) => item.type == data.value) > -1,
                              required: quantity.find((item) => item.type == data.value)
                                ? true
                                : false,
                              message: useIntl().formatMessage({ id: 'MissingReason' }),
                            },
                          ]}
                        >
                          <TextArea
                            rows={4}
                            placeholder={formatMessage({ id: 'Note' })}
                          // onChange={(event) => setFormNote(event.target.value)}
                          />
                        </Form.Item>
                      </Col>
                      {/* )} */}
                    </Row>
                  </div>
                </>
              );
            })}
          <Row gutter={[24, 24]}>
            <Col flex={1}>
              <Form.Item>
                <Button
                  disabled={formSubmit}
                  type="primary"
                  htmlType="submit"
                  block
                  loading={formSubmit}
                >
                  {useIntl().formatMessage({ id: formBtn })}
                </Button>
              </Form.Item>
            </Col>
            <Col flex={1}>
              <Form.Item>
                <Button onClick={onCancel} block>
                  {useIntl().formatMessage({ id: 'Cancel' })}
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </>
    </Modal >
  );
};

export default StatusModal;

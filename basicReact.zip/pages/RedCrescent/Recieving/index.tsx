import { PageContainer } from '@ant-design/pro-layout';
import React from 'react';
import { Button, Tabs, Tooltip, Radio } from 'antd';
import moment from 'moment';

import { LabTypes, RecivingStatues, ModuleTypes } from '@/services/Constants';
import RecievingTable from './RecievingTable';
import redcrescentService from '../services/redcrescent.service';

import styles from './index.less';
import { FormattedMessage, getLocale, useModel, useAccess } from 'umi';

interface PropsType {
  currentUser: App.CurrentUser;
  labType: App.LabType;
  access: any;
  dispatch: any;
}

const { TabPane } = Tabs;
class EditableTable extends React.Component<PropsType, any> {
  redcrescentProfile: App.Module | undefined;

  filterValueMap = {
    initial: { status: RecivingStatues.INITIAL, isApproved: false },
    inspection: { status: RecivingStatues.INSPECTION, isApproved: true },
    approve: { status: RecivingStatues.FINAL, isApproved: true },
  };
  constructor(props) {
    super(props);
    let moduleData = window.location.href.includes('non-medical')
      ? ModuleTypes.NON_MRC
      : ModuleTypes.MRC;
    const { currentUser }: App.InitialStateType = props;
    this.redcrescentProfile = currentUser?.modules.find((module) => {
      return module.name === moduleData;
    });
    this.state = {
      selectedLabType: '',
      status: 'initial',
      isApproved: false,
      labs: [],
      locationId: '',
      dataSource: [],
    };
  }

  async componentDidMount() {
    // Make a request for a user with a given ID
    var labtype = window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC;
    const customlabs = (await redcrescentService.getLocations(LabTypes.MRC)) || [];

    let labs = [...customlabs];
    if (!this.props.access.canReadAllRedCrescentInventories(labtype)) {
      labs = labs.filter((l) => this.redcrescentProfile?.location.code === l.code);
    }
    // const lab = labs.filter((l) => this.redcrescentProfile?.locationName === l.code)

    this.setState({
      labs: labs,
      selectedLabType: labtype,
    });
    this.changeLocation(labs[0]?.id);
  }

  changeLocation = async (key) => {
    this.setState({ locationId: key }, () => this.getOrder());
  };

  refreshOrder() {
    this.getOrder();
  }

  changeStatus = async (filter: { status: string; isApproved: boolean | null }) => {
    this.setState({ ...filter, currentBrandName: null }, () => this.getOrder());
  };

  async getOrder() {
    this.setState({ dataSource: [] });
    const { status, isApproved, locationId } = this.state;
    let currentStatus =
      status === 'initial' ? 'created' : status === 'inspection' ? 'quarantined' : 'approve';
    let isApprovedStatus = isApproved;
    const locId = parseInt(locationId, 10) === 0 ? '' : locationId; // Check if its All locations (All tab key === 0)
    const _orderData = await redcrescentService.getRecieving(
      this.state.selectedLabType,
      locId,
      currentStatus,
    );

    this.setState({ dataSource: _orderData });
  }
  Filters = () => {
    return (
      <>
        <Radio.Group
          value={this.state.status}
          buttonStyle="solid"
          onChange={(e) => this.changeStatus(this.filterValueMap[e.target.value])}
        >
          <Radio.Button value="initial">{<FormattedMessage id="Initial" />}</Radio.Button>
          <Radio.Button value="inspection">{<FormattedMessage id="Inspection" />}</Radio.Button>
          <Radio.Button value="approve">{<FormattedMessage id="Final" />}</Radio.Button>
        </Radio.Group>
      </>
    );
  };

  render() {
    const { labs, dataSource, status } = this.state;
    return (
      <PageContainer content="" className={styles.main}>
        <div className={styles.divContain}>
          <Tabs
            defaultActiveKey={labs[0]?.id}
            onChange={this.changeLocation}
            tabBarExtraContent={this.Filters()}
          >
            {labs.map((item, i) => (
              <TabPane
                tab={
                  <Tooltip title={getLocale().includes('en') ? item.name : item.arabicName}>
                    {item.code}
                  </Tooltip>
                }
                key={item.id}
              />
            ))}
          </Tabs>
          <RecievingTable
            data={dataSource}
            status={status}
            getOrder={this.getOrder.bind(this)}
            locationId={this.state.locationId}
            labtype={this.state.selectedLabType}
            changeStatus={this.changeStatus}
            redCrescentProfile={this.redcrescentProfile}
          />
        </div>
        <div
          style={{
            paddingTop: 100,
            textAlign: 'center',
          }}
        >
          {/* <Spin spinning={loading} size="large" /> */}
        </div>
      </PageContainer>
    );
  }
}

const EditableTableWrapper: React.FC<any> = (props) => {
  const { initialState } = useModel('@@initialState');
  const access = useAccess();
  return <EditableTable {...props} currentUser={initialState?.currentUser} access={access} />;
};
export default EditableTableWrapper;

// export default () => (
//   <div className={styles.container}>
//     <div id="components-table-demo-edit-cell">
//       <EditableTable />
//     </div>
//   </div>
// );

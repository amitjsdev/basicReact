import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Spin } from 'antd';
import { Chart, Axis, Tooltip, Geom, Coord, Legend } from 'bizcharts';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';


const stackedChartData = (resultSet) => {
  const data = resultSet
    .pivot()
    .map(({ xValues, yValuesArray }) =>
      yValuesArray.map(([yValues, m]) => ({
        x: resultSet.axisValuesString(xValues, ', '),
        color: resultSet.axisValuesString(yValues, ', '),
        measure: m && Number.parseFloat(m),
      })),
    )
    .reduce((a, b) => a.concat(b), []);

  return data;
};

const scale = { x: { tickCount: 20 } };
const label = {
  // rotate: Math.PI / 3,
  autoHide: false,
  style: {
    fill: '#ffffff',
    color: '#ffffff',
  },

  formatter(text, item, index) {
    const arr = text.split(' ');
    return `${arr[0]}...`;
  },
};

const color = ['color', ['#753BBD']];
const barRender = ({ resultSet }) => (
  <Chart scale={scale} data={stackedChartData(resultSet)} autoFit>
    <Axis name="x" label={false} />
    <Axis name="measure" />
    <Tooltip />
    <Geom type="interval" position="x*measure" color={color} />
    <Legend visible={false} />
  </Chart>
);

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) =>
  (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
  (error && error.toString()) || <Spin />;

const ChartRenderer = (props) => {
  const filters = [
    // { dimension: props.labType + '.consumableDays', operator: 'lte', values: ['80'] },
    // {
    //   dimension: 'Locations.labType',
    //   operator: 'equals',
    //   values: [props.labType],
    // },
  ];
  if (props.categoryFilter !== 'All') {
    filters.push({
      dimension: 'Products.category',
      operator: 'equals',
      values: [props.categoryFilter],
    });
  } else {
    if (props.labType === 'MedicalRedCrescentInvenories') {
      filters.push({
        dimension: 'Products.category',
        operator: 'equals',
        values: ['Medicines'],
      });
    } else {
      filters.push({
        dimension: 'Products.category',
        operator: 'equals',
        values: ['Transportation'],
      });
    }
  }

  if (props.location !== 'All locations') {
    filters.push({ dimension: 'Locations.code', operator: 'equals', values: [props.location] });
  }

  return (
    <QueryRenderer
      query={{
        measures: [props.labType + '.consumableDays'],
        dimensions: props.dimensions, // ["Products.description"],
        timeDimensions: [],
        segments: [props.labType + '.saneProducts'],
        order: { [props.labType + '.consumableDays']: 'asc' },
        filters,
      }}
      cubejsApi={cubejsApi}
      render={renderChart(barRender, {
        x: [],
        y: ['measures'],
        joinDateRange: false,
        fillMissingDates: true,
      })}
    />
  );
};

export default ChartRenderer;

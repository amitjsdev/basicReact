import React, { useEffect } from 'react';
import { Select, Cascader } from 'antd';
import {formatMessage } from 'umi';
const TypeFilter = (props) => (
    <Select defaultValue='medicalredcrescent' style={{ width: '215px' }} onChange={props.onChange}>
      <Select.Option key="medicalredcrescent" value="medicalredcrescent">
      {formatMessage({ id: 'Medical' })}  
      </Select.Option>
      <Select.Option key="nonmedicalredcrescent" value="nonmedicalredcrescent">
      {formatMessage({ id: 'NonMedical' })} 
      </Select.Option>
    </Select>
  );

  export default TypeFilter;
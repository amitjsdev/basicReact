import React from 'react';
import { Gauge } from '@ant-design/charts';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';

import { Spin } from 'antd';
import styles from './index.less';

const gaugeData = {
  min: 15,
  max: 80,
  value: 61,
};

const gaugeColors = {
  safeStock: '#27a29e',
  nearOos: '#E38F3C',
  oos: '#E33C3C',
  other: '#753BBD',
};

const AvgDayStockGauge: React.FC = (props) => {
  const { value } = props;
  const config = {
    // renderer: 'svg',
    autoFit: true,
    // height: 200,
    min: gaugeData.min / 100,
    max: gaugeData.max / 100,
    percent: value / 100,
    range: {
      ticks: [0, 0.15, 0.3, 0.8, 1, 100],
      color: [
        gaugeColors.oos,
        gaugeColors.nearOos,
        gaugeColors.safeStock,
        gaugeColors.other,
        gaugeColors.other,
      ],
    },
    axis: {
      label: {
        formatter(v: string) {
          return Number(v) * 100;
        },
      },
    },
    statistic: {
      content: {
        formatter: ({ percent }) => `${(percent * 100)?.toFixed(2)}`,
        style: {
          fill: '#ffffff',
          textAlign: 'center',
          fontWeight: 500,
          fontSize: 24,
        },
      },
    },
  };
  return <Gauge className={props.className} {...config} />;
};

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint
const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

// CubeJS
const cubeQueryRender = (props) => {
  let filters: any[] = [
    // {
    //   dimension: 'Locations.labType',
    //   operator: 'equals',
    //   values: [props.labType],
    // },
  ];
  if (props.location && props.location !== 'All locations') {
    filters.push({ dimension: 'Locations.code', operator: 'equals', values: [props.location] });
  }

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: [props.labType + '.consumableDays'],
      timeDimensions: [],
      filters,
      order: {},
    },
    {
      cubejsApi,
    },
  );

  if (isLoading || props.location === '') {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const dataSource = resultSet.tablePivot();
  const cssClasses = `${styles.fixValue} ${styles.fixAxisLine} ${styles.fixGridLines}`;
  const value: number = dataSource[0][props.labType + '.consumableDays'] as number;
  const roundedValue: number = value ? value?.toFixed(2) : 0;
  return <AvgDayStockGauge className={cssClasses} value={roundedValue} />;
};

export default cubeQueryRender;

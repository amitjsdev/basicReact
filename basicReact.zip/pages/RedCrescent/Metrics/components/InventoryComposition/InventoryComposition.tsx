import React, { useState } from 'react';
import { Pie } from '@ant-design/charts';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';
import { DonutChart } from 'bizcharts';

import { Empty, Spin } from 'antd';
import styles from './index.less';

const colors = {
  safeStock: '#27a29e',
  nearOos: '#E38F3C',
  oos: '#E33C3C',
  os: '#753BBD',
};

enum InventoryType {
  'MedicalRedCrescentInvenories.ssInventory' = 'Safe stock',
  'MedicalRedCrescentInvenories.noosInventory' = 'Near OOS',
  'MedicalRedCrescentInvenories.oosInventory' = 'OOS',
  'MedicalRedCrescentInvenories.osInventory' = 'OS',
  'NonMedicalRedCrescentInvenories.ssInventory' = 'Safe stock',
  'NonMedicalRedCrescentInvenories.noosInventory' = 'Near OOS',
  'NonMedicalRedCrescentInvenories.oosInventory' = 'OOS',
  'NonMedicalRedCrescentInvenories.osInventory' = 'OS',
}

// CubeJS
const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint
const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

// CubeJS
const cubeQueryRender = (props) => {
  let filters = [
    //   {
    //   dimension: 'Locations.labType', operator: 'equals', values: [props.labType]
    // }
  ];

  if (props.location && props.location !== 'All locations') {
    filters.push({ dimension: 'Locations.code', operator: 'equals', values: [props.location] });
  }
  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: [
        `${props.labType}.oosInventory`,
        `${props.labType}.noosInventory`,
        `${props.labType}.ssInventory`,
        `${props.labType}.osInventory`,
        `${props.labType}.count`,
      ],
      timeDimensions: [],
      filters,
      order: {},
    },
    {
      cubejsApi,
    },
  );

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const dataSource = resultSet.tablePivot();

  const pieData = Object.keys(dataSource[0])
    .filter((type) => type !== `${props.labType}.count`)
    .map((type) => {
      return {
        type: InventoryType[type],
        value: dataSource[0][type],
      };
    });

  return <InventoryCompositionPie data={pieData} />;
};

const InventoryCompositionPie: React.FC = (props) => {
  if (props.data.some((item) => item.value !== 0)) {
    return (
      <DonutChart
        radius={1}
        innerRadius={0.7}
        data={props.data}
        angleField="value"
        colorField="type"
        color={['#008755', '#C8102E', '#DC582A', '#009ACE', '#753BBD']}
        pieStyle={{
          stroke: 'transparent',
        }}
        label={{ visible: false }}
        statistic={{
          visible: true,
          totalLabel: '',
        }}
        tooltip={{
          visible: true,
        }}
      />
    );
  } else {
    return <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
  }
};

/* const InventoryComposition = () => {
  const chartData = cubeQueryRender();
  

  return <InventoryCompositionPie data={chartData} />
} */

export default cubeQueryRender;

import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Spin } from 'antd';
import { Chart, Axis, Tooltip, Geom, Coord, Legend } from 'bizcharts';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';

const stackedChartData = (resultSet) => {
  const data = resultSet
    .pivot()
    .map(({ xValues, yValuesArray }) =>
      yValuesArray.map(([yValues, m]) => ({
        x: resultSet.axisValuesString(xValues, ', '),
        color: resultSet.axisValuesString(yValues, ', '),
        measure: m && Number.parseFloat(m),
      })),
    )
    .reduce((a, b) => a.concat(b), []);

  return data;
};

const label = { style: { fill: '#7c7c7d' } };
const colors = ['#1DAD28', '#79D2DE', '#753BBD', '#E1BE4C', '#9971D0'];

const barRender = ({ resultSet }) => (
  <Chart
    scale={{ x: { tickCount: 8 } }}
    // height={240}
    data={stackedChartData(resultSet)}
    autoFit
    // renderer={'svg'}
  >
    <Axis name="x" label={false} />
    <Axis name="measure" label={label} />
    <Tooltip />
    {/* <Geom type="interval" position={`x*measure`} color="color" /> */}
    <Geom type="interval" position="x*measure" color={['x', colors]} />
  </Chart>
);

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) =>
  (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
  (error && error.toString()) || <Spin />;

const ChartRenderer = (props) => (
  <QueryRenderer
    query={{
      dimensions: props.dimensions, // ["Locations.name"],
      timeDimensions: [],
      measures: [props.labType+'.consumableDays'],
      order: {},
      filters: [
        // {
        //   dimension: 'Locations.labType',
        //   operator: 'equals',
        //   values: [props.labType],
        // },
      ],
    }}
    cubejsApi={cubejsApi}
    render={renderChart(barRender, {
      x: [],
      y: ['Locations.code', 'measures'],
      fillMissingDates: true,
      joinDateRange: false,
    })}
  />
);

export default ChartRenderer;

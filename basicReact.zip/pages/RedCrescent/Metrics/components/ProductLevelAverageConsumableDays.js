import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Spin, Row, Col, Statistic, Table } from 'antd';

const tableRender = ({ resultSet, pivotConfig }) => (
  <Table
    pagination={false}
    columns={resultSet.tableColumns(pivotConfig)}
    dataSource={resultSet.tablePivot(pivotConfig)}
  />
);

const API_URL = '';

const cubejsApi = cubejs(
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2MDE0NzEzNTMsImV4cCI6MTYwMTU1Nzc1M30.QMSw-JxgzZUQl0mJkfJTglifRU-J6_MC1Si9AG0sbqE',
  { apiUrl: `${API_URL}/cubejs-api/v1` },
);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) =>
  (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
  (error && error.toString()) || <Spin />;

const ChartRenderer = (props) => (
  <QueryRenderer
    query={{
      dimensions: props.dimension, // ["Products.description"],
      measures: ['Inventories.averageDailyDemand', 'Inventories.consumableDays'],
      timeDimensions: [
        {
          dimension: 'Inventories.createdat',
        },
      ],
      order: {
        'Inventories.averageDailyDemand': 'desc',
      },
      filters: [],
    }}
    cubejsApi={cubejsApi}
    render={renderChart(tableRender, {
      x: ['Products.description'],
      y: ['measures'],
      fillMissingDates: true,
      joinDateRange: false,
    })}
  />
);

export default ChartRenderer;

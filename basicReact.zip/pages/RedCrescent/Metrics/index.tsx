import { PageContainer } from '@ant-design/pro-layout';
import React, { useState, useEffect } from 'react';
import { Typography, List, Divider, Row, Col, Spin, Card, Select, Popover, Menu } from 'antd';
import LocationSelector from '@/components/LocationSelector';
import { InfoCircleOutlined } from '@ant-design/icons';
import styles from './index.less';
import AvailableQuantity from './components/AvailableQuantity';
import AverageConsumableDays from './components/AverageConsumableDays';
import ItemLevelConsumableDays from './components/ItemLevelConsumableDays';
import ProductLevelAverageConsumableDays from './components/ProductLevelAverageConsumableDays';
import AvgDayStock from './components/AvgDayStock/AvgDayStock';
import ItemExpiry from './components/ItemExpiry';
import StockRotation from './components/StockRotation/StockRotation';
import InventoryComposition from './components/InventoryComposition/InventoryComposition';

import TotalCapacity from './components/TotalCapacity';
import LabCapacity from './components/LabCapacity';
import Attendees from './components/Attendees';
import SamplesPerDay from './components/SamplesPerDay';
import SamplesPerDayTrend from './components/SamplesPerDayTrend/SamplesPerDayTrend';
import SamplesPerDayStatistics from './components/SamplesPerDayStatistics';
import AttendeesStatistics from './components/AttendeesStatistics';
import { LabTypes } from '@/services/Constants';
import redcrescentService from '../services/redcrescent.service';
import TypeFilter from './components/TypeFilter';
import { formatMessage, getLocale } from 'umi';

const { Title, Text } = Typography;

interface IKpiCardProps {
  title: string;
  info?: string;
  filters?: any;
  children?: React.ReactNode;
  location?: string;
}

enum type {
  nonmedicalredcrescent = 'NonMedicalRedCrescentInvenories',
  medicalredcrescent = 'MedicalRedCrescentInvenories',
}

const avgConsumableDaysFilters = [
  {
    name: 'Category filter',
    onChange: (option: string) => {
      avgConsumableDaysFilters[0] = {
        ...avgConsumableDaysFilters,
        selectedOption: [option],
      };
    },
    options: [
      { label: 'By location', value: 'Locations.name' },
      { label: 'By Category', value: 'Products.classification' },
    ],
    selectedOption: ['Locations.name'],
  },
];

const itemExpiryFilters = [
  {
    name: 'Range filter',
    onChange: (option: string) => {
      itemExpiryFilters[0] = {
        ...itemExpiryFilters,
        selectedOption: [option],
      };
    },
    options: [
      { label: '< 1 month', value: '< 1 month' },
      { label: '1 - 3 months', value: '1 - 3 months' },
      { label: '3+ months', value: '3+ months' },
    ],
    selectedOption: '< 1 month',
  },
];

const FilterSelect: React.FC<{}> = (props: any) => {
  return (
    <Select
      style={{ width: '120px' }}
      defaultValue={props?.filter?.options[0]?.value}
      onChange={props.onChange}
    >
      {props.filter.options.map((option: any) => (
        <Select.Option key={option.value} value={option.value}>
          {option.label}
        </Select.Option>
      ))}
    </Select>
  );
};

// KPI card
const KpiCard: React.FC<IKpiCardProps> = (props) => {
  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <div>
              <Text className={styles.chartTitle}>{props.title}</Text>
              {props.info ? (
                <Popover content={props.info} title={formatMessage({ id: 'Info' })}>
                  <InfoCircleOutlined style={{ padding: '8px' }} />
                </Popover>
              ) : null}
            </div>
          </Col>
          <Col flex={2} className={styles.filters}>
            <div>
              {props.filters?.map((filter) => (
                <FilterSelect filter={filter} />
              ))}
            </div>
          </Col>
        </Row>
      </div>
      <div className={styles.kpiCardContent}>{props.children}</div>
    </div>
  );
};

// KPI card
const AverageConsumableDaysChart: React.FC<IKpiCardProps> = (props) => {
  // const chartDimension = avgConsumableDaysFilters[0].selectedOption;
  const [chartDimension, setChartDimension] = useState(avgConsumableDaysFilters[0].selectedOption);
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;

  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{props.title}</Text>
          </Col>
          <Col flex={2} className={styles.filters}>
            {/* <div>
              {props.filters?.map((filter) => (
                <FilterSelect
                  filter={filter}
                  onChange={(val) => {
                    setChartDimension([val]);
                  }}
                />
              ))}
            </div> */}
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <AverageConsumableDays dimensions={chartDimension} labType={props.labType} />
      </div>
    </div>
  );
};

const ItemLevelConsumableDaysChart: React.FC<IKpiCardProps> = (props) => {
  // const [categoryFilter, setCategoryFilter] = useState('All');

  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;
  return (
    <div className={styles.kpiCardLarge}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{props.title}</Text>
          </Col>
          <Col flex={2} className={styles.filters}>
            <div>
              {props?.filters?.options.length > 0 ? (
                <FilterSelect filter={props.filters} onChange={props.setCategoryFilter} />
              ) : (
                <></>
              )}
            </div>
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <ItemLevelConsumableDays
          dimensions={['Products.description']}
          categoryFilter={props.categoryFilter}
          location={props.location}
          labType={props.labType}
        />
      </div>
    </div>
  );
};

export default () => {
  const [selectedLocation, setSelectedLocation] = useState('');
  const [typeFilter, setTypeFilter] = useState('medicalredcrescent');
  const [locations, setLocation] = useState(['All locations']);
  const [loading, setLoading] = useState<boolean>(true);
  const [classification, setClassification] = useState();
  const [categoryFilter, setCategoryFilter] = useState('All');

  useEffect(() => {
    redcrescentService.getLocations(LabTypes.MRC).then((loc: any) => {
      const allLoc = loc.map((location) => location.code);
      setLocation(locations.concat(allLoc));
    });
    getCategory(typeFilter);
    setSelectedLocation('All locations');

    // setLabNames(labNames.concat(lab_Name));
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }, []);

  const getCategory = (typevalue: any) => {
    setClassification({
      name: 'Category filter',
      options: [],
      selectedOption: ['Products.description'],
    });
    setTypeFilter(typevalue);
    setCategoryFilter('All');
    redcrescentService.getPopulatedClassifications(typevalue as LabTypes).then((res) => {
      let categoryArray = res.results.data.map((type) =>
        getLocale() === 'ar-EG'
          ? { key: type.category, name: type.arabicCategory }
          : { key: type.category, name: type.category },
      );

      const uniqueSet = _.uniqBy(categoryArray, 'name');
      // setClassification(uniqueSet);

      let optionArray = uniqueSet.map((category) => ({
        label: category.name,
        value: category.key,
      }));

      let customFilter = {
        name: 'Category filter',
        options: optionArray,
        selectedOption: ['Products.description'],
      };
      setClassification(customFilter);
    });
  };

  return (
    // <PageContainer className={styles.main} header={{ title: '' }}>
    <div className={styles.main}>
      <Spin spinning={loading} size="large" />
      <Row className={styles.locationPanel} align="middle" justify="space-between">
        <Col>
          <Title level={4}>{formatMessage({ id: 'Metrics' })}</Title>
        </Col>
        <Row gutter={[24, 24]} align="middle" style={{ margin: '0px' }}>
          <Col>
            <TypeFilter onChange={getCategory} />
          </Col>
          <Col>
            <LocationSelector onChange={setSelectedLocation} locations={locations} />
          </Col>
        </Row>
      </Row>
      {/* KPI cards */}

      <Row gutter={[24, 24]}>
        <Col span={8}>
          <KpiCard
            title={formatMessage({ id: 'AverageDayStock' })}
            info={() => (
              <div>
                <p>
                  <b>&lt; 15:</b> OOS
                </p>
                <p>
                  <b>15-30:</b> NOOS,
                </p>
                <p>
                  <b>30-80:</b> SS,
                </p>
                <p>
                  <b>&gt; 80:</b> OS
                </p>
              </div>
            )}
          >
            <AvgDayStock location={selectedLocation} labType={type[typeFilter]} />
          </KpiCard>
        </Col>
        <Col span={8}>
          <KpiCard
            title={formatMessage({ id: 'StockRotationPerYear' })}
            info={() => (
              <div>
                <p>
                  <b>{formatMessage({ id: 'TargetValue' })}:</b> 12
                </p>
              </div>
            )}
          >
            {/* <AvgDayStock /> */}
            <StockRotation location={selectedLocation} labType={type[typeFilter]} />
          </KpiCard>
        </Col>
        <Col span={8}>
          <KpiCard title={formatMessage({ id: 'InventoryComposition' })}>
            <InventoryComposition location={selectedLocation} labType={type[typeFilter]} />
          </KpiCard>
        </Col>
      </Row>

      {/* Row 2 */}

      <Row gutter={[24, 24]}>
        <Col span={24}>
          <AverageConsumableDaysChart
            title={formatMessage({ id: 'AverageStockDays' })}
            filters={avgConsumableDaysFilters}
            labType={type[typeFilter]}
          />
        </Col>
      </Row>

      {/* Row 3 */}

      <Row gutter={[24, 24]}>
        <Col span={24}>
          <ItemLevelConsumableDaysChart
            title={formatMessage({ id: 'AvgNoOfDaysStocks' })}
            filters={classification}
            location={selectedLocation}
            labType={type[typeFilter]}
            categoryFilter={categoryFilter}
            setCategoryFilter={setCategoryFilter}
          />
        </Col>
      </Row>

      {/* <Row gutter={[24, 24]}>
            <Col flex={1}>
              <ItemLevelConsumableDaysChart
                title="Avg. No. Of days of stocks"
                filters={itemLevelConsumableDaysFilters}
                location={selectedLocation}
              />
            </Col>
          </Row> */}
    </div>
    // {/* </PageContainer> */}
  );
};

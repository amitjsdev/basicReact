import React, { useState, useEffect ,useRef} from 'react';
import { Empty } from 'antd';

import moment from 'moment';
import SearchBar from './components/SearchBar/SearchBar';
import THSearchTable from './components/THSearchTable/THSearchTable';
import { getSearchResults } from './services';
import { SEARCH_CATEGORIES } from './Constants';

import styles from './index.less';
import PocDetails from './components/PocDetails/PocDetails';
import PatientDetails from './components/PatientDetails/PatientDetails';
import redcrescentService from '../services/redcrescent.service';
import { LabTypes } from '@/services/Constants';
import { getLocale } from 'umi';

const date = moment().format('L');
const SearchResults = (props) => {
  const { category, results, currentLocation, labType ,searchTerm} = props;
  const ref = useRef(null);
  const [height, setHeight] = useState(0);

  useEffect(() => {
    if (ref && ref.current) {
      setHeight(ref.current.clientHeight);
    }
  }, [ref]);

  // const resultContainer = {
  //   purchaseOrderIds: <THSearchTable category={category} results={results} date={date} />,
  //   // poc: <PocDetails poc={poc} date={date} />,
  //   // 'patient-code': <PatientDetails patient={patient} date={date} />,
  // };

  // return resultContainer[category];
  return (
    <div className={styles.main}>
    <div className={styles.container}>
    <div ref={ref}>
    <THSearchTable
      category={category}
      results={results}
      date={date}
      tableHeight={height}
      currentLocation={currentLocation}
      labType={labType}
      searchTerm = {searchTerm}
    />
    </div>
    </div>
        </div>
  );
};

export default () => {
  const [results, setResults] = useState([]);
  const [currentCategory, setCurrentCategory] = useState(SEARCH_CATEGORIES[0]);
  const [poc, setPoc] = useState();
  const [patientDetails, setPatientDetails] = useState();
  const [redcrescentLocation, setRedcrescentLocation] = useState();
  const [currentLocation, setCurrentLocation] = useState(286);
  const [labType, setLabType] = useState('');
  const [search, setSearch] = useState([])
  const [searchTerm,setSearchTerm] = useState();
  useEffect(() => {
    setLabType(window.location.href.includes('non-medical') ? LabTypes.NON_MRC : LabTypes.MRC);

    redcrescentService.getLocations(LabTypes.MRC).then((loc: any) => {
      const locCodeAndId = loc.map(({ code, id }) => ({ code, id }));
      setRedcrescentLocation(locCodeAndId);
    });
    const s = [];
    s.push("Item Code");
    s.push("Item Description");
    s.push("SRCA PO number");
    s.push("Transaction Id");
    setSearch(s);
  }, []);

  const handleLocationChange = (newlocation) => {
    setCurrentLocation(newlocation);
    setResults([]);
    setPoc(null);
    setPatientDetails(null);
  };

  const getResults = async (searchTerm, optionDetail) => {
    if (searchTerm !== '') {
      setCurrentCategory(optionDetail.category);
      

      const searchResults = await getSearchResults(
        searchTerm,
        optionDetail.category,
        labType,
        currentLocation,
      );
      setSearchTerm(searchTerm);
      setResults(searchResults);
    } else {
      setResults([]);
    }

    // }
  };

  const clearData = () => { };
  return (
    <div className={styles.main}>
      <div className={styles.searchBarContainer}>
        <SearchBar
          labtype={labType}
          searchLocation={redcrescentLocation}
          handleSearchResults={getResults}
          onLocationChange={handleLocationChange}
          searchByResults={search}
        />
      </div>
      <div className={styles.resultContainer}>
      
        {results.length || poc || patientDetails ? (
          <SearchResults
            category={currentCategory}
            results={results}
            currentLocation={currentLocation}
            labType={labType}
            searchTerm = {searchTerm}
          />
        ) : (
          <Empty />
        )}
      </div>
    </div>
  );
};

import React from 'react';
import { Table, Tag, Button, Typography, Tooltip, Col, Row } from 'antd';
import moment from 'moment';
import { getLocale, FormattedMessage, formatMessage } from 'umi';
import { DATE_FORMAT } from '../../Constants';
import styles from './index.less';
import redcrescentService from '@/pages/RedCrescent/services/redcrescent.service';
import { nestedColumns } from '@/pages/BloodBank/BloodBankTransfer/components/TransferTable/columns';

const { Text } = Typography;

export default (props) => {
  const { category, results, date, currentLocation, labType, tableHeight, searchTerm } = props;

  const dateDiff = (_date) => {
    const today = new Date();
    const yday = new Date(_date);
    const _diff = (today.getTime() - yday.getTime()) / (1000 * 3600 * 24);
    return _diff;
  };
  const categoryWiseColumns = {
    columns: [
      {
        title: <FormattedMessage id="TransactionId" />,
        dataIndex: 'transferId',
        key: 'id',
      },
      {
        title: <FormattedMessage id="TypeOfTransaction" />,
        dataIndex: 'transferType',
        key: 'transferType',
      },
      {
        title: <FormattedMessage id="ItemName" />,
        dataIndex: getLocale() === 'ar-EG' ? 'arabicDescription' : 'description',
        key: 'description',
      },
      {
        title: <FormattedMessage id="FromLocation" />,
        dataIndex: 'fromLocationCode',
        key: 'fromLocationCode',
      },
      {
        title: <FormattedMessage id="ToLocation" />,
        dataIndex: 'toLocationCode',
        key: 'toLocationCode',
      },
      {
        title: <FormattedMessage id="RequestedQuantity" />,
        dataIndex: 'requestedQuantity',
        key: 'quantity',
        render: (text: any, record: any) => {
          return record.transferType === 'ISS' ? record.receivedQuantity : record.requestedQuantity;
        },
      },
      {
        title: <FormattedMessage id="ReceivedQuantity" />,
        dataIndex: 'receivedQuantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="Status" />,
        key: 'status',
        dataIndex: 'status',
        render: (text: any, record: any) => {
          return record.status === 'created' ? (
            <Tag
              style={{
                textTransform: 'uppercase',
              }}
            >
              <FormattedMessage id="Approved" />
            </Tag>
          ) : (
            <Tag
              style={{
                textTransform: 'uppercase',
              }}
            >
              {text ? formatMessage({ id: `${text.charAt(0).toUpperCase() + text.slice(1)}` }) : ''}
            </Tag>
          );
        },
      },
      {
        title: <FormattedMessage id="DateOfTransaction" />,
        key: 'updatedAt',
        dataIndex: 'updatedAt',
        render: (text, record) => {
          return getLocale().includes('en')
            ? moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
            : moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD');
        },
      },
    ],

    columnsDescp: [
      {
        title: <FormattedMessage id="Code" />,
        dataIndex: 'code',
        key: 'id',
      },
      {
        title: <FormattedMessage id="TransactionId" />,
        dataIndex: 'transferId',
        key: 'id',
      },
      {
        title: <FormattedMessage id="TypeOfTransaction" />,
        dataIndex: 'transferType',
        key: 'transferType',
      },
      {
        title: <FormattedMessage id="ItemName" />,
        dataIndex: 'description',
        key: 'description',
      },
      {
        title: <FormattedMessage id="FromLocation" />,
        dataIndex: 'fromLocationCode',
        key: 'fromLocationCode',
      },
      {
        title: <FormattedMessage id="ToLocation" />,
        dataIndex: 'toLocationCode',
        key: 'toLocationCode',
      },
      {
        title: <FormattedMessage id="RequestedQuantity" />,
        dataIndex: 'requestedQuantity',
        key: 'quantity',
        render: (text: any, record: any) => {
          return record.transferType === 'ISS' ? record.receivedQuantity : record.requestedQuantity;
        },
      },
      {
        title: <FormattedMessage id="ReceivedQuantity" />,
        dataIndex: 'receivedQuantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="Status" />,
        key: 'status',
        dataIndex: 'status',
        render: (text: any, record: any) => {
          return record.status === 'created' ? (
            <Tag
              style={{
                textTransform: 'uppercase',
              }}
            >
              <FormattedMessage id="Approved" />
            </Tag>
          ) : (
            <Tag
              style={{
                textTransform: 'uppercase',
              }}
            >
              {text ? formatMessage({ id: `${text.charAt(0).toUpperCase() + text.slice(1)}` }) : ''}
            </Tag>
          );
        },
      },
      {
        title: <FormattedMessage id="DateOfTransaction" />,
        key: 'updatedAt',
        dataIndex: 'updatedAt',
        render: (text, record) => {
          return getLocale().includes('en')
            ? moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD')
            : moment(text, DATE_FORMAT).locale(getLocale()).format('YYYY-MM-DD');
        },
      },
    ],

    columns1: [
      {
        title: <FormattedMessage id="TransactionId" />,
        dataIndex: 'transferId',
        key: 'id',
      },
      {
        title: <FormattedMessage id="FromLocation" />,
        dataIndex: 'fromLocationCode',
        key: 'fromLocationCode',
      },
      {
        title: <FormattedMessage id="ToLocation" />,
        dataIndex: 'toLocationCode',
        key: 'toLocationCode',
      },
      {
        title: <FormattedMessage id="RequestedQuantity" />,
        dataIndex: 'requestedQuantity',
        key: 'quantity',
        render: (text: any, record: any) => {
          return record.transferType === 'ISS' ? record.receivedQuantity : record.requestedQuantity;
        },
      },
      {
        title: <FormattedMessage id="ReceivedQuantity" />,
        dataIndex: 'receivedQuantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="Status" />,
        key: 'status',
        dataIndex: 'status',
        render: (text: any, record: any) => {
          return record.status === 'created' ? (
            <Tag
              style={{
                textTransform: 'uppercase',
              }}
            >
              <FormattedMessage id="Approved" />
            </Tag>
          ) : (
            <Tag
              style={{
                textTransform: 'uppercase',
              }}
            >
              {text ? formatMessage({ id: `${text.charAt(0).toUpperCase() + text.slice(1)}` }) : ''}
            </Tag>
          );
        },
      },
    ],
    nestedColumns: [
      {
        title: <FormattedMessage id="Code" />,
        width: '200px',
        dataIndex: 'productCode',
        key: 'productCode',
      },
      {
        title: <FormattedMessage id="Description" />,
        width: '200px',
        dataIndex: getLocale() === 'ar-EG' ? 'arabicDescription' : 'description',
        key: 'description',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        width: '150px',
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        width: '150px',
        dataIndex: 'updatedAt',
        key: 'updatedAt',
        render: (text, record) =>
          getLocale().includes('en')
            ? moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
      {
        title: <FormattedMessage id="CreatedAt" />,
        width: '150px',
        dataIndex: 'createdAt',
        key: 'createdAt', // moment(batch.manufactureDate).format(dateFormat)
        render: (text, record) =>
          getLocale().includes('en')
            ? moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
    ],

    nestedPOColumns: [
      {
        title: <FormattedMessage id="BatchNumber" />,
        width: '200px',
        dataIndex: 'batchNumber',
        key: 'code',
      },
      {
        title: <FormattedMessage id="GRN" />,
        width: '200px',
        dataIndex: 'id',
        key: 'id',
      },
      {
        title: <FormattedMessage id="ReceivedQuantity" />,
        width: '150px',
        dataIndex: 'receivedQuantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="AcceptedQuantity" />,
        width: '150px',
        dataIndex: 'acceptedQuantity',
        key: 'acceptedQuantity',
      },
      {
        title: <FormattedMessage id="HoldQuantity" />,
        width: '150px',
        dataIndex: 'holdedQuantity',
        key: 'holdedQuantity',
      },
      {
        title: <FormattedMessage id="RejectedQuantity" />,
        width: '150px',
        dataIndex: 'rejectedQuantity',
        key: 'rejectedQuantity',
      },
      {
        title: <FormattedMessage id="CreatedAt" />,
        width: '150px',
        dataIndex: 'createdAt',
        key: 'createdAt', // moment(batch.manufactureDate).format(dateFormat)
        render: (text, record) =>
          getLocale().includes('en')
            ? moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
      {
        title: <FormattedMessage id="Status" />,
        key: 'status',
        dataIndex: 'status',
        render: (text: any, record: any) => {
          return record.status === 'created' ? (
            <Tag
              style={{
                textTransform: 'uppercase',
              }}
            >
              <FormattedMessage id="Created" />
            </Tag>
          ) : (
            <Tag
              style={{
                textTransform: 'uppercase',
              }}
            >
              {text ? formatMessage({ id: `${text.charAt(0).toUpperCase() + text.slice(1)}` }) : ''}
            </Tag>
          );
        },
      },
    ],

    nestedInspectedColumns: [
      {
        title: <FormattedMessage id="Code" />,
        width: '200px',
        dataIndex: 'productCode',
        key: 'productCode',
      },
      {
        title: <FormattedMessage id="Description" />,
        width: '200px',
        dataIndex: getLocale() === 'ar-EG' ? ['product', 'arabicDescription'] : 'description',
        key: 'description',
      },
      {
        title: <FormattedMessage id="Quantity" />,
        width: '150px',
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: <FormattedMessage id="PendingQuantity" />,
        width: '150px',
        dataIndex: 'quarantineQuantity',
        key: 'quarantineQuantity',
      },
      {
        title: <FormattedMessage id="UpdatedAt" />,
        width: '150px',
        dataIndex: 'updatedAt',
        key: 'updatedAt',
        render: (text, record) =>
          getLocale().includes('en')
            ? moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
      {
        title: <FormattedMessage id="CreatedAt" />,
        width: '150px',
        dataIndex: 'createdAt',
        key: 'createdAt', // moment(batch.manufactureDate).format(dateFormat)
        render: (text, record) =>
          !getLocale() || getLocale().includes('en')
            ? moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.createdAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
    ],
    GRNColumn: [
      {
        title: <FormattedMessage id="GRN" />,
        width: '100px',
        dataIndex: 'id',
        key: 'id',
      },
      {
        title: <FormattedMessage id="PurchaseOrderId" />,
        width: '100px',
        dataIndex: 'purchaseOrderId',
        key: 'purchaseOrderId',
      },
      {
        title: <FormattedMessage id="Description" />,
        width: '200px',
        dataIndex: getLocale() === 'ar-EG' ? 'arabicDescription' : 'description',
        key: 'purchaseOrderId',
      },
      {
        title: <FormattedMessage id="ReceivedQuantity" />,
        width: '100px',
        dataIndex: 'receivedQuantity',
        key: 'receivedQuantity',
      },
      {
        title: <FormattedMessage id="UpdatedAt" />,
        width: '100px',
        dataIndex: 'updatedAt',
        key: 'updatedAt',
        render: (text, record) =>
          getLocale().includes('en')
            ? moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD')
            : moment(record.updatedAt).locale(getLocale()).format('YYYY-MM-DD'),
      },
    ],
  };

  const downloadPO = async (id) => {
    await redcrescentService.downloadPO(id, currentLocation, labType);
  };

  const expandedRowRender = (nestedData, status) => {
    return (
      <Table
        columns={
          status === 'transferIds'
            ? categoryWiseColumns['nestedPOColumns']
            : status === 'pending'
            ? categoryWiseColumns['nestedPendingColumns']
            : categoryWiseColumns['nestedPOColumns']
        }
        dataSource={nestedData}
        pagination={false}
      />
    );
  };
  const downloadTranscation = async () => {
    await redcrescentService.downloadTranscation(labType, currentLocation, category, searchTerm);
  };
  const getTotalColumnWidth = (columns) => {
    return columns.reduce((acc, cur) => acc + parseInt(cur.width, 10), 0);
  };
  const columns =
    category === 'productCode' || category === 'productDescriptions'
      ? categoryWiseColumns['columnsDescp']
      : category === 'GRNIds'
      ? categoryWiseColumns['GRNColumn']
      : category === 'transferIds' || category === 'transferTypes'
      ? categoryWiseColumns['columns']
      : categoryWiseColumns['columns1'];
  return (
    <Row style={{ width: '100%' }}>
      <div className={styles.tableContainer}>
        <Table
          columns={columns}
          dataSource={results}
          rowKey={(record) => record.tableId}
          expandedRowRender={(record) => expandedRowRender(record.items, 'transferIds')}
          pagination={false}
          scroll={{
            x:
              getTotalColumnWidth(columns) + // All columns
              300, // Checkbox
            y: tableHeight - 100,
          }}
          expandable={{
            rowExpandable: (record) => {
              if (record && record.items && record?.items.length > 0) {
                return true;
              } else {
                return false;
              }
            },
          }}
        />
      </div>
      <Row className={styles.stickyFooter} gutter={[12, 0]}>
        <Col>
          <Button type="primary" onClick={downloadTranscation}>
            <FormattedMessage id="Download" />
          </Button>
        </Col>
      </Row>
    </Row>
  );
};

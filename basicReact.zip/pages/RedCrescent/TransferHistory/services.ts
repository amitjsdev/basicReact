import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';

import { getCubejsApiParams } from '@/services/cubejs';
import redcrescentService from '../services/redcrescent.service';
import { SearchCategoryUrlFragments } from './Constants';

// CubeJS
const cubejsParams = getCubejsApiParams();

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const useCubeData = (query: any) => {
  const { resultSet, isLoading, error, progress } = useCubeQuery(query, {
    cubejsApi,
  });

  if (isLoading) {
    return {
      isLoading,
      progress,
      dataSource: null,
    };
  }

  if (error) {
    return null;
  }

  if (!resultSet && !resultSet?.tablePivot()) {
    return null;
  }

  return {
    isLoading,
    dataSource: resultSet.tablePivot(),
    progress: null,
  };
};

const getAutocompleteResults = (searchTerm: string, searchLocation: string, labtype: any) => {
  return redcrescentService.getAutocompleteResultsTransferHistory(
    searchTerm,
    searchLocation,
    labtype,
  );
};

const getSearchResults = (
  searchTerm: string,
  category: string,
  labType: any,
  currentLocation: any,
) => {
  return redcrescentService.searchItemTransferHistory(
    searchTerm,
    SearchCategoryUrlFragments[category],
    labType,
    currentLocation,
  );

  // return category === 'tickets'
  //   ? redcrescentService.searchTickets(regionId, searchTerm)
  //   : redcrescentService.searchPodData(searchTerm);
};

export { getAutocompleteResults, getSearchResults, useCubeData };

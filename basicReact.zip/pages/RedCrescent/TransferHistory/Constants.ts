enum AutocompleteCategories {
  'purchaseOrderIds' = 'Purchase Order Id',
  'GRNIds' = 'GRN',
  'descriptions' = 'Description',
  'productCodes' = 'Product Code',
  'productDescriptions' = 'Description',
  'transferIds' = 'TransferIds',
  'transferTypes' = 'TransferTypes',
  
}

enum PriorityColors {
  'low' = 'green',
  'medium' = 'gold',
  'high' = 'volcano',
  'critical' = 'red',
}

enum SearchCategoryNames {
  'purchaseOrderIds' = 'Purchase Order Id',
  'GRNIds' = 'GRN',
  'descriptions' = 'Description',
  'productCodes' = 'Product Code',
}

enum SearchCategoryUrlFragments {
  'purchaseOrderIds' = 'purchaseOrderId',
  'GRNIds' = 'GRN',
  'descriptions' = 'description',
  'productCodes' = 'productCode',
  'transferIds' = 'transferId',
  "transferTypes" = 'transferType',
  "productDescriptions" = "productDescription"
}

enum PocKpiNames {
  'efficiency' = 'SLA Compliance',
  'tat' = 'TAT',
  'missingSamples' = 'Missing Samples',
  'samplesInTransit' = 'Samples in transit',
  'completedTrips' = 'Completed Trips',
}

enum PatientDetailNames {
  'patientCode' = 'Swab ID',
  'pointOfCollection' = 'Sample collected at',
  'status' = 'Status',
  'patientName' = 'Sample delivered at',
  'networkEfficiency' = 'SLA Compliance',
  'sla' = 'Target SLA',
  'turnAroundTime' = 'Turn Around Time',
  'timeforSampleCollection' = 'Response Time',
  'appointmentDate' = 'Appointment created on',
  'sampleCollectionTime' = 'Sample collected on',
  'sampleProcessTime' = 'Sample processed on',
}

enum PatientDetailOrder {
  'patientCode' = 0,
  'status' = 1,
  'patientName' = 2,
  'pointOfCollection' = 3,
  'sla' = 4,
  'turnAroundTime' = 5,
  'timeforSampleCollection' = 6,
  'networkEfficiency' = 7,
  'appointmentDate' = 8,
  'sampleCollectionTime' = 9,
  'sampleProcessTime' = 10,
}

enum TicketPropertyNames {
  externalTicketId = 'Ticket number',
  subject = 'Description',
  sla = 'Target SLA',
  turnAroundTime = 'TAT',
  dueDate = 'Due date',
  priority = 'Priority',
  status = 'Status',
  pointOfCollection = 'Point of Collection',
}

enum TicketPropertySuffix {
  'Ticket number' = '',
  'Description' = '',
  'Target SLA' = 'hrs',
  'TAT' = 'hrs',
  'Due date' = '',
  'Priority' = '',
  'Status' = '',
  'Point of Collection' = '',
}

enum TicketPropertyOrder {
  externalTicketId = 1,
  subject = 2,
  dueDate = 3,
  status = 4,
  priority = 5,
  sla = 6,
  turnAroundTime = 7,
  pointOfCollection = 8,
}

enum TicketTableProperties {
  TICKET_NUMBER = 'externalTicketId',
  DESCRIPTION = 'subject',
  TARGET_SLA = 'sla',
  TAT = 'turnAroundTime',
  DUE_DATE = 'dueDate',
  PRIORITY = 'priority',
  STATUS = 'status',
  POC = 'pointOfCollection',
}

const SEARCH_CATEGORIES = ['purchaseOrderIds', 'GRNIds', 'descriptions', 'productCodes'];
const INVENTORY_CATEGORIES = ['productCode', 'productDescription'];
const POC_KPIS = ['efficiency', 'tat', 'missingSamples', 'samplesInTransit', 'completedTrips'];
const PATIENT_DETAILS = [
  'status',
  'pointOfCollection',
  'patientName',
  'networkEfficiency',
  'sla',
  'turnAroundTime',
  'timeforSampleCollection',
  'appointmentDate',
  'sampleCollectionTime',
  'sampleProcessTime',
];
const PATIENT_DETAILS_TIME_PROPERTIES = [
  'appointmentDate',
  'sampleCollectionTime',
  'sampleProcessTime',
];

const DATE_FORMAT = 'YYYY-MM-DD, HH:mm';

export {
  AutocompleteCategories,
  PriorityColors,
  SearchCategoryNames,
  SearchCategoryUrlFragments,
  PocKpiNames,
  PatientDetailNames,
  PatientDetailOrder,
  TicketPropertyNames,
  TicketTableProperties,
  TicketPropertySuffix,
  TicketPropertyOrder,
  DATE_FORMAT,
  SEARCH_CATEGORIES,
  INVENTORY_CATEGORIES,
  POC_KPIS,
  PATIENT_DETAILS,
  PATIENT_DETAILS_TIME_PROPERTIES,
};

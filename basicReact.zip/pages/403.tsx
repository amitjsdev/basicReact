import React, { useState, useEffect } from 'react';
import { history } from 'umi';
import { Result, Button } from 'antd';

import {
  checkLocalProfileIntegrity,
  getAuthToken,
  getUserProfileFromLocal,
} from '@/utils/userProfile';
import { storageService } from '@/services/storage';
import { LoadingOutlined } from '@ant-design/icons';

const goBack = () => {
  if (getAuthToken()) {
    history.push('/');
  } else {
    storageService.clear();
    history.push('/user/login');
  }
};

const Exception = (props) => {
  return (
    <Result
      icon={<LoadingOutlined />}
      subTitle="Please wait. If this persists, try logging in again."
      /* extra={
      <Button type="primary" onClick={backToHome}>
        Go back
      </Button>
    } */
    />
  );
};

export default Exception;

import React, { useState } from 'react';
import { Link, history } from 'umi';
import { Button, Form, Input, message } from 'antd';
import httpService from '../../../services/http.service';
import { ApiUrlFragments } from '../../../services/Constants';
import logo from '@/assets/MoH-logo.png';
import redCrescentLogo from '@/assets/Redcrescent-logo.png';
import { RED_CRESCENT_URL } from '@/services/Constants';

import styles from '../login/style.less';

const SetPassword = () => {
  const [loading, setLoading] = useState(false);
  const handleSubmit = async (values: any) => {
    try {
      if (
        history.location.query.k &&
        values.password === values.reenterPassword &&
        values.password.length >= 8
      ) {
        setLoading(true);
        await httpService
          .post(`${ApiUrlFragments.AUTH}/password/reset`, {
            key: history.location.query.k,
            newPassword: values.password,
          })
          .then((data) => {
            setLoading(false);
            message.success(data.message);
            history.push('/user/login');
          })
          .catch((err) => {
            if (err.data?.message) {
              message.error(err.data?.message);
            } else {
              message.error('Network error');
            }
            setLoading(false);
          });
      }
    } catch (error) {
      setLoading(false);
      message.error(error.response.data.message);
    }
  };

  enum Branding {
    RED_CRESCENT = 'Red Crescent',
    MOH = 'Ministry of Health',
  }

  return (
    <div className={styles.container}>
      <div className={styles.lang}>{/* <SelectLang /> */}</div>
      <div className={styles.content}>
        <div className={styles.top}>
          <div className={styles.header}>
            <Link to="/user/login">
              <img
                alt="logo"
                className={styles.logo}
                src={window.location.href.includes(RED_CRESCENT_URL) ? redCrescentLogo : logo}
              />
              <span className={styles.title}>
                {window.location.href.includes(RED_CRESCENT_URL)
                  ? Branding.RED_CRESCENT
                  : Branding.MOH}
              </span>
            </Link>
          </div>
          <div className={styles.desc} />
        </div>

        <div className={styles.main}>
          <Form initialValues={{ password: '' }} onFinish={handleSubmit}>
            <Form.Item
              name="password"
              rules={[
                { required: true, message: 'Please enter new password!' },
                ({ getFieldValue }) => ({
                  validator(_, value) {
                    if (!value || !(value.length < 8)) {
                      return Promise.resolve();
                    }
                    return Promise.reject(
                      new Error('The passwords must be of minimum 8 characters!'),
                    );
                  },
                }),
              ]}
            >
              <Input.Password placeholder="Password" type="password" />
            </Form.Item>

            <Form.Item
              name="reenterPassword"
              dependencies={['password']}
              rules={[
                {
                  required: true,
                  message: 'Please confirm your password!',
                },
                ({ getFieldValue }) => ({
                  validator(_, value) {
                    if (!value || getFieldValue('password') === value) {
                      return Promise.resolve();
                    }
                    return Promise.reject(
                      new Error('The two passwords that you entered do not match!'),
                    );
                  },
                }),
              ]}
            >
              <Input.Password placeholder="Re-enter Password" type="password" />
            </Form.Item>

            <Form.Item>
              <Button block type="primary" htmlType="submit" loading={loading}>
                Submit
              </Button>
            </Form.Item>
          </Form>
        </div>
      </div>
      {/* <Footer /> */}
    </div>
  );
};

export default SetPassword;

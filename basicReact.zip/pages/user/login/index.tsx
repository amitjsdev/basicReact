import React, { useState } from 'react';
import { Link, useModel, history, formatMessage, FormattedMessage } from 'umi';

import authService from '@/services/auth.service';
import { storageService } from '@/services/storage';
import homeRouteResolver from '@/utils/homeRouteResolver';
import logo from '@/assets/MoH-logo.png';
import redCrescentLogo from '@/assets/Redcrescent-logo.png';
import Apis from '../../../api/apis';
import LoginFrom from './components/Login';
import { RED_CRESCENT_URL } from '@/services/Constants';

import styles from './style.less';

interface ILoginParams {
  email: string;
  password: string;
}

const { Tab, Username, Password, Submit } = LoginFrom;

const LoginMessage: React.FC<{
  content: string;
}> = ({ content }) => (
  <Alert
    style={{
      marginBottom: 24,
    }}
    message={content}
    type="error"
    showIcon
  />
);

enum Branding {
  RED_CRESCENT = 'Red Crescent',
  MOH = 'Ministry of Health',
}

const Login: React.FC<{}> = () => {
  const [userLoginState, setUserLoginState] = useState<API.LoginStateType>({});
  const [submitting, setSubmitting] = useState(false);
  const { setInitialState } = useModel('@@initialState');
  const [type, setType] = useState<string>('account');

  const login = async (userCredentials) => {
    const { token } = await await authService.login(userCredentials);
    storageService.setItem('auth-token', token);
  };

  const handleSubmit = async (userCredentials: ILoginParams) => {
    setSubmitting(true);

    try {
      await login(userCredentials);

      Apis.getProfile().then(async (data) => {
        const userProfile: API.Profile = data;
        const defaultModule =
          (userProfile &&
            userProfile.modules &&
            userProfile.modules.find((module) => module.default)?.name) ||
          userProfile.modules[0].name;

        setUserLoginState({ status: 'ok', type });
        // setUserProfileInLocal(userProfile);
        setInitialState({
          currentUser: {
            ...userProfile,
            defaultModule,
            currentModule: defaultModule,
          },
        });

        storageService.setItem('current-app', defaultModule);

        const cubejsToken = await authService.getCubeJsToken();

        storageService.setItem('cubejs-token', cubejsToken);

        const homeRoute = homeRouteResolver(userProfile.modules[0].role);

        // history.push(homeRoute);
        history.push('/');
      });
    } catch (err) {
      console.error(err);
    }

    setSubmitting(false);
  };

  const { status } = userLoginState;

  return (
    <div className={styles.container}>
      <div className={styles.lang}>{/* <SelectLang /> */}</div>
      <div className={styles.content}>
        <div className={styles.top}>
          <div className={styles.header}>
            <Link to="/user/login">
              <img
                alt="logo"
                className={styles.logo}
                src={window.location.href.includes(RED_CRESCENT_URL) ? redCrescentLogo : logo}
              />
              <span className={styles.title}>
                {window.location.href.includes(RED_CRESCENT_URL)
                  ? Branding.RED_CRESCENT
                  : Branding.MOH}
              </span>
            </Link>
          </div>
          <div className={styles.desc} />
        </div>

        <div className={styles.main}>
          <LoginFrom activeKey={type} onTabChange={setType} onSubmit={handleSubmit}>
            <Tab key="account" tab="Email">
              {status === 'error' && loginType === 'account' && !submitting && (
                <LoginMessage content={formatMessage({ id: 'IncorrectEmailOrPassword' })} />
              )}

              <Username
                name="email"
                placeholder={formatMessage({ id: 'EnterEmail' })}
                rules={[
                  {
                    required: true,
                    message: 'Invalid!',
                  },
                ]}
              />
              <Password
                name="password"
                placeholder={formatMessage({ id: 'EnterPassword' })}
                rules={[
                  {
                    required: true,
                    message: 'Invalid！',
                  },
                ]}
              />
            </Tab>
            <div>
              {/* <Checkbox checked={autoLogin} onChange={(e) => setAutoLogin(e.target.checked)}>
                Remember Me
              </Checkbox> */}
              <Link
                style={{
                  float: 'right',
                }}
                to="/user/forgot-password"
              >
                <FormattedMessage id="ForgotPassword" />
              </Link>
            </div>
            <Submit loading={submitting}>
              <FormattedMessage id="Submit" />
            </Submit>
            <div className={styles.other}>
              {/* <Link className={styles.register} to="/user/register">
                Register Account
              </Link> */}
            </div>
          </LoginFrom>
        </div>
      </div>
      {/* <Footer /> */}
    </div>
  );
};

export default Login;

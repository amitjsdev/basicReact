import React, { useState } from 'react';
import { Link, history } from 'umi';
import { Button, Form, Input, message } from 'antd';
import httpService from '../../../services/http.service';
import { ApiUrlFragments } from '../../../services/Constants';
import logo from '@/assets/MoH-logo.png';
import redCrescentLogo from '@/assets/Redcrescent-logo.png';
import { RED_CRESCENT_URL } from '@/services/Constants';
import styles from '../login/style.less';

const ForgotPassword = () => {
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (values: any) => {
    setLoading(true);
    await httpService
      .post(`${ApiUrlFragments.AUTH}/password/forgot`, {
        email: values.Email,
        labType: 'redcrescent',
      })
      .then((res) => {
        setLoading(false);
        message.success('Sent verification link to the email');
        history.push('/user/login');
      })
      .catch((err) => {
        if (err.data?.message) {
          message.error(err.data?.message);
        } else {
          message.error('Network error');
        }
        setLoading(false);
      });
  };

  enum Branding {
    RED_CRESCENT = 'Red Crescent',
    MOH = 'Ministry of Health',
  }

  return (
    <div className={styles.container}>
      <div className={styles.lang}>{/* <SelectLang /> */}</div>
      <div className={styles.content}>
        <div className={styles.top}>
          <div className={styles.header}>
            <Link to="/user/login">
              <img
                alt="logo"
                className={styles.logo}
                src={window.location.href.includes(RED_CRESCENT_URL) ? redCrescentLogo : logo}
              />
              <span className={styles.title}>
                {window.location.href.includes(RED_CRESCENT_URL)
                  ? Branding.RED_CRESCENT
                  : Branding.MOH}
              </span>
            </Link>
          </div>
          <div className={styles.desc} />
        </div>

        <div className={styles.main}>
          <Form initialValues={{ email: '' }} onFinish={handleSubmit}>
            <Form.Item
              name="Email"
              rules={[{ required: true, message: 'Please enter your Email!' }]}
            >
              <Input placeholder="Enter your Email" type="Email" />
            </Form.Item>

            <Form.Item>
              <Button block type="primary" htmlType="submit" loading={loading}>
                Submit
              </Button>
            </Form.Item>
          </Form>
        </div>
      </div>
      {/* <Footer /> */}
    </div>
  );
};

export default ForgotPassword;

import { React, useEffect, useState } from 'react';
import './index.css';
const App = (props) => {


  const { value, setValue } = props

  const priceChange = (e, type) => {
      
    if (type === 'firstInput') {
        console.log("e, type",e, type)
      if (e < 0) {

        setValue([0, value[1]]);
      } else if (e >= value[1]) {
        setValue([parseInt(value[1]) - parseInt(1), value[1]]);
       // return;
      } else {
        console.log("else, type",e, type)
        setValue([e, value[1]]);
      }

    }
    if (type === 'secondInput') {
      if (e < 0) {
        setValue([value[0], value[1]]);
      } else if (e <= value[0] || e == 0) {
        setValue([value[0], parseInt(value[0]) + parseInt(1)]);
       // return;
      } else {
        setValue([value[0], e]);
      }


    }

  }

  return (
    <div style={{
      margin: 'auto',
      display: 'block',
      width: 'fit-content'
    }}>
      <div>
        <h2>Price</h2>
        <div className="row">
          <div className="col">
            <label className="IDofInput">Min price</label>
            <input min="0" onChange={(e) => priceChange(e.target.value, 'firstInput')} value={value[0]} type="number" id="IDofInput" />
          </div>
          <div className="col">
            <label className="IDofInput">Max Price</label>
            <input min="0" value={value[1]} onChange={(e) => priceChange(e.target.value, 'secondInput')} type="number" id="IDofInput" />
          </div>
        </div>
        <div>
          <span className="multi-range">
            <input onChange={(e) => priceChange(e.target.value, 'firstInput')} type="range" min="0" max="99" value={value[0]} id="lower" />
            <input onChange={(e) => priceChange(e.target.value, 'secondInput')} type="range" min="0" max="100" value={value[1]} id="upper" />
          </span>
        </div>
      </div>
    </div>
  );
}

export default App;
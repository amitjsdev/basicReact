import React from 'react';
import Typography from '@material-ui/core/Typography';
import Slider from '@material-ui/core/Slider';
import './index.css'
const App = (props) => {



const {value, setValue} = props 

// Changing State when volume increases/decreases
const rangeSelector = (event, newValue) => {
	setValue(newValue);
	console.log(newValue)
};

const priceChange = (e,type) => {
console.log("e,type",e,type)
if(type === 'firstInput'){
	setValue([e,value[1]]);
}
if(type === 'secondInput'){
	setValue([value[0],e]);
}
}
return (
	<div style={{
	margin: 'auto',
	display: 'block',
	width: 'fit-content'
	}}>
	
  <div>
    <h2>Price</h2>
    <div class="row">
    <div class="col">
        <label className="IDofInput">Min price</label> 
        <input min="0" onChange={(e) => priceChange(e.target.value,'firstInput') }  value={value[0]} type="number" id="IDofInput" /> 
    </div>
    <div class="col">
        <label className="IDofInput">Max Price</label> 
        <input min="0" value={value[1]} onChange={(e) => priceChange(e.target.value,'secondInput') } type="number" id="IDofInput" />
    </div>
</div>
  </div>
	<Typography id="range-slider" gutterBottom>
		Select Price Range:
	</Typography>
	<Slider
		value={value}
		onChange={rangeSelector}
		valueLabelDisplay="auto"
	/>
	Your range of Price is between {value[0]} /- and {value[1]} /-
	</div>
);
}

export default App;

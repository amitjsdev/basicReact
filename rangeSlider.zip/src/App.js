
import React from 'react';
import './App.css';
import CustomSlider from './components/CustomSlider/index';
function App() {
  const [value, setValue] = React.useState([2,50]);

  return (
    <div className="App">
      <CustomSlider
      value={value}
      setValue={setValue}
      />
    </div>
  );
}

export default App;
